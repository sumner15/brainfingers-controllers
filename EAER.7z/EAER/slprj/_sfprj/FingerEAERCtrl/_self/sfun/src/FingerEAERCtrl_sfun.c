/* Include files */

#include "FingerEAERCtrl_sfun.h"
#include "c1_FingerEAERCtrl.h"
#include "c2_FingerEAERCtrl.h"
#include "c3_FingerEAERCtrl.h"
#include "c4_FingerEAERCtrl.h"
#include "c5_FingerEAERCtrl.h"
#include "c6_FingerEAERCtrl.h"
#include "c7_FingerEAERCtrl.h"
#include "c8_FingerEAERCtrl.h"
#include "c9_FingerEAERCtrl.h"
#include "c10_FingerEAERCtrl.h"
#include "c11_FingerEAERCtrl.h"
#include "c12_FingerEAERCtrl.h"
#include "c13_FingerEAERCtrl.h"
#include "c14_FingerEAERCtrl.h"
#include "c15_FingerEAERCtrl.h"
#include "c16_FingerEAERCtrl.h"
#include "c17_FingerEAERCtrl.h"
#include "c18_FingerEAERCtrl.h"
#include "c19_FingerEAERCtrl.h"
#include "c20_FingerEAERCtrl.h"
#include "c21_FingerEAERCtrl.h"
#include "c22_FingerEAERCtrl.h"
#include "c23_FingerEAERCtrl.h"
#include "c24_FingerEAERCtrl.h"
#include "c25_FingerEAERCtrl.h"
#include "c26_FingerEAERCtrl.h"
#include "c27_FingerEAERCtrl.h"
#include "c28_FingerEAERCtrl.h"
#include "c29_FingerEAERCtrl.h"
#include "c30_FingerEAERCtrl.h"
#include "c31_FingerEAERCtrl.h"
#include "c32_FingerEAERCtrl.h"
#include "c33_FingerEAERCtrl.h"
#include "c34_FingerEAERCtrl.h"
#include "c35_FingerEAERCtrl.h"
#include "c36_FingerEAERCtrl.h"
#include "c37_FingerEAERCtrl.h"
#include "c38_FingerEAERCtrl.h"
#include "c39_FingerEAERCtrl.h"
#include "c40_FingerEAERCtrl.h"
#include "c41_FingerEAERCtrl.h"
#include "c42_FingerEAERCtrl.h"
#include "c43_FingerEAERCtrl.h"
#include "c44_FingerEAERCtrl.h"
#include "c45_FingerEAERCtrl.h"
#include "c46_FingerEAERCtrl.h"
#include "c47_FingerEAERCtrl.h"
#include "c48_FingerEAERCtrl.h"
#include "c49_FingerEAERCtrl.h"
#include "c50_FingerEAERCtrl.h"
#include "c51_FingerEAERCtrl.h"
#include "c52_FingerEAERCtrl.h"
#include "c53_FingerEAERCtrl.h"
#include "c55_FingerEAERCtrl.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
uint32_T _FingerEAERCtrlMachineNumber_;
real_T _sfTime_;

/* Function Declarations */

/* Function Definitions */
void FingerEAERCtrl_initializer(void)
{
}

void FingerEAERCtrl_terminator(void)
{
}

/* SFunction Glue Code */
unsigned int sf_FingerEAERCtrl_method_dispatcher(SimStruct *simstructPtr,
  unsigned int chartFileNumber, const char* specsCksum, int_T method, void *data)
{
  if (chartFileNumber==1) {
    c1_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==2) {
    c2_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==3) {
    c3_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==4) {
    c4_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==5) {
    c5_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==6) {
    c6_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==7) {
    c7_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==8) {
    c8_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==9) {
    c9_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==10) {
    c10_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==11) {
    c11_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==12) {
    c12_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==13) {
    c13_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==14) {
    c14_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==15) {
    c15_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==16) {
    c16_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==17) {
    c17_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==18) {
    c18_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==19) {
    c19_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==20) {
    c20_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==21) {
    c21_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==22) {
    c22_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==23) {
    c23_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==24) {
    c24_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==25) {
    c25_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==26) {
    c26_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==27) {
    c27_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==28) {
    c28_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==29) {
    c29_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==30) {
    c30_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==31) {
    c31_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==32) {
    c32_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==33) {
    c33_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==34) {
    c34_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==35) {
    c35_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==36) {
    c36_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==37) {
    c37_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==38) {
    c38_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==39) {
    c39_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==40) {
    c40_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==41) {
    c41_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==42) {
    c42_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==43) {
    c43_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==44) {
    c44_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==45) {
    c45_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==46) {
    c46_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==47) {
    c47_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==48) {
    c48_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==49) {
    c49_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==50) {
    c50_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==51) {
    c51_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==52) {
    c52_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==53) {
    c53_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==55) {
    c55_FingerEAERCtrl_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  return 0;
}

unsigned int sf_FingerEAERCtrl_process_testpoint_info_call( int nlhs, mxArray *
  plhs[], int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[32];
  char machineName[128];
  if (nrhs < 3 || !mxIsChar(prhs[0]) || !mxIsChar(prhs[1]))
    return 0;

  /* Possible call to get testpoint info. */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_testpoint_info"))
    return 0;
  mxGetString(prhs[1], machineName, sizeof(machineName)/sizeof(char));
  machineName[(sizeof(machineName)/sizeof(char)-1)] = '\0';
  if (!strcmp(machineName, "FingerEAERCtrl")) {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[2]);
    switch (chartFileNumber) {
     case 1:
      {
        extern mxArray *sf_c1_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c1_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 2:
      {
        extern mxArray *sf_c2_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c2_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 3:
      {
        extern mxArray *sf_c3_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c3_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 4:
      {
        extern mxArray *sf_c4_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c4_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 5:
      {
        extern mxArray *sf_c5_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c5_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 6:
      {
        extern mxArray *sf_c6_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c6_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 7:
      {
        extern mxArray *sf_c7_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c7_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 8:
      {
        extern mxArray *sf_c8_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c8_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 9:
      {
        extern mxArray *sf_c9_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c9_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 10:
      {
        extern mxArray *sf_c10_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c10_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 11:
      {
        extern mxArray *sf_c11_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c11_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 12:
      {
        extern mxArray *sf_c12_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c12_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 13:
      {
        extern mxArray *sf_c13_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c13_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 14:
      {
        extern mxArray *sf_c14_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c14_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 15:
      {
        extern mxArray *sf_c15_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c15_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 16:
      {
        extern mxArray *sf_c16_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c16_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 17:
      {
        extern mxArray *sf_c17_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c17_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 18:
      {
        extern mxArray *sf_c18_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c18_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 19:
      {
        extern mxArray *sf_c19_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c19_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 20:
      {
        extern mxArray *sf_c20_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c20_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 21:
      {
        extern mxArray *sf_c21_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c21_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 22:
      {
        extern mxArray *sf_c22_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c22_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 23:
      {
        extern mxArray *sf_c23_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c23_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 24:
      {
        extern mxArray *sf_c24_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c24_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 25:
      {
        extern mxArray *sf_c25_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c25_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 26:
      {
        extern mxArray *sf_c26_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c26_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 27:
      {
        extern mxArray *sf_c27_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c27_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 28:
      {
        extern mxArray *sf_c28_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c28_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 29:
      {
        extern mxArray *sf_c29_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c29_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 30:
      {
        extern mxArray *sf_c30_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c30_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 31:
      {
        extern mxArray *sf_c31_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c31_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 32:
      {
        extern mxArray *sf_c32_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c32_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 33:
      {
        extern mxArray *sf_c33_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c33_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 34:
      {
        extern mxArray *sf_c34_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c34_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 35:
      {
        extern mxArray *sf_c35_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c35_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 36:
      {
        extern mxArray *sf_c36_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c36_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 37:
      {
        extern mxArray *sf_c37_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c37_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 38:
      {
        extern mxArray *sf_c38_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c38_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 39:
      {
        extern mxArray *sf_c39_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c39_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 40:
      {
        extern mxArray *sf_c40_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c40_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 41:
      {
        extern mxArray *sf_c41_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c41_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 42:
      {
        extern mxArray *sf_c42_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c42_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 43:
      {
        extern mxArray *sf_c43_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c43_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 44:
      {
        extern mxArray *sf_c44_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c44_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 45:
      {
        extern mxArray *sf_c45_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c45_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 46:
      {
        extern mxArray *sf_c46_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c46_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 47:
      {
        extern mxArray *sf_c47_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c47_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 48:
      {
        extern mxArray *sf_c48_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c48_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 49:
      {
        extern mxArray *sf_c49_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c49_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 50:
      {
        extern mxArray *sf_c50_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c50_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 51:
      {
        extern mxArray *sf_c51_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c51_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 52:
      {
        extern mxArray *sf_c52_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c52_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 53:
      {
        extern mxArray *sf_c53_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c53_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     case 55:
      {
        extern mxArray *sf_c55_FingerEAERCtrl_get_testpoint_info(void);
        plhs[0] = sf_c55_FingerEAERCtrl_get_testpoint_info();
        break;
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }

    return 1;
  }

  return 0;

#else

  return 0;

#endif

}

unsigned int sf_FingerEAERCtrl_process_check_sum_call( int nlhs, mxArray * plhs[],
  int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[20];
  if (nrhs<1 || !mxIsChar(prhs[0]) )
    return 0;

  /* Possible call to get the checksum */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"sf_get_check_sum"))
    return 0;
  plhs[0] = mxCreateDoubleMatrix( 1,4,mxREAL);
  if (nrhs>1 && mxIsChar(prhs[1])) {
    mxGetString(prhs[1], commandName,sizeof(commandName)/sizeof(char));
    commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
    if (!strcmp(commandName,"machine")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(2318493249U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(2074269535U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1519241959U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1736285008U);
    } else if (!strcmp(commandName,"exportedFcn")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(0U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(0U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(0U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(0U);
    } else if (!strcmp(commandName,"makefile")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1883592890U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(2037672282U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3808946394U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(4059342027U);
    } else if (nrhs==3 && !strcmp(commandName,"chart")) {
      unsigned int chartFileNumber;
      chartFileNumber = (unsigned int)mxGetScalar(prhs[2]);
      switch (chartFileNumber) {
       case 1:
        {
          extern void sf_c1_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c1_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 2:
        {
          extern void sf_c2_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c2_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 3:
        {
          extern void sf_c3_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c3_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 4:
        {
          extern void sf_c4_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c4_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 5:
        {
          extern void sf_c5_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c5_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 6:
        {
          extern void sf_c6_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c6_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 7:
        {
          extern void sf_c7_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c7_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 8:
        {
          extern void sf_c8_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c8_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 9:
        {
          extern void sf_c9_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c9_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 10:
        {
          extern void sf_c10_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c10_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 11:
        {
          extern void sf_c11_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c11_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 12:
        {
          extern void sf_c12_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c12_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 13:
        {
          extern void sf_c13_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c13_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 14:
        {
          extern void sf_c14_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c14_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 15:
        {
          extern void sf_c15_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c15_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 16:
        {
          extern void sf_c16_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c16_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 17:
        {
          extern void sf_c17_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c17_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 18:
        {
          extern void sf_c18_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c18_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 19:
        {
          extern void sf_c19_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c19_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 20:
        {
          extern void sf_c20_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c20_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 21:
        {
          extern void sf_c21_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c21_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 22:
        {
          extern void sf_c22_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c22_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 23:
        {
          extern void sf_c23_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c23_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 24:
        {
          extern void sf_c24_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c24_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 25:
        {
          extern void sf_c25_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c25_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 26:
        {
          extern void sf_c26_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c26_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 27:
        {
          extern void sf_c27_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c27_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 28:
        {
          extern void sf_c28_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c28_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 29:
        {
          extern void sf_c29_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c29_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 30:
        {
          extern void sf_c30_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c30_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 31:
        {
          extern void sf_c31_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c31_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 32:
        {
          extern void sf_c32_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c32_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 33:
        {
          extern void sf_c33_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c33_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 34:
        {
          extern void sf_c34_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c34_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 35:
        {
          extern void sf_c35_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c35_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 36:
        {
          extern void sf_c36_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c36_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 37:
        {
          extern void sf_c37_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c37_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 38:
        {
          extern void sf_c38_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c38_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 39:
        {
          extern void sf_c39_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c39_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 40:
        {
          extern void sf_c40_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c40_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 41:
        {
          extern void sf_c41_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c41_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 42:
        {
          extern void sf_c42_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c42_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 43:
        {
          extern void sf_c43_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c43_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 44:
        {
          extern void sf_c44_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c44_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 45:
        {
          extern void sf_c45_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c45_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 46:
        {
          extern void sf_c46_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c46_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 47:
        {
          extern void sf_c47_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c47_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 48:
        {
          extern void sf_c48_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c48_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 49:
        {
          extern void sf_c49_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c49_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 50:
        {
          extern void sf_c50_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c50_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 51:
        {
          extern void sf_c51_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c51_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 52:
        {
          extern void sf_c52_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c52_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 53:
        {
          extern void sf_c53_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c53_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       case 55:
        {
          extern void sf_c55_FingerEAERCtrl_get_check_sum(mxArray *plhs[]);
          sf_c55_FingerEAERCtrl_get_check_sum(plhs);
          break;
        }

       default:
        ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(0.0);
      }
    } else if (!strcmp(commandName,"target")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(4275977279U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(2171188014U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(765069457U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1649229680U);
    } else {
      return 0;
    }
  } else {
    ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(2774395068U);
    ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(249553232U);
    ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1696497474U);
    ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(442295539U);
  }

  return 1;

#else

  return 0;

#endif

}

unsigned int sf_FingerEAERCtrl_autoinheritance_info( int nlhs, mxArray * plhs[],
  int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[32];
  char aiChksum[64];
  if (nrhs<3 || !mxIsChar(prhs[0]) )
    return 0;

  /* Possible call to get the autoinheritance_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_autoinheritance_info"))
    return 0;
  mxGetString(prhs[2], aiChksum,sizeof(aiChksum)/sizeof(char));
  aiChksum[(sizeof(aiChksum)/sizeof(char)-1)] = '\0';

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     case 1:
      {
        if (strcmp(aiChksum, "hsOjpPt4n9H2j7r9zASn4") == 0) {
          extern mxArray *sf_c1_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c1_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 2:
      {
        if (strcmp(aiChksum, "ZhVa8sJAySnsW7mE5RsHlF") == 0) {
          extern mxArray *sf_c2_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c2_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 3:
      {
        if (strcmp(aiChksum, "TpMxT63LDTWRvc0OL1whhG") == 0) {
          extern mxArray *sf_c3_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c3_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 4:
      {
        if (strcmp(aiChksum, "i4Im7qq43Xm7Cww27RKnMH") == 0) {
          extern mxArray *sf_c4_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c4_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 5:
      {
        if (strcmp(aiChksum, "7NEdiQtmOeupMt8dLEnjvB") == 0) {
          extern mxArray *sf_c5_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c5_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 6:
      {
        if (strcmp(aiChksum, "ngq99ukKKUkBRuipt432eE") == 0) {
          extern mxArray *sf_c6_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c6_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 7:
      {
        if (strcmp(aiChksum, "WsYrYbSYVLPFCVHvfVGSVH") == 0) {
          extern mxArray *sf_c7_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c7_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 8:
      {
        if (strcmp(aiChksum, "ZBuYwXUSKWjfvrh8gTg3GC") == 0) {
          extern mxArray *sf_c8_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c8_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 9:
      {
        if (strcmp(aiChksum, "6TfwbfaSipTGukNyqqbPw") == 0) {
          extern mxArray *sf_c9_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c9_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 10:
      {
        if (strcmp(aiChksum, "EfhZG5g2QEs7D3vF20ILeH") == 0) {
          extern mxArray *sf_c10_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c10_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 11:
      {
        if (strcmp(aiChksum, "aqJcqHB8eLdm2N3O7BtGDH") == 0) {
          extern mxArray *sf_c11_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c11_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 12:
      {
        if (strcmp(aiChksum, "aqJcqHB8eLdm2N3O7BtGDH") == 0) {
          extern mxArray *sf_c12_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c12_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 13:
      {
        if (strcmp(aiChksum, "aqJcqHB8eLdm2N3O7BtGDH") == 0) {
          extern mxArray *sf_c13_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c13_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 14:
      {
        if (strcmp(aiChksum, "ZBuYwXUSKWjfvrh8gTg3GC") == 0) {
          extern mxArray *sf_c14_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c14_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 15:
      {
        if (strcmp(aiChksum, "ZBuYwXUSKWjfvrh8gTg3GC") == 0) {
          extern mxArray *sf_c15_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c15_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 16:
      {
        if (strcmp(aiChksum, "ZBuYwXUSKWjfvrh8gTg3GC") == 0) {
          extern mxArray *sf_c16_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c16_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 17:
      {
        if (strcmp(aiChksum, "ZBuYwXUSKWjfvrh8gTg3GC") == 0) {
          extern mxArray *sf_c17_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c17_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 18:
      {
        if (strcmp(aiChksum, "7NEdiQtmOeupMt8dLEnjvB") == 0) {
          extern mxArray *sf_c18_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c18_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 19:
      {
        if (strcmp(aiChksum, "i4Im7qq43Xm7Cww27RKnMH") == 0) {
          extern mxArray *sf_c19_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c19_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 20:
      {
        if (strcmp(aiChksum, "ngq99ukKKUkBRuipt432eE") == 0) {
          extern mxArray *sf_c20_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c20_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 21:
      {
        if (strcmp(aiChksum, "WsYrYbSYVLPFCVHvfVGSVH") == 0) {
          extern mxArray *sf_c21_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c21_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 22:
      {
        if (strcmp(aiChksum, "sFitMufp11q93tm4KDgKqG") == 0) {
          extern mxArray *sf_c22_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c22_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 23:
      {
        if (strcmp(aiChksum, "l7Mla1MgURT76vgceX2I6C") == 0) {
          extern mxArray *sf_c23_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c23_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 24:
      {
        if (strcmp(aiChksum, "hsOjpPt4n9H2j7r9zASn4") == 0) {
          extern mxArray *sf_c24_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c24_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 25:
      {
        if (strcmp(aiChksum, "TpMxT63LDTWRvc0OL1whhG") == 0) {
          extern mxArray *sf_c25_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c25_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 26:
      {
        if (strcmp(aiChksum, "DaaJcGnwUgOgTR1vFzHjpG") == 0) {
          extern mxArray *sf_c26_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c26_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 27:
      {
        if (strcmp(aiChksum, "94c93SwoY4HoPaZ9y1rE5B") == 0) {
          extern mxArray *sf_c27_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c27_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 28:
      {
        if (strcmp(aiChksum, "ngq99ukKKUkBRuipt432eE") == 0) {
          extern mxArray *sf_c28_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c28_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 29:
      {
        if (strcmp(aiChksum, "jvvRYg7ET4AnIsktC4vdTC") == 0) {
          extern mxArray *sf_c29_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c29_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 30:
      {
        if (strcmp(aiChksum, "Xe2M7b5AADArAXeKlLxRTE") == 0) {
          extern mxArray *sf_c30_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c30_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 31:
      {
        if (strcmp(aiChksum, "Z7m7DwW0h6HPzS9Q5431XC") == 0) {
          extern mxArray *sf_c31_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c31_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 32:
      {
        if (strcmp(aiChksum, "sdv2UJ5En9wuhXQ33tXpzD") == 0) {
          extern mxArray *sf_c32_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c32_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 33:
      {
        if (strcmp(aiChksum, "sdv2UJ5En9wuhXQ33tXpzD") == 0) {
          extern mxArray *sf_c33_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c33_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 34:
      {
        if (strcmp(aiChksum, "94c93SwoY4HoPaZ9y1rE5B") == 0) {
          extern mxArray *sf_c34_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c34_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 35:
      {
        if (strcmp(aiChksum, "Lmo50c9o8XIUj5BTm4PEHD") == 0) {
          extern mxArray *sf_c35_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c35_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 36:
      {
        if (strcmp(aiChksum, "ngq99ukKKUkBRuipt432eE") == 0) {
          extern mxArray *sf_c36_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c36_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 37:
      {
        if (strcmp(aiChksum, "DNvlT9OBycrN5lXmutBGUG") == 0) {
          extern mxArray *sf_c37_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c37_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 38:
      {
        if (strcmp(aiChksum, "jvvRYg7ET4AnIsktC4vdTC") == 0) {
          extern mxArray *sf_c38_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c38_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 39:
      {
        if (strcmp(aiChksum, "lSnzngSX3nfnZ7S70D0V9E") == 0) {
          extern mxArray *sf_c39_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c39_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 40:
      {
        if (strcmp(aiChksum, "OqkyR4eM6H5PBZYixwBA8C") == 0) {
          extern mxArray *sf_c40_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c40_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 41:
      {
        if (strcmp(aiChksum, "ohFZrghzQYdzgkfjrJPVoG") == 0) {
          extern mxArray *sf_c41_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c41_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 42:
      {
        if (strcmp(aiChksum, "GeipqEf2LmeiREpDdJOUWF") == 0) {
          extern mxArray *sf_c42_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c42_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 43:
      {
        if (strcmp(aiChksum, "ZBuYwXUSKWjfvrh8gTg3GC") == 0) {
          extern mxArray *sf_c43_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c43_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 44:
      {
        if (strcmp(aiChksum, "ZBuYwXUSKWjfvrh8gTg3GC") == 0) {
          extern mxArray *sf_c44_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c44_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 45:
      {
        if (strcmp(aiChksum, "ruAV2Cb23vosL2cGyBCFh") == 0) {
          extern mxArray *sf_c45_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c45_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 46:
      {
        if (strcmp(aiChksum, "sFitMufp11q93tm4KDgKqG") == 0) {
          extern mxArray *sf_c46_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c46_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 47:
      {
        if (strcmp(aiChksum, "l7Mla1MgURT76vgceX2I6C") == 0) {
          extern mxArray *sf_c47_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c47_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 48:
      {
        if (strcmp(aiChksum, "UkUstxsYvEcfcgwRy1oO2E") == 0) {
          extern mxArray *sf_c48_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c48_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 49:
      {
        if (strcmp(aiChksum, "Lmo50c9o8XIUj5BTm4PEHD") == 0) {
          extern mxArray *sf_c49_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c49_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 50:
      {
        if (strcmp(aiChksum, "DNvlT9OBycrN5lXmutBGUG") == 0) {
          extern mxArray *sf_c50_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c50_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 51:
      {
        if (strcmp(aiChksum, "lSnzngSX3nfnZ7S70D0V9E") == 0) {
          extern mxArray *sf_c51_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c51_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 52:
      {
        if (strcmp(aiChksum, "OqkyR4eM6H5PBZYixwBA8C") == 0) {
          extern mxArray *sf_c52_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c52_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 53:
      {
        if (strcmp(aiChksum, "ohFZrghzQYdzgkfjrJPVoG") == 0) {
          extern mxArray *sf_c53_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c53_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 55:
      {
        if (strcmp(aiChksum, "UkUstxsYvEcfcgwRy1oO2E") == 0) {
          extern mxArray *sf_c55_FingerEAERCtrl_get_autoinheritance_info(void);
          plhs[0] = sf_c55_FingerEAERCtrl_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;

#else

  return 0;

#endif

}

unsigned int sf_FingerEAERCtrl_get_eml_resolved_functions_info( int nlhs,
  mxArray * plhs[], int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[64];
  if (nrhs<2 || !mxIsChar(prhs[0]))
    return 0;

  /* Possible call to get the get_eml_resolved_functions_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_eml_resolved_functions_info"))
    return 0;

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     case 1:
      {
        extern const mxArray
          *sf_c1_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c1_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 2:
      {
        extern const mxArray
          *sf_c2_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c2_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 3:
      {
        extern const mxArray
          *sf_c3_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c3_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 4:
      {
        extern const mxArray
          *sf_c4_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c4_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 5:
      {
        extern const mxArray
          *sf_c5_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c5_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 6:
      {
        extern const mxArray
          *sf_c6_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c6_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 7:
      {
        extern const mxArray
          *sf_c7_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c7_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 8:
      {
        extern const mxArray
          *sf_c8_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c8_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 9:
      {
        extern const mxArray
          *sf_c9_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c9_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 10:
      {
        extern const mxArray
          *sf_c10_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c10_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 11:
      {
        extern const mxArray
          *sf_c11_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c11_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 12:
      {
        extern const mxArray
          *sf_c12_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c12_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 13:
      {
        extern const mxArray
          *sf_c13_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c13_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 14:
      {
        extern const mxArray
          *sf_c14_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c14_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 15:
      {
        extern const mxArray
          *sf_c15_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c15_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 16:
      {
        extern const mxArray
          *sf_c16_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c16_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 17:
      {
        extern const mxArray
          *sf_c17_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c17_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 18:
      {
        extern const mxArray
          *sf_c18_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c18_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 19:
      {
        extern const mxArray
          *sf_c19_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c19_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 20:
      {
        extern const mxArray
          *sf_c20_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c20_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 21:
      {
        extern const mxArray
          *sf_c21_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c21_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 22:
      {
        extern const mxArray
          *sf_c22_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c22_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 23:
      {
        extern const mxArray
          *sf_c23_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c23_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 24:
      {
        extern const mxArray
          *sf_c24_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c24_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 25:
      {
        extern const mxArray
          *sf_c25_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c25_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 26:
      {
        extern const mxArray
          *sf_c26_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c26_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 27:
      {
        extern const mxArray
          *sf_c27_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c27_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 28:
      {
        extern const mxArray
          *sf_c28_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c28_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 29:
      {
        extern const mxArray
          *sf_c29_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c29_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 30:
      {
        extern const mxArray
          *sf_c30_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c30_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 31:
      {
        extern const mxArray
          *sf_c31_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c31_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 32:
      {
        extern const mxArray
          *sf_c32_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c32_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 33:
      {
        extern const mxArray
          *sf_c33_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c33_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 34:
      {
        extern const mxArray
          *sf_c34_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c34_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 35:
      {
        extern const mxArray
          *sf_c35_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c35_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 36:
      {
        extern const mxArray
          *sf_c36_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c36_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 37:
      {
        extern const mxArray
          *sf_c37_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c37_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 38:
      {
        extern const mxArray
          *sf_c38_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c38_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 39:
      {
        extern const mxArray
          *sf_c39_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c39_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 40:
      {
        extern const mxArray
          *sf_c40_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c40_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 41:
      {
        extern const mxArray
          *sf_c41_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c41_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 42:
      {
        extern const mxArray
          *sf_c42_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c42_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 43:
      {
        extern const mxArray
          *sf_c43_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c43_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 44:
      {
        extern const mxArray
          *sf_c44_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c44_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 45:
      {
        extern const mxArray
          *sf_c45_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c45_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 46:
      {
        extern const mxArray
          *sf_c46_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c46_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 47:
      {
        extern const mxArray
          *sf_c47_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c47_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 48:
      {
        extern const mxArray
          *sf_c48_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c48_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 49:
      {
        extern const mxArray
          *sf_c49_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c49_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 50:
      {
        extern const mxArray
          *sf_c50_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c50_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 51:
      {
        extern const mxArray
          *sf_c51_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c51_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 52:
      {
        extern const mxArray
          *sf_c52_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c52_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 53:
      {
        extern const mxArray
          *sf_c53_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c53_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 55:
      {
        extern const mxArray
          *sf_c55_FingerEAERCtrl_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c55_FingerEAERCtrl_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;

#else

  return 0;

#endif

}

void FingerEAERCtrl_debug_initialize(void)
{
  _FingerEAERCtrlMachineNumber_ = sf_debug_initialize_machine("FingerEAERCtrl",
    "sfun",0,54,0,0,0);
  sf_debug_set_machine_event_thresholds(_FingerEAERCtrlMachineNumber_,0,0);
  sf_debug_set_machine_data_thresholds(_FingerEAERCtrlMachineNumber_,0);
}

void FingerEAERCtrl_register_exported_symbols(SimStruct* S)
{
}

static mxArray* sRtwOptimizationInfoStruct= NULL;
mxArray* load_FingerEAERCtrl_optimization_info(void)
{
  if (sRtwOptimizationInfoStruct==NULL) {
    sRtwOptimizationInfoStruct = sf_load_rtw_optimization_info("FingerEAERCtrl",
      "FingerEAERCtrl");
    mexMakeArrayPersistent(sRtwOptimizationInfoStruct);
  }

  return(sRtwOptimizationInfoStruct);
}

void unload_FingerEAERCtrl_optimization_info(void)
{
  if (sRtwOptimizationInfoStruct!=NULL) {
    mxDestroyArray(sRtwOptimizationInfoStruct);
    sRtwOptimizationInfoStruct = NULL;
  }
}
