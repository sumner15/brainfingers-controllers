/* Include files */

#include "blascompat32.h"
#include "FingerEAERCtrl_sfun.h"
#include "c54_FingerEAERCtrl.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "FingerEAERCtrl_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static const char * c54_debug_family_names[15] = { "startT", "Pr", "T", "nargin",
  "nargout", "Pd", "th", "dur", "t", "Phold_", "state_", "Pactual_", "des",
  "Phold", "state" };

/* Function Declarations */
static void initialize_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance);
static void initialize_params_c54_FingerEAERCtrl
  (SFc54_FingerEAERCtrlInstanceStruct *chartInstance);
static void enable_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance);
static void disable_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance);
static void c54_update_debugger_state_c54_FingerEAERCtrl
  (SFc54_FingerEAERCtrlInstanceStruct *chartInstance);
static void ext_mode_exec_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct *
  chartInstance);
static const mxArray *get_sim_state_c54_FingerEAERCtrl
  (SFc54_FingerEAERCtrlInstanceStruct *chartInstance);
static void set_sim_state_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct *
  chartInstance, const mxArray *c54_st);
static void finalize_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance);
static void sf_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance);
static void c54_chartstep_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct *
  chartInstance);
static void initSimStructsc54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct *
  chartInstance);
static void init_script_number_translation(uint32_T c54_machineNumber, uint32_T
  c54_chartNumber);
static const mxArray *c54_sf_marshallOut(void *chartInstanceVoid, void
  *c54_inData);
static real_T c54_emlrt_marshallIn(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance, const mxArray *c54_state, const char_T *c54_identifier);
static real_T c54_b_emlrt_marshallIn(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance, const mxArray *c54_u, const emlrtMsgIdentifier *c54_parentId);
static void c54_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c54_mxArrayInData, const char_T *c54_varName, void *c54_outData);
static const mxArray *c54_b_sf_marshallOut(void *chartInstanceVoid, void
  *c54_inData);
static void c54_c_emlrt_marshallIn(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance, const mxArray *c54_des, const char_T *c54_identifier, real_T
  c54_y[3]);
static void c54_d_emlrt_marshallIn(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance, const mxArray *c54_u, const emlrtMsgIdentifier *c54_parentId,
  real_T c54_y[3]);
static void c54_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c54_mxArrayInData, const char_T *c54_varName, void *c54_outData);
static real_T c54_mpower(SFc54_FingerEAERCtrlInstanceStruct *chartInstance,
  real_T c54_a);
static void c54_eml_scalar_eg(SFc54_FingerEAERCtrlInstanceStruct *chartInstance);
static real_T c54_b_mpower(SFc54_FingerEAERCtrlInstanceStruct *chartInstance,
  real_T c54_a);
static real_T c54_c_mpower(SFc54_FingerEAERCtrlInstanceStruct *chartInstance,
  real_T c54_a);
static real_T c54_d_mpower(SFc54_FingerEAERCtrlInstanceStruct *chartInstance,
  real_T c54_a);
static const mxArray *c54_c_sf_marshallOut(void *chartInstanceVoid, void
  *c54_inData);
static int32_T c54_e_emlrt_marshallIn(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance, const mxArray *c54_u, const emlrtMsgIdentifier *c54_parentId);
static void c54_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c54_mxArrayInData, const char_T *c54_varName, void *c54_outData);
static uint8_T c54_f_emlrt_marshallIn(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance, const mxArray *c54_is_active_c54_FingerEAERCtrl, const char_T *
  c54_identifier);
static uint8_T c54_g_emlrt_marshallIn(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance, const mxArray *c54_u, const emlrtMsgIdentifier *c54_parentId);
static void init_dsm_address_info(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance)
{
  int32_T *c54_sfEvent;
  uint8_T *c54_is_active_c54_FingerEAERCtrl;
  c54_is_active_c54_FingerEAERCtrl = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c54_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  *c54_sfEvent = CALL_EVENT;
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  *c54_is_active_c54_FingerEAERCtrl = 0U;
}

static void initialize_params_c54_FingerEAERCtrl
  (SFc54_FingerEAERCtrlInstanceStruct *chartInstance)
{
}

static void enable_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c54_update_debugger_state_c54_FingerEAERCtrl
  (SFc54_FingerEAERCtrlInstanceStruct *chartInstance)
{
}

static void ext_mode_exec_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct *
  chartInstance)
{
  c54_update_debugger_state_c54_FingerEAERCtrl(chartInstance);
}

static const mxArray *get_sim_state_c54_FingerEAERCtrl
  (SFc54_FingerEAERCtrlInstanceStruct *chartInstance)
{
  const mxArray *c54_st;
  const mxArray *c54_y = NULL;
  real_T c54_hoistedGlobal;
  real_T c54_u;
  const mxArray *c54_b_y = NULL;
  int32_T c54_i0;
  real_T c54_b_u[3];
  const mxArray *c54_c_y = NULL;
  real_T c54_b_hoistedGlobal;
  real_T c54_c_u;
  const mxArray *c54_d_y = NULL;
  uint8_T c54_c_hoistedGlobal;
  uint8_T c54_d_u;
  const mxArray *c54_e_y = NULL;
  real_T *c54_Phold;
  real_T *c54_state;
  uint8_T *c54_is_active_c54_FingerEAERCtrl;
  real_T (*c54_des)[3];
  c54_state = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c54_Phold = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c54_des = (real_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
  c54_is_active_c54_FingerEAERCtrl = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c54_st = NULL;
  c54_st = NULL;
  c54_y = NULL;
  sf_mex_assign(&c54_y, sf_mex_createcellarray(4), FALSE);
  c54_hoistedGlobal = *c54_Phold;
  c54_u = c54_hoistedGlobal;
  c54_b_y = NULL;
  sf_mex_assign(&c54_b_y, sf_mex_create("y", &c54_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c54_y, 0, c54_b_y);
  for (c54_i0 = 0; c54_i0 < 3; c54_i0++) {
    c54_b_u[c54_i0] = (*c54_des)[c54_i0];
  }

  c54_c_y = NULL;
  sf_mex_assign(&c54_c_y, sf_mex_create("y", c54_b_u, 0, 0U, 1U, 0U, 1, 3),
                FALSE);
  sf_mex_setcell(c54_y, 1, c54_c_y);
  c54_b_hoistedGlobal = *c54_state;
  c54_c_u = c54_b_hoistedGlobal;
  c54_d_y = NULL;
  sf_mex_assign(&c54_d_y, sf_mex_create("y", &c54_c_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c54_y, 2, c54_d_y);
  c54_c_hoistedGlobal = *c54_is_active_c54_FingerEAERCtrl;
  c54_d_u = c54_c_hoistedGlobal;
  c54_e_y = NULL;
  sf_mex_assign(&c54_e_y, sf_mex_create("y", &c54_d_u, 3, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c54_y, 3, c54_e_y);
  sf_mex_assign(&c54_st, c54_y, FALSE);
  return c54_st;
}

static void set_sim_state_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct *
  chartInstance, const mxArray *c54_st)
{
  const mxArray *c54_u;
  real_T c54_dv0[3];
  int32_T c54_i1;
  boolean_T *c54_doneDoubleBufferReInit;
  real_T *c54_Phold;
  real_T *c54_state;
  uint8_T *c54_is_active_c54_FingerEAERCtrl;
  real_T (*c54_des)[3];
  c54_state = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c54_Phold = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c54_des = (real_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
  c54_is_active_c54_FingerEAERCtrl = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c54_doneDoubleBufferReInit = (boolean_T *)ssGetDWork(chartInstance->S, 2);
  *c54_doneDoubleBufferReInit = TRUE;
  c54_u = sf_mex_dup(c54_st);
  *c54_Phold = c54_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c54_u, 0)), "Phold");
  c54_c_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c54_u, 1)),
    "des", c54_dv0);
  for (c54_i1 = 0; c54_i1 < 3; c54_i1++) {
    (*c54_des)[c54_i1] = c54_dv0[c54_i1];
  }

  *c54_state = c54_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c54_u, 2)), "state");
  *c54_is_active_c54_FingerEAERCtrl = c54_f_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c54_u, 3)), "is_active_c54_FingerEAERCtrl");
  sf_mex_destroy(&c54_u);
  c54_update_debugger_state_c54_FingerEAERCtrl(chartInstance);
  sf_mex_destroy(&c54_st);
}

static void finalize_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance)
{
}

static void sf_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance)
{
  int32_T c54_i2;
  int32_T *c54_sfEvent;
  real_T *c54_Pd;
  real_T *c54_th;
  real_T *c54_dur;
  real_T *c54_t;
  real_T *c54_Phold_;
  real_T *c54_Phold;
  real_T *c54_state_;
  real_T *c54_state;
  real_T *c54_Pactual_;
  real_T (*c54_des)[3];
  c54_Pactual_ = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
  c54_state = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c54_state_ = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
  c54_Phold = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c54_Phold_ = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c54_t = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c54_des = (real_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
  c54_dur = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c54_th = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c54_Pd = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
  c54_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 50U, *c54_sfEvent);
  _SFD_DATA_RANGE_CHECK(*c54_Pd, 0U);
  _SFD_DATA_RANGE_CHECK(*c54_th, 1U);
  _SFD_DATA_RANGE_CHECK(*c54_dur, 2U);
  for (c54_i2 = 0; c54_i2 < 3; c54_i2++) {
    _SFD_DATA_RANGE_CHECK((*c54_des)[c54_i2], 3U);
  }

  _SFD_DATA_RANGE_CHECK(*c54_t, 4U);
  _SFD_DATA_RANGE_CHECK(*c54_Phold_, 5U);
  _SFD_DATA_RANGE_CHECK(*c54_Phold, 6U);
  _SFD_DATA_RANGE_CHECK(*c54_state_, 7U);
  _SFD_DATA_RANGE_CHECK(*c54_state, 8U);
  _SFD_DATA_RANGE_CHECK(*c54_Pactual_, 9U);
  *c54_sfEvent = CALL_EVENT;
  c54_chartstep_c54_FingerEAERCtrl(chartInstance);
  sf_debug_check_for_state_inconsistency(_FingerEAERCtrlMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber);
}

static void c54_chartstep_c54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct *
  chartInstance)
{
  real_T c54_hoistedGlobal;
  real_T c54_b_hoistedGlobal;
  real_T c54_c_hoistedGlobal;
  real_T c54_d_hoistedGlobal;
  real_T c54_e_hoistedGlobal;
  real_T c54_f_hoistedGlobal;
  real_T c54_g_hoistedGlobal;
  real_T c54_Pd;
  real_T c54_th;
  real_T c54_dur;
  real_T c54_t;
  real_T c54_Phold_;
  real_T c54_state_;
  real_T c54_Pactual_;
  uint32_T c54_debug_family_var_map[15];
  real_T c54_startT;
  real_T c54_Pr;
  real_T c54_T;
  real_T c54_nargin = 7.0;
  real_T c54_nargout = 3.0;
  real_T c54_des[3];
  real_T c54_Phold;
  real_T c54_state;
  real_T c54_b;
  real_T c54_y;
  real_T c54_a;
  real_T c54_b_b;
  real_T c54_b_y;
  real_T c54_A;
  real_T c54_B;
  real_T c54_x;
  real_T c54_c_y;
  real_T c54_b_x;
  real_T c54_d_y;
  real_T c54_e_y;
  real_T c54_c_b;
  real_T c54_f_y;
  real_T c54_b_a;
  real_T c54_d_b;
  real_T c54_g_y;
  real_T c54_b_A;
  real_T c54_b_B;
  real_T c54_c_x;
  real_T c54_h_y;
  real_T c54_d_x;
  real_T c54_i_y;
  real_T c54_j_y;
  real_T c54_e_b;
  real_T c54_k_y;
  real_T c54_c_a;
  real_T c54_f_b;
  real_T c54_l_y;
  real_T c54_c_A;
  real_T c54_c_B;
  real_T c54_e_x;
  real_T c54_m_y;
  real_T c54_f_x;
  real_T c54_n_y;
  real_T c54_o_y;
  real_T c54_g_b;
  real_T c54_p_y;
  real_T c54_d_a;
  real_T c54_h_b;
  real_T c54_q_y;
  real_T c54_d_A;
  real_T c54_d_B;
  real_T c54_g_x;
  real_T c54_r_y;
  real_T c54_h_x;
  real_T c54_s_y;
  real_T c54_t_y;
  real_T c54_i_b;
  real_T c54_u_y;
  real_T c54_e_a;
  real_T c54_j_b;
  real_T c54_v_y;
  real_T c54_e_A;
  real_T c54_e_B;
  real_T c54_i_x;
  real_T c54_w_y;
  real_T c54_j_x;
  real_T c54_x_y;
  real_T c54_y_y;
  real_T c54_k_b;
  real_T c54_ab_y;
  real_T c54_f_a;
  real_T c54_l_b;
  real_T c54_bb_y;
  real_T c54_f_A;
  real_T c54_f_B;
  real_T c54_k_x;
  real_T c54_cb_y;
  real_T c54_l_x;
  real_T c54_db_y;
  real_T c54_eb_y;
  real_T c54_m_b;
  real_T c54_fb_y;
  real_T c54_g_a;
  real_T c54_n_b;
  real_T c54_gb_y;
  real_T c54_g_A;
  real_T c54_g_B;
  real_T c54_m_x;
  real_T c54_hb_y;
  real_T c54_n_x;
  real_T c54_ib_y;
  real_T c54_jb_y;
  real_T c54_o_b;
  real_T c54_kb_y;
  real_T c54_h_a;
  real_T c54_p_b;
  real_T c54_lb_y;
  real_T c54_h_A;
  real_T c54_h_B;
  real_T c54_o_x;
  real_T c54_mb_y;
  real_T c54_p_x;
  real_T c54_nb_y;
  real_T c54_ob_y;
  real_T c54_q_b;
  real_T c54_pb_y;
  real_T c54_i_a;
  real_T c54_r_b;
  real_T c54_qb_y;
  real_T c54_i_A;
  real_T c54_i_B;
  real_T c54_q_x;
  real_T c54_rb_y;
  real_T c54_r_x;
  real_T c54_sb_y;
  real_T c54_tb_y;
  int32_T c54_i3;
  real_T *c54_b_state;
  real_T *c54_b_Phold;
  real_T *c54_b_Pactual_;
  real_T *c54_b_state_;
  real_T *c54_b_Phold_;
  real_T *c54_b_t;
  real_T *c54_b_dur;
  real_T *c54_b_th;
  real_T *c54_b_Pd;
  real_T (*c54_b_des)[3];
  int32_T *c54_sfEvent;
  c54_b_Pactual_ = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
  c54_b_state = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c54_b_state_ = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
  c54_b_Phold = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c54_b_Phold_ = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c54_b_t = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c54_b_des = (real_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
  c54_b_dur = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c54_b_th = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c54_b_Pd = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
  c54_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 50U, *c54_sfEvent);
  c54_hoistedGlobal = *c54_b_Pd;
  c54_b_hoistedGlobal = *c54_b_th;
  c54_c_hoistedGlobal = *c54_b_dur;
  c54_d_hoistedGlobal = *c54_b_t;
  c54_e_hoistedGlobal = *c54_b_Phold_;
  c54_f_hoistedGlobal = *c54_b_state_;
  c54_g_hoistedGlobal = *c54_b_Pactual_;
  c54_Pd = c54_hoistedGlobal;
  c54_th = c54_b_hoistedGlobal;
  c54_dur = c54_c_hoistedGlobal;
  c54_t = c54_d_hoistedGlobal;
  c54_Phold_ = c54_e_hoistedGlobal;
  c54_state_ = c54_f_hoistedGlobal;
  c54_Pactual_ = c54_g_hoistedGlobal;
  sf_debug_symbol_scope_push_eml(0U, 15U, 15U, c54_debug_family_names,
    c54_debug_family_var_map);
  sf_debug_symbol_scope_add_eml_importable(&c54_startT, 0U, c54_sf_marshallOut,
    c54_sf_marshallIn);
  sf_debug_symbol_scope_add_eml_importable(&c54_Pr, 1U, c54_sf_marshallOut,
    c54_sf_marshallIn);
  sf_debug_symbol_scope_add_eml_importable(&c54_T, 2U, c54_sf_marshallOut,
    c54_sf_marshallIn);
  sf_debug_symbol_scope_add_eml_importable(&c54_nargin, 3U, c54_sf_marshallOut,
    c54_sf_marshallIn);
  sf_debug_symbol_scope_add_eml_importable(&c54_nargout, 4U, c54_sf_marshallOut,
    c54_sf_marshallIn);
  sf_debug_symbol_scope_add_eml(&c54_Pd, 5U, c54_sf_marshallOut);
  sf_debug_symbol_scope_add_eml(&c54_th, 6U, c54_sf_marshallOut);
  sf_debug_symbol_scope_add_eml(&c54_dur, 7U, c54_sf_marshallOut);
  sf_debug_symbol_scope_add_eml(&c54_t, 8U, c54_sf_marshallOut);
  sf_debug_symbol_scope_add_eml(&c54_Phold_, 9U, c54_sf_marshallOut);
  sf_debug_symbol_scope_add_eml(&c54_state_, 10U, c54_sf_marshallOut);
  sf_debug_symbol_scope_add_eml(&c54_Pactual_, 11U, c54_sf_marshallOut);
  sf_debug_symbol_scope_add_eml_importable(c54_des, 12U, c54_b_sf_marshallOut,
    c54_b_sf_marshallIn);
  sf_debug_symbol_scope_add_eml_importable(&c54_Phold, 13U, c54_sf_marshallOut,
    c54_sf_marshallIn);
  sf_debug_symbol_scope_add_eml_importable(&c54_state, 14U, c54_sf_marshallOut,
    c54_sf_marshallIn);
  CV_EML_FCN(0, 0);
  _SFD_EML_CALL(0U, *c54_sfEvent, 6);
  c54_startT = c54_th - c54_dur;
  _SFD_EML_CALL(0U, *c54_sfEvent, 8);
  c54_Pr = c54_Pd - c54_Phold_;
  _SFD_EML_CALL(0U, *c54_sfEvent, 9);
  c54_Phold = c54_Phold_;
  _SFD_EML_CALL(0U, *c54_sfEvent, 10);
  c54_state = c54_state_;
  _SFD_EML_CALL(0U, *c54_sfEvent, 11);
  switch ((int32_T)_SFD_INTEGER_CHECK("state_", c54_state_)) {
   case 0:
    CV_EML_SWITCH(0, 1, 0, 1);
    _SFD_EML_CALL(0U, *c54_sfEvent, 15);
    c54_des[0] = c54_Pactual_;
    c54_des[1] = 0.0;
    c54_des[2] = 0.0;
    _SFD_EML_CALL(0U, *c54_sfEvent, 16);
    if (CV_EML_IF(0, 1, 0, c54_t > c54_startT)) {
      _SFD_EML_CALL(0U, *c54_sfEvent, 16);
      c54_state = 1.0;
    }
    break;

   case 1:
    CV_EML_SWITCH(0, 1, 0, 2);
    _SFD_EML_CALL(0U, *c54_sfEvent, 19);
    c54_T = c54_t - c54_startT;
    _SFD_EML_CALL(0U, *c54_sfEvent, 20);
    c54_b = c54_Pr;
    c54_y = 10.0 * c54_b;
    c54_a = c54_y;
    c54_b_b = c54_mpower(chartInstance, c54_T);
    c54_b_y = c54_a * c54_b_b;
    c54_A = c54_b_y;
    c54_B = c54_mpower(chartInstance, c54_dur);
    c54_x = c54_A;
    c54_c_y = c54_B;
    c54_b_x = c54_x;
    c54_d_y = c54_c_y;
    c54_e_y = c54_b_x / c54_d_y;
    c54_c_b = c54_Pr;
    c54_f_y = 15.0 * c54_c_b;
    c54_b_a = c54_f_y;
    c54_d_b = c54_b_mpower(chartInstance, c54_T);
    c54_g_y = c54_b_a * c54_d_b;
    c54_b_A = c54_g_y;
    c54_b_B = c54_b_mpower(chartInstance, c54_dur);
    c54_c_x = c54_b_A;
    c54_h_y = c54_b_B;
    c54_d_x = c54_c_x;
    c54_i_y = c54_h_y;
    c54_j_y = c54_d_x / c54_i_y;
    c54_e_b = c54_Pr;
    c54_k_y = 6.0 * c54_e_b;
    c54_c_a = c54_k_y;
    c54_f_b = c54_c_mpower(chartInstance, c54_T);
    c54_l_y = c54_c_a * c54_f_b;
    c54_c_A = c54_l_y;
    c54_c_B = c54_c_mpower(chartInstance, c54_dur);
    c54_e_x = c54_c_A;
    c54_m_y = c54_c_B;
    c54_f_x = c54_e_x;
    c54_n_y = c54_m_y;
    c54_o_y = c54_f_x / c54_n_y;
    c54_g_b = c54_Pr;
    c54_p_y = 30.0 * c54_g_b;
    c54_d_a = c54_p_y;
    c54_h_b = c54_d_mpower(chartInstance, c54_T);
    c54_q_y = c54_d_a * c54_h_b;
    c54_d_A = c54_q_y;
    c54_d_B = c54_mpower(chartInstance, c54_dur);
    c54_g_x = c54_d_A;
    c54_r_y = c54_d_B;
    c54_h_x = c54_g_x;
    c54_s_y = c54_r_y;
    c54_t_y = c54_h_x / c54_s_y;
    c54_i_b = c54_Pr;
    c54_u_y = 60.0 * c54_i_b;
    c54_e_a = c54_u_y;
    c54_j_b = c54_mpower(chartInstance, c54_T);
    c54_v_y = c54_e_a * c54_j_b;
    c54_e_A = c54_v_y;
    c54_e_B = c54_b_mpower(chartInstance, c54_dur);
    c54_i_x = c54_e_A;
    c54_w_y = c54_e_B;
    c54_j_x = c54_i_x;
    c54_x_y = c54_w_y;
    c54_y_y = c54_j_x / c54_x_y;
    c54_k_b = c54_Pr;
    c54_ab_y = 30.0 * c54_k_b;
    c54_f_a = c54_ab_y;
    c54_l_b = c54_b_mpower(chartInstance, c54_T);
    c54_bb_y = c54_f_a * c54_l_b;
    c54_f_A = c54_bb_y;
    c54_f_B = c54_c_mpower(chartInstance, c54_dur);
    c54_k_x = c54_f_A;
    c54_cb_y = c54_f_B;
    c54_l_x = c54_k_x;
    c54_db_y = c54_cb_y;
    c54_eb_y = c54_l_x / c54_db_y;
    c54_m_b = c54_Pr;
    c54_fb_y = 120.0 * c54_m_b;
    c54_g_a = c54_fb_y;
    c54_n_b = c54_mpower(chartInstance, c54_T);
    c54_gb_y = c54_g_a * c54_n_b;
    c54_g_A = c54_gb_y;
    c54_g_B = c54_c_mpower(chartInstance, c54_dur);
    c54_m_x = c54_g_A;
    c54_hb_y = c54_g_B;
    c54_n_x = c54_m_x;
    c54_ib_y = c54_hb_y;
    c54_jb_y = c54_n_x / c54_ib_y;
    c54_o_b = c54_Pr;
    c54_kb_y = 180.0 * c54_o_b;
    c54_h_a = c54_kb_y;
    c54_p_b = c54_d_mpower(chartInstance, c54_T);
    c54_lb_y = c54_h_a * c54_p_b;
    c54_h_A = c54_lb_y;
    c54_h_B = c54_b_mpower(chartInstance, c54_dur);
    c54_o_x = c54_h_A;
    c54_mb_y = c54_h_B;
    c54_p_x = c54_o_x;
    c54_nb_y = c54_mb_y;
    c54_ob_y = c54_p_x / c54_nb_y;
    c54_q_b = c54_Pr;
    c54_pb_y = 60.0 * c54_q_b;
    c54_i_a = c54_pb_y;
    c54_r_b = c54_T;
    c54_qb_y = c54_i_a * c54_r_b;
    c54_i_A = c54_qb_y;
    c54_i_B = c54_mpower(chartInstance, c54_dur);
    c54_q_x = c54_i_A;
    c54_rb_y = c54_i_B;
    c54_r_x = c54_q_x;
    c54_sb_y = c54_rb_y;
    c54_tb_y = c54_r_x / c54_sb_y;
    c54_des[0] = ((c54_e_y - c54_j_y) + c54_o_y) + c54_Phold_;
    c54_des[1] = (c54_t_y - c54_y_y) + c54_eb_y;
    c54_des[2] = (c54_jb_y - c54_ob_y) + c54_tb_y;
    _SFD_EML_CALL(0U, *c54_sfEvent, 23);
    if (CV_EML_IF(0, 1, 1, c54_t > c54_th)) {
      _SFD_EML_CALL(0U, *c54_sfEvent, 23);
      c54_state = 2.0;
    }
    break;

   case 2:
    CV_EML_SWITCH(0, 1, 0, 3);
    _SFD_EML_CALL(0U, *c54_sfEvent, 26);
    c54_Phold = c54_Pd;
    _SFD_EML_CALL(0U, *c54_sfEvent, 27);
    c54_des[0] = c54_Pd;
    c54_des[1] = 0.0;
    c54_des[2] = 0.0;
    _SFD_EML_CALL(0U, *c54_sfEvent, 28);
    c54_state = 3.0;
    break;

   case 3:
    CV_EML_SWITCH(0, 1, 0, 4);
    _SFD_EML_CALL(0U, *c54_sfEvent, 31);
    c54_des[0] = c54_Phold_;
    c54_des[1] = 0.0;
    c54_des[2] = 0.0;
    _SFD_EML_CALL(0U, *c54_sfEvent, 32);
    if (CV_EML_IF(0, 1, 2, c54_t < c54_startT)) {
      _SFD_EML_CALL(0U, *c54_sfEvent, 32);
      c54_state = 0.0;
    }
    break;

   default:
    CV_EML_SWITCH(0, 1, 0, 0);
    _SFD_EML_CALL(0U, *c54_sfEvent, 34);
    c54_state = 0.0;
    _SFD_EML_CALL(0U, *c54_sfEvent, 35);
    c54_Phold = 0.0;
    _SFD_EML_CALL(0U, *c54_sfEvent, 36);
    c54_des[0] = c54_Phold_;
    c54_des[1] = 0.0;
    c54_des[2] = 0.0;
    break;
  }

  _SFD_EML_CALL(0U, *c54_sfEvent, -36);
  sf_debug_symbol_scope_pop();
  for (c54_i3 = 0; c54_i3 < 3; c54_i3++) {
    (*c54_b_des)[c54_i3] = c54_des[c54_i3];
  }

  *c54_b_Phold = c54_Phold;
  *c54_b_state = c54_state;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 50U, *c54_sfEvent);
}

static void initSimStructsc54_FingerEAERCtrl(SFc54_FingerEAERCtrlInstanceStruct *
  chartInstance)
{
}

static void init_script_number_translation(uint32_T c54_machineNumber, uint32_T
  c54_chartNumber)
{
}

static const mxArray *c54_sf_marshallOut(void *chartInstanceVoid, void
  *c54_inData)
{
  const mxArray *c54_mxArrayOutData = NULL;
  real_T c54_u;
  const mxArray *c54_y = NULL;
  SFc54_FingerEAERCtrlInstanceStruct *chartInstance;
  chartInstance = (SFc54_FingerEAERCtrlInstanceStruct *)chartInstanceVoid;
  c54_mxArrayOutData = NULL;
  c54_u = *(real_T *)c54_inData;
  c54_y = NULL;
  sf_mex_assign(&c54_y, sf_mex_create("y", &c54_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c54_mxArrayOutData, c54_y, FALSE);
  return c54_mxArrayOutData;
}

static real_T c54_emlrt_marshallIn(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance, const mxArray *c54_state, const char_T *c54_identifier)
{
  real_T c54_y;
  emlrtMsgIdentifier c54_thisId;
  c54_thisId.fIdentifier = c54_identifier;
  c54_thisId.fParent = NULL;
  c54_y = c54_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c54_state),
    &c54_thisId);
  sf_mex_destroy(&c54_state);
  return c54_y;
}

static real_T c54_b_emlrt_marshallIn(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance, const mxArray *c54_u, const emlrtMsgIdentifier *c54_parentId)
{
  real_T c54_y;
  real_T c54_d0;
  sf_mex_import(c54_parentId, sf_mex_dup(c54_u), &c54_d0, 1, 0, 0U, 0, 0U, 0);
  c54_y = c54_d0;
  sf_mex_destroy(&c54_u);
  return c54_y;
}

static void c54_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c54_mxArrayInData, const char_T *c54_varName, void *c54_outData)
{
  const mxArray *c54_state;
  const char_T *c54_identifier;
  emlrtMsgIdentifier c54_thisId;
  real_T c54_y;
  SFc54_FingerEAERCtrlInstanceStruct *chartInstance;
  chartInstance = (SFc54_FingerEAERCtrlInstanceStruct *)chartInstanceVoid;
  c54_state = sf_mex_dup(c54_mxArrayInData);
  c54_identifier = c54_varName;
  c54_thisId.fIdentifier = c54_identifier;
  c54_thisId.fParent = NULL;
  c54_y = c54_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c54_state),
    &c54_thisId);
  sf_mex_destroy(&c54_state);
  *(real_T *)c54_outData = c54_y;
  sf_mex_destroy(&c54_mxArrayInData);
}

static const mxArray *c54_b_sf_marshallOut(void *chartInstanceVoid, void
  *c54_inData)
{
  const mxArray *c54_mxArrayOutData = NULL;
  int32_T c54_i4;
  real_T c54_b_inData[3];
  int32_T c54_i5;
  real_T c54_u[3];
  const mxArray *c54_y = NULL;
  SFc54_FingerEAERCtrlInstanceStruct *chartInstance;
  chartInstance = (SFc54_FingerEAERCtrlInstanceStruct *)chartInstanceVoid;
  c54_mxArrayOutData = NULL;
  for (c54_i4 = 0; c54_i4 < 3; c54_i4++) {
    c54_b_inData[c54_i4] = (*(real_T (*)[3])c54_inData)[c54_i4];
  }

  for (c54_i5 = 0; c54_i5 < 3; c54_i5++) {
    c54_u[c54_i5] = c54_b_inData[c54_i5];
  }

  c54_y = NULL;
  sf_mex_assign(&c54_y, sf_mex_create("y", c54_u, 0, 0U, 1U, 0U, 1, 3), FALSE);
  sf_mex_assign(&c54_mxArrayOutData, c54_y, FALSE);
  return c54_mxArrayOutData;
}

static void c54_c_emlrt_marshallIn(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance, const mxArray *c54_des, const char_T *c54_identifier, real_T
  c54_y[3])
{
  emlrtMsgIdentifier c54_thisId;
  c54_thisId.fIdentifier = c54_identifier;
  c54_thisId.fParent = NULL;
  c54_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c54_des), &c54_thisId, c54_y);
  sf_mex_destroy(&c54_des);
}

static void c54_d_emlrt_marshallIn(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance, const mxArray *c54_u, const emlrtMsgIdentifier *c54_parentId,
  real_T c54_y[3])
{
  real_T c54_dv1[3];
  int32_T c54_i6;
  sf_mex_import(c54_parentId, sf_mex_dup(c54_u), c54_dv1, 1, 0, 0U, 1, 0U, 1, 3);
  for (c54_i6 = 0; c54_i6 < 3; c54_i6++) {
    c54_y[c54_i6] = c54_dv1[c54_i6];
  }

  sf_mex_destroy(&c54_u);
}

static void c54_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c54_mxArrayInData, const char_T *c54_varName, void *c54_outData)
{
  const mxArray *c54_des;
  const char_T *c54_identifier;
  emlrtMsgIdentifier c54_thisId;
  real_T c54_y[3];
  int32_T c54_i7;
  SFc54_FingerEAERCtrlInstanceStruct *chartInstance;
  chartInstance = (SFc54_FingerEAERCtrlInstanceStruct *)chartInstanceVoid;
  c54_des = sf_mex_dup(c54_mxArrayInData);
  c54_identifier = c54_varName;
  c54_thisId.fIdentifier = c54_identifier;
  c54_thisId.fParent = NULL;
  c54_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c54_des), &c54_thisId, c54_y);
  sf_mex_destroy(&c54_des);
  for (c54_i7 = 0; c54_i7 < 3; c54_i7++) {
    (*(real_T (*)[3])c54_outData)[c54_i7] = c54_y[c54_i7];
  }

  sf_mex_destroy(&c54_mxArrayInData);
}

const mxArray *sf_c54_FingerEAERCtrl_get_eml_resolved_functions_info(void)
{
  const mxArray *c54_nameCaptureInfo;
  c54_ResolvedFunctionInfo c54_info[10];
  c54_ResolvedFunctionInfo (*c54_b_info)[10];
  const mxArray *c54_m0 = NULL;
  int32_T c54_i8;
  c54_ResolvedFunctionInfo *c54_r0;
  c54_nameCaptureInfo = NULL;
  c54_nameCaptureInfo = NULL;
  c54_b_info = (c54_ResolvedFunctionInfo (*)[10])c54_info;
  (*c54_b_info)[0].context = "";
  (*c54_b_info)[0].name = "mtimes";
  (*c54_b_info)[0].dominantType = "double";
  (*c54_b_info)[0].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c54_b_info)[0].fileTimeLo = 1289552092U;
  (*c54_b_info)[0].fileTimeHi = 0U;
  (*c54_b_info)[0].mFileTimeLo = 0U;
  (*c54_b_info)[0].mFileTimeHi = 0U;
  (*c54_b_info)[1].context = "";
  (*c54_b_info)[1].name = "mpower";
  (*c54_b_info)[1].dominantType = "double";
  (*c54_b_info)[1].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m";
  (*c54_b_info)[1].fileTimeLo = 1286851242U;
  (*c54_b_info)[1].fileTimeHi = 0U;
  (*c54_b_info)[1].mFileTimeLo = 0U;
  (*c54_b_info)[1].mFileTimeHi = 0U;
  (*c54_b_info)[2].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m";
  (*c54_b_info)[2].name = "power";
  (*c54_b_info)[2].dominantType = "double";
  (*c54_b_info)[2].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m";
  (*c54_b_info)[2].fileTimeLo = 1336554496U;
  (*c54_b_info)[2].fileTimeHi = 0U;
  (*c54_b_info)[2].mFileTimeLo = 0U;
  (*c54_b_info)[2].mFileTimeHi = 0U;
  (*c54_b_info)[3].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  (*c54_b_info)[3].name = "eml_scalar_eg";
  (*c54_b_info)[3].dominantType = "double";
  (*c54_b_info)[3].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  (*c54_b_info)[3].fileTimeLo = 1286851196U;
  (*c54_b_info)[3].fileTimeHi = 0U;
  (*c54_b_info)[3].mFileTimeLo = 0U;
  (*c54_b_info)[3].mFileTimeHi = 0U;
  (*c54_b_info)[4].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  (*c54_b_info)[4].name = "eml_scalexp_alloc";
  (*c54_b_info)[4].dominantType = "double";
  (*c54_b_info)[4].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m";
  (*c54_b_info)[4].fileTimeLo = 1330640834U;
  (*c54_b_info)[4].fileTimeHi = 0U;
  (*c54_b_info)[4].mFileTimeLo = 0U;
  (*c54_b_info)[4].mFileTimeHi = 0U;
  (*c54_b_info)[5].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  (*c54_b_info)[5].name = "floor";
  (*c54_b_info)[5].dominantType = "double";
  (*c54_b_info)[5].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m";
  (*c54_b_info)[5].fileTimeLo = 1286851142U;
  (*c54_b_info)[5].fileTimeHi = 0U;
  (*c54_b_info)[5].mFileTimeLo = 0U;
  (*c54_b_info)[5].mFileTimeHi = 0U;
  (*c54_b_info)[6].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m";
  (*c54_b_info)[6].name = "eml_scalar_floor";
  (*c54_b_info)[6].dominantType = "double";
  (*c54_b_info)[6].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_floor.m";
  (*c54_b_info)[6].fileTimeLo = 1286851126U;
  (*c54_b_info)[6].fileTimeHi = 0U;
  (*c54_b_info)[6].mFileTimeLo = 0U;
  (*c54_b_info)[6].mFileTimeHi = 0U;
  (*c54_b_info)[7].context = "";
  (*c54_b_info)[7].name = "mrdivide";
  (*c54_b_info)[7].dominantType = "double";
  (*c54_b_info)[7].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  (*c54_b_info)[7].fileTimeLo = 1342843344U;
  (*c54_b_info)[7].fileTimeHi = 0U;
  (*c54_b_info)[7].mFileTimeLo = 1319762366U;
  (*c54_b_info)[7].mFileTimeHi = 0U;
  (*c54_b_info)[8].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  (*c54_b_info)[8].name = "rdivide";
  (*c54_b_info)[8].dominantType = "double";
  (*c54_b_info)[8].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  (*c54_b_info)[8].fileTimeLo = 1286851244U;
  (*c54_b_info)[8].fileTimeHi = 0U;
  (*c54_b_info)[8].mFileTimeLo = 0U;
  (*c54_b_info)[8].mFileTimeHi = 0U;
  (*c54_b_info)[9].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  (*c54_b_info)[9].name = "eml_div";
  (*c54_b_info)[9].dominantType = "double";
  (*c54_b_info)[9].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m";
  (*c54_b_info)[9].fileTimeLo = 1313380210U;
  (*c54_b_info)[9].fileTimeHi = 0U;
  (*c54_b_info)[9].mFileTimeLo = 0U;
  (*c54_b_info)[9].mFileTimeHi = 0U;
  sf_mex_assign(&c54_m0, sf_mex_createstruct("nameCaptureInfo", 1, 10), FALSE);
  for (c54_i8 = 0; c54_i8 < 10; c54_i8++) {
    c54_r0 = &c54_info[c54_i8];
    sf_mex_addfield(c54_m0, sf_mex_create("nameCaptureInfo", c54_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c54_r0->context)), "context", "nameCaptureInfo",
                    c54_i8);
    sf_mex_addfield(c54_m0, sf_mex_create("nameCaptureInfo", c54_r0->name, 15,
      0U, 0U, 0U, 2, 1, strlen(c54_r0->name)), "name", "nameCaptureInfo", c54_i8);
    sf_mex_addfield(c54_m0, sf_mex_create("nameCaptureInfo",
      c54_r0->dominantType, 15, 0U, 0U, 0U, 2, 1, strlen(c54_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c54_i8);
    sf_mex_addfield(c54_m0, sf_mex_create("nameCaptureInfo", c54_r0->resolved,
      15, 0U, 0U, 0U, 2, 1, strlen(c54_r0->resolved)), "resolved",
                    "nameCaptureInfo", c54_i8);
    sf_mex_addfield(c54_m0, sf_mex_create("nameCaptureInfo", &c54_r0->fileTimeLo,
      7, 0U, 0U, 0U, 0), "fileTimeLo", "nameCaptureInfo", c54_i8);
    sf_mex_addfield(c54_m0, sf_mex_create("nameCaptureInfo", &c54_r0->fileTimeHi,
      7, 0U, 0U, 0U, 0), "fileTimeHi", "nameCaptureInfo", c54_i8);
    sf_mex_addfield(c54_m0, sf_mex_create("nameCaptureInfo",
      &c54_r0->mFileTimeLo, 7, 0U, 0U, 0U, 0), "mFileTimeLo", "nameCaptureInfo",
                    c54_i8);
    sf_mex_addfield(c54_m0, sf_mex_create("nameCaptureInfo",
      &c54_r0->mFileTimeHi, 7, 0U, 0U, 0U, 0), "mFileTimeHi", "nameCaptureInfo",
                    c54_i8);
  }

  sf_mex_assign(&c54_nameCaptureInfo, c54_m0, FALSE);
  sf_mex_emlrtNameCapturePostProcessR2012a(&c54_nameCaptureInfo);
  return c54_nameCaptureInfo;
}

static real_T c54_mpower(SFc54_FingerEAERCtrlInstanceStruct *chartInstance,
  real_T c54_a)
{
  real_T c54_b_a;
  real_T c54_c_a;
  real_T c54_ak;
  c54_b_a = c54_a;
  c54_c_a = c54_b_a;
  c54_eml_scalar_eg(chartInstance);
  c54_ak = c54_c_a;
  return muDoubleScalarPower(c54_ak, 3.0);
}

static void c54_eml_scalar_eg(SFc54_FingerEAERCtrlInstanceStruct *chartInstance)
{
}

static real_T c54_b_mpower(SFc54_FingerEAERCtrlInstanceStruct *chartInstance,
  real_T c54_a)
{
  real_T c54_b_a;
  real_T c54_c_a;
  real_T c54_ak;
  c54_b_a = c54_a;
  c54_c_a = c54_b_a;
  c54_eml_scalar_eg(chartInstance);
  c54_ak = c54_c_a;
  return muDoubleScalarPower(c54_ak, 4.0);
}

static real_T c54_c_mpower(SFc54_FingerEAERCtrlInstanceStruct *chartInstance,
  real_T c54_a)
{
  real_T c54_b_a;
  real_T c54_c_a;
  real_T c54_ak;
  c54_b_a = c54_a;
  c54_c_a = c54_b_a;
  c54_eml_scalar_eg(chartInstance);
  c54_ak = c54_c_a;
  return muDoubleScalarPower(c54_ak, 5.0);
}

static real_T c54_d_mpower(SFc54_FingerEAERCtrlInstanceStruct *chartInstance,
  real_T c54_a)
{
  real_T c54_b_a;
  real_T c54_c_a;
  real_T c54_ak;
  c54_b_a = c54_a;
  c54_c_a = c54_b_a;
  c54_eml_scalar_eg(chartInstance);
  c54_ak = c54_c_a;
  return muDoubleScalarPower(c54_ak, 2.0);
}

static const mxArray *c54_c_sf_marshallOut(void *chartInstanceVoid, void
  *c54_inData)
{
  const mxArray *c54_mxArrayOutData = NULL;
  int32_T c54_u;
  const mxArray *c54_y = NULL;
  SFc54_FingerEAERCtrlInstanceStruct *chartInstance;
  chartInstance = (SFc54_FingerEAERCtrlInstanceStruct *)chartInstanceVoid;
  c54_mxArrayOutData = NULL;
  c54_u = *(int32_T *)c54_inData;
  c54_y = NULL;
  sf_mex_assign(&c54_y, sf_mex_create("y", &c54_u, 6, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c54_mxArrayOutData, c54_y, FALSE);
  return c54_mxArrayOutData;
}

static int32_T c54_e_emlrt_marshallIn(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance, const mxArray *c54_u, const emlrtMsgIdentifier *c54_parentId)
{
  int32_T c54_y;
  int32_T c54_i9;
  sf_mex_import(c54_parentId, sf_mex_dup(c54_u), &c54_i9, 1, 6, 0U, 0, 0U, 0);
  c54_y = c54_i9;
  sf_mex_destroy(&c54_u);
  return c54_y;
}

static void c54_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c54_mxArrayInData, const char_T *c54_varName, void *c54_outData)
{
  const mxArray *c54_sfEvent;
  const char_T *c54_identifier;
  emlrtMsgIdentifier c54_thisId;
  int32_T c54_y;
  SFc54_FingerEAERCtrlInstanceStruct *chartInstance;
  chartInstance = (SFc54_FingerEAERCtrlInstanceStruct *)chartInstanceVoid;
  c54_sfEvent = sf_mex_dup(c54_mxArrayInData);
  c54_identifier = c54_varName;
  c54_thisId.fIdentifier = c54_identifier;
  c54_thisId.fParent = NULL;
  c54_y = c54_e_emlrt_marshallIn(chartInstance, sf_mex_dup(c54_sfEvent),
    &c54_thisId);
  sf_mex_destroy(&c54_sfEvent);
  *(int32_T *)c54_outData = c54_y;
  sf_mex_destroy(&c54_mxArrayInData);
}

static uint8_T c54_f_emlrt_marshallIn(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance, const mxArray *c54_is_active_c54_FingerEAERCtrl, const char_T *
  c54_identifier)
{
  uint8_T c54_y;
  emlrtMsgIdentifier c54_thisId;
  c54_thisId.fIdentifier = c54_identifier;
  c54_thisId.fParent = NULL;
  c54_y = c54_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c54_is_active_c54_FingerEAERCtrl), &c54_thisId);
  sf_mex_destroy(&c54_is_active_c54_FingerEAERCtrl);
  return c54_y;
}

static uint8_T c54_g_emlrt_marshallIn(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance, const mxArray *c54_u, const emlrtMsgIdentifier *c54_parentId)
{
  uint8_T c54_y;
  uint8_T c54_u0;
  sf_mex_import(c54_parentId, sf_mex_dup(c54_u), &c54_u0, 1, 3, 0U, 0, 0U, 0);
  c54_y = c54_u0;
  sf_mex_destroy(&c54_u);
  return c54_y;
}

static void init_dsm_address_info(SFc54_FingerEAERCtrlInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
static uint32_T* sf_get_sfun_dwork_checksum();
void sf_c54_FingerEAERCtrl_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3354691350U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3483287912U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1903864891U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(3348623937U);
}

mxArray *sf_c54_FingerEAERCtrl_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,5,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("5NWOZJJwUu5ijypigPwpqC");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,7,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,6,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,6,"type",mxType);
    }

    mxSetField(mxData,6,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,3,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxCreateDoubleMatrix(0,0,mxREAL));
  }

  return(mxAutoinheritanceInfo);
}

static const mxArray *sf_get_sim_state_info_c54_FingerEAERCtrl(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x4'type','srcId','name','auxInfo'{{M[1],M[12],T\"Phold\",},{M[1],M[5],T\"des\",},{M[1],M[14],T\"state\",},{M[8],M[0],T\"is_active_c54_FingerEAERCtrl\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 4, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c54_FingerEAERCtrl_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc54_FingerEAERCtrlInstanceStruct *chartInstance;
    chartInstance = (SFc54_FingerEAERCtrlInstanceStruct *) ((ChartInfoStruct *)
      (ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_FingerEAERCtrlMachineNumber_,
           54,
           1,
           1,
           10,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation(_FingerEAERCtrlMachineNumber_,
            chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_FingerEAERCtrlMachineNumber_,chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(_FingerEAERCtrlMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,"Pd");
          _SFD_SET_DATA_PROPS(1,1,1,0,"th");
          _SFD_SET_DATA_PROPS(2,1,1,0,"dur");
          _SFD_SET_DATA_PROPS(3,2,0,1,"des");
          _SFD_SET_DATA_PROPS(4,1,1,0,"t");
          _SFD_SET_DATA_PROPS(5,1,1,0,"Phold_");
          _SFD_SET_DATA_PROPS(6,2,0,1,"Phold");
          _SFD_SET_DATA_PROPS(7,1,1,0,"state_");
          _SFD_SET_DATA_PROPS(8,2,0,1,"state");
          _SFD_SET_DATA_PROPS(9,1,1,0,"Pactual_");
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of MATLAB Function Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,3,0,0,1,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",98,-1,1122);
        _SFD_CV_INIT_EML_IF(0,1,0,421,436,-1,452);
        _SFD_CV_INIT_EML_IF(0,1,1,740,751,-1,767);
        _SFD_CV_INIT_EML_IF(0,1,2,1004,1019,-1,1035);

        {
          static int caseStart[] = { 1040, 311, 457, 772, 924 };

          static int caseExprEnd[] = { 1049, 317, 463, 778, 930 };

          _SFD_CV_INIT_EML_SWITCH(0,1,0,293,307,1121,5,&(caseStart[0]),
            &(caseExprEnd[0]));
        }

        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_SET_DATA_COMPILED_PROPS(0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c54_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c54_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(2,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c54_sf_marshallOut,(MexInFcnForType)NULL);

        {
          unsigned int dimVector[1];
          dimVector[0]= 3;
          _SFD_SET_DATA_COMPILED_PROPS(3,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c54_b_sf_marshallOut,(MexInFcnForType)
            c54_b_sf_marshallIn);
        }

        _SFD_SET_DATA_COMPILED_PROPS(4,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c54_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(5,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c54_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(6,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c54_sf_marshallOut,(MexInFcnForType)c54_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(7,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c54_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(8,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c54_sf_marshallOut,(MexInFcnForType)c54_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(9,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c54_sf_marshallOut,(MexInFcnForType)NULL);

        {
          real_T *c54_Pd;
          real_T *c54_th;
          real_T *c54_dur;
          real_T *c54_t;
          real_T *c54_Phold_;
          real_T *c54_Phold;
          real_T *c54_state_;
          real_T *c54_state;
          real_T *c54_Pactual_;
          real_T (*c54_des)[3];
          c54_Pactual_ = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
          c54_state = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
          c54_state_ = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
          c54_Phold = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
          c54_Phold_ = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
          c54_t = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
          c54_des = (real_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
          c54_dur = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
          c54_th = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
          c54_Pd = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c54_Pd);
          _SFD_SET_DATA_VALUE_PTR(1U, c54_th);
          _SFD_SET_DATA_VALUE_PTR(2U, c54_dur);
          _SFD_SET_DATA_VALUE_PTR(3U, *c54_des);
          _SFD_SET_DATA_VALUE_PTR(4U, c54_t);
          _SFD_SET_DATA_VALUE_PTR(5U, c54_Phold_);
          _SFD_SET_DATA_VALUE_PTR(6U, c54_Phold);
          _SFD_SET_DATA_VALUE_PTR(7U, c54_state_);
          _SFD_SET_DATA_VALUE_PTR(8U, c54_state);
          _SFD_SET_DATA_VALUE_PTR(9U, c54_Pactual_);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration(_FingerEAERCtrlMachineNumber_,
        chartInstance->chartNumber,chartInstance->instanceNumber);
    }
  }
}

static const char* sf_get_instance_specialization()
{
  return "5XIho4d3K414D3TLLhlh2D";
}

static void sf_check_dwork_consistency(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    const uint32_T *sfunDWorkChecksum = sf_get_sfun_dwork_checksum();
    mxArray *infoStruct = load_FingerEAERCtrl_optimization_info();
    mxArray* mxRTWDWorkChecksum = sf_get_dwork_info_from_mat_file(S,
      sf_get_instance_specialization(), infoStruct, 54, "dworkChecksum");
    if (mxRTWDWorkChecksum != NULL) {
      double *pr = mxGetPr(mxRTWDWorkChecksum);
      if ((uint32_T)pr[0] != sfunDWorkChecksum[0] ||
          (uint32_T)pr[1] != sfunDWorkChecksum[1] ||
          (uint32_T)pr[2] != sfunDWorkChecksum[2] ||
          (uint32_T)pr[3] != sfunDWorkChecksum[3]) {
        sf_mex_error_message("Code generation and simulation targets registered different sets of persistent variables for the block. "
                             "External or Rapid Accelerator mode simulation requires code generation and simulation targets to "
                             "register the same set of persistent variables for this block. "
                             "This discrepancy is typically caused by MATLAB functions that have different code paths for "
                             "simulation and code generation targets where these code paths define different sets of persistent variables. "
                             "Please identify these code paths in the offending block and rewrite the MATLAB code so that "
                             "the set of persistent variables is the same between simulation and code generation.");
      }
    }
  }
}

static void sf_opaque_initialize_c54_FingerEAERCtrl(void *chartInstanceVar)
{
  sf_check_dwork_consistency(((SFc54_FingerEAERCtrlInstanceStruct*)
    chartInstanceVar)->S);
  chart_debug_initialization(((SFc54_FingerEAERCtrlInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c54_FingerEAERCtrl((SFc54_FingerEAERCtrlInstanceStruct*)
    chartInstanceVar);
  initialize_c54_FingerEAERCtrl((SFc54_FingerEAERCtrlInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c54_FingerEAERCtrl(void *chartInstanceVar)
{
  enable_c54_FingerEAERCtrl((SFc54_FingerEAERCtrlInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c54_FingerEAERCtrl(void *chartInstanceVar)
{
  disable_c54_FingerEAERCtrl((SFc54_FingerEAERCtrlInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c54_FingerEAERCtrl(void *chartInstanceVar)
{
  sf_c54_FingerEAERCtrl((SFc54_FingerEAERCtrlInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_ext_mode_exec_c54_FingerEAERCtrl(void *chartInstanceVar)
{
  ext_mode_exec_c54_FingerEAERCtrl((SFc54_FingerEAERCtrlInstanceStruct*)
    chartInstanceVar);
}

extern const mxArray* sf_internal_get_sim_state_c54_FingerEAERCtrl(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c54_FingerEAERCtrl
    ((SFc54_FingerEAERCtrlInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c54_FingerEAERCtrl();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

extern void sf_internal_set_sim_state_c54_FingerEAERCtrl(SimStruct* S, const
  mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c54_FingerEAERCtrl();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c54_FingerEAERCtrl((SFc54_FingerEAERCtrlInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static const mxArray* sf_opaque_get_sim_state_c54_FingerEAERCtrl(SimStruct* S)
{
  return sf_internal_get_sim_state_c54_FingerEAERCtrl(S);
}

static void sf_opaque_set_sim_state_c54_FingerEAERCtrl(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c54_FingerEAERCtrl(S, st);
}

static void sf_opaque_terminate_c54_FingerEAERCtrl(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc54_FingerEAERCtrlInstanceStruct*) chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c54_FingerEAERCtrl((SFc54_FingerEAERCtrlInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }

  unload_FingerEAERCtrl_optimization_info();
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc54_FingerEAERCtrl((SFc54_FingerEAERCtrlInstanceStruct*)
    chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c54_FingerEAERCtrl(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c54_FingerEAERCtrl((SFc54_FingerEAERCtrlInstanceStruct*)
      (((ChartInfoStruct *)ssGetUserData(S))->chartInstance));
  }
}

mxArray *sf_c54_FingerEAERCtrl_get_testpoint_info(void)
{
  return NULL;
}

static void sf_set_sfun_dwork_info(SimStruct *S)
{
  const char *dworkEncStr[] = {
    "100 S1x4'type','isSigned','wordLength','bias','slope','exponent','isComplex','size'{{T\"int32\",,,,,,M[0],M[]},{T\"boolean\",,,,,,M[0],M[]},{T\"boolean\",,,,,,M[0],M[]},{T\"uint8\",,,,,,M[0],M[]}}"
  };

  sf_set_encoded_dwork_info(S, dworkEncStr, 4, 10);
}

static uint32_T* sf_get_sfun_dwork_checksum()
{
  static uint32_T checksum[4] = { 3851270630U, 3363230343U, 1651207761U,
    946165807U };

  return checksum;
}

static void mdlSetWorkWidths_c54_FingerEAERCtrl(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct = load_FingerEAERCtrl_optimization_info();
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(S,sf_get_instance_specialization(),infoStruct,
      54);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop(S,sf_get_instance_specialization(),
                infoStruct,54,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop(S,
      sf_get_instance_specialization(),infoStruct,54,
      "gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 4, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 5, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 6, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,54,7);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,54,3);
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,54);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
    sf_set_sfun_dwork_info(S);
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(1972194935U));
  ssSetChecksum1(S,(852166876U));
  ssSetChecksum2(S,(3097347643U));
  ssSetChecksum3(S,(2939125178U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
  ssSupportsMultipleExecInstances(S,1);
}

static void mdlRTW_c54_FingerEAERCtrl(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c54_FingerEAERCtrl(SimStruct *S)
{
  SFc54_FingerEAERCtrlInstanceStruct *chartInstance;
  chartInstance = (SFc54_FingerEAERCtrlInstanceStruct *)malloc(sizeof
    (SFc54_FingerEAERCtrlInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc54_FingerEAERCtrlInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c54_FingerEAERCtrl;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c54_FingerEAERCtrl;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c54_FingerEAERCtrl;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c54_FingerEAERCtrl;
  chartInstance->chartInfo.disableChart = sf_opaque_disable_c54_FingerEAERCtrl;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c54_FingerEAERCtrl;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c54_FingerEAERCtrl;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c54_FingerEAERCtrl;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c54_FingerEAERCtrl;
  chartInstance->chartInfo.mdlStart = mdlStart_c54_FingerEAERCtrl;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c54_FingerEAERCtrl;
  chartInstance->chartInfo.extModeExec =
    sf_opaque_ext_mode_exec_c54_FingerEAERCtrl;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  init_dsm_address_info(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  sf_opaque_init_subchart_simstructs(chartInstance->chartInfo.chartInstance);
  chart_debug_initialization(S,1);
}

void c54_FingerEAERCtrl_method_dispatcher(SimStruct *S, int_T method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c54_FingerEAERCtrl(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c54_FingerEAERCtrl(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c54_FingerEAERCtrl(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c54_FingerEAERCtrl_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
