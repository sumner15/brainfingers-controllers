/*
 * FingerEAERCtrl_private.h
 *
 * Code generation for model "FingerEAERCtrl".
 *
 * Model version              : 1.750
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Thu Apr 28 15:02:04 2016
 *
 * Target selection: xpctarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_FingerEAERCtrl_private_h_
#define RTW_HEADER_FingerEAERCtrl_private_h_
#include "rtwtypes.h"
#ifndef __RTWTYPES_H__
#error This file requires rtwtypes.h to be included
#else
#ifdef TMWTYPES_PREVIOUSLY_INCLUDED
#error This file requires rtwtypes.h to be included before tmwtypes.h
#else

/* Check for inclusion of an incorrect version of rtwtypes.h */
#ifndef RTWTYPES_ID_C08S16I32L32N32F1
#error This code was generated with a different "rtwtypes.h" than the file included
#endif                                 /* RTWTYPES_ID_C08S16I32L32N32F1 */
#endif                                 /* TMWTYPES_PREVIOUSLY_INCLUDED */
#endif                                 /* __RTWTYPES_H__ */

extern const serialfifoptr serialfifoground;
extern const bcmsglist1553 bcmsg1553ground;
extern const bcstatus1553 bcstatground;
extern const bmmsglist1553 bmmsg1553ground;
extern real_T rt_powd_snf(real_T u0, real_T u1);

/* Exported functions */
/* Exported functions */
/* Exported functions */
/* Exported functions */
/* Exported functions */
extern real_T rt_roundd_snf(real_T u);

/* Exported functions */
extern void adnipcim(SimStruct *rts);
extern void encnipcim(SimStruct *rts);
extern void danipcim(SimStruct *rts);
extern void FingerEAERC_MATLABFunction_Init(rtDW_MATLABFunction_FingerEAERC
  *localDW);
extern void FingerEAERCtrl_MATLABFunction(real_T rtu_input1, real_T rtu_input2,
  real_T rtu_leftyMode, rtB_MATLABFunction_FingerEAERCt *localB,
  rtDW_MATLABFunction_FingerEAERC *localDW);
extern void FingerEAERCtrl_gainramp_Init(rtDW_gainramp_FingerEAERCtrl *localDW);
extern void FingerEAERCtrl_gainramp(real_T rtu_tr, real_T rtu_valD, const real_T
  rtu_state[4], rtB_gainramp_FingerEAERCtrl *localB,
  rtDW_gainramp_FingerEAERCtrl *localDW);
extern void FingerEAE_MATLABFunction_e_Init(rtDW_MATLABFunction_FingerEAE_i
  *localDW);
extern void FingerEAERCtrl_MATLABFunction_g(real_T rtu_Pd, real_T rtu_th, real_T
  rtu_dur, real_T rtu_t, rtB_MATLABFunction_FingerEAER_h *localB,
  rtDW_MATLABFunction_FingerEAE_i *localDW);
extern void FingerEAE_detectforceonset_Init(rtDW_detectforceonset_FingerEAE
  *localDW);
extern void FingerEAERCtrl_detectforceonset(real_T rtu_force, real_T
  rtu_F_THRESH, real_T rtu_tDes, real_T rtu_t, real_T rtu_pTraj, real_T
  rtu_maxDur, rtB_detectforceonset_FingerEAER *localB,
  rtDW_detectforceonset_FingerEAE *localDW);
extern void Finger_detectmovementonset_Init(rtDW_detectmovementonset_Finger
  *localDW);
extern void FingerEAERC_detectmovementonset(real_T rtu_vel, real_T rtu_V_THRESH,
  real_T rtu_tDes, real_T rtu_t, real_T rtu_pTraj, real_T rtu_maxDur,
  rtB_detectmovementonset_FingerE *localB, rtDW_detectmovementonset_Finger
  *localDW);
extern void FingerEAERCtr_paramsbuffer_Init(rtDW_paramsbuffer_FingerEAERCtr
  *localDW);
extern void FingerEAERCtrl_paramsbuffer(boolean_T rtu_0, real_T rtu_pDes_,
  real_T rtu_tHit_, real_T rtu_t, rtModel_FingerEAERCtrl * const
  FingerEAERCtrl_rtM, rtB_paramsbuffer_FingerEAERCtrl *localB,
  rtDW_paramsbuffer_FingerEAERCtr *localDW, rtZCE_paramsbuffer_FingerEAERCt
  *localZCE);
extern void FingerEAE_MATLABFunction_a_Init(rtDW_MATLABFunction_FingerEA_ig
  *localDW);
extern void FingerEAERCtrl_MATLABFunction_m(real_T rtu_Pd, real_T rtu_Pstart,
  real_T rtu_th, real_T rtu_dur, real_T rtu_t, rtB_MATLABFunction_FingerEAER_b
  *localB, rtDW_MATLABFunction_FingerEA_ig *localDW);
extern void FingerEAER_MATLABFunction1_Init(rtDW_MATLABFunction1_FingerEAER
  *localDW);
extern void FingerEAERCtrl_MATLABFunction1(real_T rtu_pDes, real_T rtu_pDes_,
  rtB_MATLABFunction1_FingerEAERC *localB, rtDW_MATLABFunction1_FingerEAER
  *localDW);
extern void FingerEAERC_paramsbuffer_n_Init(rtDW_paramsbuffer_FingerEAERC_p
  *localDW);
extern void FingerEAERCtrl_paramsbuffer_k(real_T rtu_0, real_T rtu_1, real_T
  rtu_pDes_, real_T rtu_pos_, real_T rtu_tHit_, rtModel_FingerEAERCtrl * const
  FingerEAERCtrl_rtM, rtB_paramsbuffer_FingerEAERCt_c *localB,
  rtDW_paramsbuffer_FingerEAERC_p *localDW, rtZCE_paramsbuffer_FingerEAER_a
  *localZCE);
extern void FingerEAE_MATLABFunction_n_Init(rtDW_MATLABFunction_FingerEAE_l
  *localDW);
extern void FingerEAERCtrl_MATLABFunction_c(real_T rtu_Pd, real_T rtu_th, real_T
  rtu_dur, real_T rtu_t, real_T rtu_Phold_, real_T rtu_state_, real_T
  rtu_Pactual_, rtB_MATLABFunction_FingerEAER_i *localB,
  rtDW_MATLABFunction_FingerEAE_l *localDW);
extern void FingerEAERC_paramsbuffer_b_Init(rtDW_paramsbuffer_FingerEAERC_j
  *localDW);
extern void FingerEAERCtrl_paramsbuffer_o(real_T rtu_0, real_T rtu_1, real_T
  rtu_pDes_, real_T rtu_tHit_, rtModel_FingerEAERCtrl * const FingerEAERCtrl_rtM,
  rtB_paramsbuffer_FingerEAERCt_d *localB, rtDW_paramsbuffer_FingerEAERC_j
  *localDW, rtZCE_paramsbuffer_FingerEAER_l *localZCE);
extern void FingerEA_detectforceonset1_Init(rtDW_detectforceonset1_FingerEA
  *localDW);
extern void FingerEAERCtr_detectforceonset1(real_T rtu_Pdes, real_T rtu_force,
  real_T rtu_F_THRESH, real_T rtu_tDes_, real_T rtu_t, real_T rtu_f0_,
  rtB_detectforceonset1_FingerEAE *localB, rtDW_detectforceonset1_FingerEA
  *localDW);
extern void FingerEA_MATLABFunction1_j_Init(rtDW_MATLABFunction1_FingerEA_m
  *localDW);
extern void FingerEAERCtr_MATLABFunction1_k(real_T rtu_tDes, real_T rtu_tDesLast,
  rtB_MATLABFunction1_FingerEAE_l *localB, rtDW_MATLABFunction1_FingerEA_m
  *localDW);
extern void FingerEAERCtrl_forcebuffer_Init(rtDW_forcebuffer_FingerEAERCtrl
  *localDW);
extern void FingerEAERCtrl_forcebuffer(real_T rtu_0, real_T rtu_force_,
  rtModel_FingerEAERCtrl * const FingerEAERCtrl_rtM,
  rtB_forcebuffer_FingerEAERCtrl *localB, rtDW_forcebuffer_FingerEAERCtrl
  *localDW, rtZCE_forcebuffer_FingerEAERCtr *localZCE);
extern void FingerEAERCt_paramsbuffer1_Init(rtDW_paramsbuffer1_FingerEAERCt
  *localDW);
extern void FingerEAERCtrl_paramsbuffer1(real_T rtu_0, real_T rtu_pDes_, real_T
  rtu_tHit_, real_T rtu_maxDur, real_T rtu_t, rtModel_FingerEAERCtrl * const
  FingerEAERCtrl_rtM, rtB_paramsbuffer1_FingerEAERCtr *localB,
  rtDW_paramsbuffer1_FingerEAERCt *localDW, rtZCE_paramsbuffer1_FingerEAERC
  *localZCE);
extern void FingerE_saveTrialStartTime_Init(rtDW_saveTrialStartTime_FingerE
  *localDW);
extern void FingerEAERCt_saveTrialStartTime(real_T rtu_0, real_T rtu_t,
  rtModel_FingerEAERCtrl * const FingerEAERCtrl_rtM,
  rtB_saveTrialStartTime_FingerEA *localB, rtDW_saveTrialStartTime_FingerE
  *localDW, rtZCE_saveTrialStartTime_Finger *localZCE);
extern void FingerEAERCt_timeToTrigger_Init(rtDW_timeToTrigger_FingerEAERCt
  *localDW, rtP_timeToTrigger_FingerEAERCtr *localP);
extern void FingerEAERCtrl_timeToTrigger(real_T rtu_0, real_T rtu_t, real_T
  rtu_trialStart, rtModel_FingerEAERCtrl * const FingerEAERCtrl_rtM,
  rtB_timeToTrigger_FingerEAERCtr *localB, rtDW_timeToTrigger_FingerEAERCt
  *localDW, rtZCE_timeToTrigger_FingerEAERC *localZCE);
extern void FingerEAERCtrl_trajcalc_Init(rtDW_trajcalc_FingerEAERCtrl *localDW);
extern void FingerEAERCtrl_trajcalc(real_T rtu_Pd, real_T rtu_th, real_T rtu_dur,
  real_T rtu_t, real_T rtu_Phold_, real_T rtu_state_, real_T rtu_Pactual_,
  real_T rtu_trajMode, rtB_trajcalc_FingerEAERCtrl *localB,
  rtDW_trajcalc_FingerEAERCtrl *localDW);
extern void FingerEAERCtr_triggercheck_Init(rtDW_triggercheck_FingerEAERCtr
  *localDW);
extern void FingerEAERCtrl_triggercheck(real_T rtu_update, real_T rtu_tDes_,
  real_T rtu_tDesLast_, rtB_triggercheck_FingerEAERCtrl *localB,
  rtDW_triggercheck_FingerEAERCtr *localDW);

/* private model entry point functions */
extern void FingerEAERCtrl_derivatives(void);

#endif                                 /* RTW_HEADER_FingerEAERCtrl_private_h_ */
