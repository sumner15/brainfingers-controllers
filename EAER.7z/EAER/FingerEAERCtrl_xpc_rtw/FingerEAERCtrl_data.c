/*
 * FingerEAERCtrl_data.c
 *
 * Code generation for model "FingerEAERCtrl".
 *
 * Model version              : 1.750
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Thu Apr 28 15:02:04 2016
 *
 * Target selection: xpctarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "FingerEAERCtrl.h"
#include "FingerEAERCtrl_private.h"

/* Block parameters (auto storage) */
Parameters_FingerEAERCtrl FingerEAERCtrl_P = {
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<Root>/Force On'
                                        */

  /*  Expression: [1.5;0;0]
   * Referenced by: '<S8>/Integrator'
   */
  { 1.5, 0.0, 0.0 },

  /*  Expression: [0 0 0;0 0 1;-70 0 0]
   * Referenced by: '<S8>/A'
   */
  { 0.0, 0.0, -70.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0 },

  /*  Computed Parameter: PCI6221AD1_P1_Size
   * Referenced by: '<S2>/PCI-6221 AD1'
   */
  { 1.0, 8.0 },

  /*  Expression: channel
   * Referenced by: '<S2>/PCI-6221 AD1'
   */
  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0 },

  /*  Computed Parameter: PCI6221AD1_P2_Size
   * Referenced by: '<S2>/PCI-6221 AD1'
   */
  { 1.0, 8.0 },

  /*  Expression: range
   * Referenced by: '<S2>/PCI-6221 AD1'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /*  Computed Parameter: PCI6221AD1_P3_Size
   * Referenced by: '<S2>/PCI-6221 AD1'
   */
  { 1.0, 8.0 },

  /*  Expression: coupling
   * Referenced by: '<S2>/PCI-6221 AD1'
   */
  { 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0 },

  /*  Computed Parameter: PCI6221AD1_P4_Size
   * Referenced by: '<S2>/PCI-6221 AD1'
   */
  { 1.0, 1.0 },
  5.0E-6,                              /* Expression: scantime
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */

  /*  Computed Parameter: PCI6221AD1_P5_Size
   * Referenced by: '<S2>/PCI-6221 AD1'
   */
  { 1.0, 1.0 },
  0.001,                               /* Expression: sampletime
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */

  /*  Computed Parameter: PCI6221AD1_P6_Size
   * Referenced by: '<S2>/PCI-6221 AD1'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: slot
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */

  /*  Computed Parameter: PCI6221AD1_P7_Size
   * Referenced by: '<S2>/PCI-6221 AD1'
   */
  { 1.0, 1.0 },
  21.0,                                /* Expression: boardType
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S4>/paremeters_ must_be_one'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S4>/parLeftMode'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S4>/Saturation'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S4>/Saturation'
                                        */

  /*  Expression: [0;0;70]
   * Referenced by: '<S8>/B'
   */
  { 0.0, 0.0, 70.0 },

  /*  Computed Parameter: PCI6221ENC_P1_Size
   * Referenced by: '<S2>/PCI 6221 ENC '
   */
  { 1.0, 1.0 },
  21.0,                                /* Expression: device
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */

  /*  Computed Parameter: PCI6221ENC_P2_Size
   * Referenced by: '<S2>/PCI 6221 ENC '
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: channel
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */

  /*  Computed Parameter: PCI6221ENC_P3_Size
   * Referenced by: '<S2>/PCI 6221 ENC '
   */
  { 1.0, 1.0 },
  3.0,                                 /* Expression: countMode
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */

  /*  Computed Parameter: PCI6221ENC_P4_Size
   * Referenced by: '<S2>/PCI 6221 ENC '
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: initCount
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */

  /*  Computed Parameter: PCI6221ENC_P5_Size
   * Referenced by: '<S2>/PCI 6221 ENC '
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: reload
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */

  /*  Computed Parameter: PCI6221ENC_P6_Size
   * Referenced by: '<S2>/PCI 6221 ENC '
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: indexPhase
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */

  /*  Computed Parameter: PCI6221ENC_P7_Size
   * Referenced by: '<S2>/PCI 6221 ENC '
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: filter
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */

  /*  Computed Parameter: PCI6221ENC_P8_Size
   * Referenced by: '<S2>/PCI 6221 ENC '
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: outmask
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */

  /*  Computed Parameter: PCI6221ENC_P9_Size
   * Referenced by: '<S2>/PCI 6221 ENC '
   */
  { 1.0, 1.0 },
  0.001,                               /* Expression: sampleTime
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */

  /*  Computed Parameter: PCI6221ENC_P10_Size
   * Referenced by: '<S2>/PCI 6221 ENC '
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: slot
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */

  /*  Computed Parameter: PCI6221ENC1_P1_Size
   * Referenced by: '<S2>/PCI 6221 ENC 1'
   */
  { 1.0, 1.0 },
  21.0,                                /* Expression: device
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */

  /*  Computed Parameter: PCI6221ENC1_P2_Size
   * Referenced by: '<S2>/PCI 6221 ENC 1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: channel
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */

  /*  Computed Parameter: PCI6221ENC1_P3_Size
   * Referenced by: '<S2>/PCI 6221 ENC 1'
   */
  { 1.0, 1.0 },
  3.0,                                 /* Expression: countMode
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */

  /*  Computed Parameter: PCI6221ENC1_P4_Size
   * Referenced by: '<S2>/PCI 6221 ENC 1'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: initCount
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */

  /*  Computed Parameter: PCI6221ENC1_P5_Size
   * Referenced by: '<S2>/PCI 6221 ENC 1'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: reload
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */

  /*  Computed Parameter: PCI6221ENC1_P6_Size
   * Referenced by: '<S2>/PCI 6221 ENC 1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: indexPhase
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */

  /*  Computed Parameter: PCI6221ENC1_P7_Size
   * Referenced by: '<S2>/PCI 6221 ENC 1'
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: filter
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */

  /*  Computed Parameter: PCI6221ENC1_P8_Size
   * Referenced by: '<S2>/PCI 6221 ENC 1'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: outmask
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */

  /*  Computed Parameter: PCI6221ENC1_P9_Size
   * Referenced by: '<S2>/PCI 6221 ENC 1'
   */
  { 1.0, 1.0 },
  0.001,                               /* Expression: sampleTime
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */

  /*  Computed Parameter: PCI6221ENC1_P10_Size
   * Referenced by: '<S2>/PCI 6221 ENC 1'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: slot
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */

  /*  Expression: [0,0]
   * Referenced by: '<S17>/Memory1'
   */
  { 0.0, 0.0 },
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S17>/Memory'
                                        */
  0.00022222222222222223,              /* Expression: 1/4500.0
                                        * Referenced by: '<S2>/Gain'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S8>/B1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S8>/B2'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S8>/B3'
                                        */

  /*  Expression: [0 1 0]
   * Referenced by: '<S8>/C'
   */
  { 0.0, 1.0, 0.0 },
  1000.0,                              /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S10>/TSamp'
                                        */
  0.0,                                 /* Expression: ICPrevScaledInput
                                        * Referenced by: '<S10>/UD'
                                        */

  /*  Expression: [-316;101;5050]
   * Referenced by: '<S8>/K'
   */
  { -316.0, 101.0, 5050.0 },

  /*  Expression: [1.5;0;0]
   * Referenced by: '<S9>/Integrator'
   */
  { 1.5, 0.0, 0.0 },

  /*  Expression: [0 0 0;0 0 1;-65 0 0]
   * Referenced by: '<S9>/A'
   */
  { 0.0, 0.0, -65.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0 },

  /*  Expression: [0;0;65]
   * Referenced by: '<S9>/B'
   */
  { 0.0, 0.0, 65.0 },
  0.00022222222222222223,              /* Expression: 1/4500.0
                                        * Referenced by: '<S2>/Gain1'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S9>/B1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S9>/B2'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S9>/B3'
                                        */

  /*  Expression: [0 1 0]
   * Referenced by: '<S9>/C'
   */
  { 0.0, 1.0, 0.0 },
  1000.0,                              /* Computed Parameter: TSamp_WtEt_p
                                        * Referenced by: '<S11>/TSamp'
                                        */
  0.0,                                 /* Expression: ICPrevScaledInput
                                        * Referenced by: '<S11>/UD'
                                        */

  /*  Expression: [-316;101;5050]
   * Referenced by: '<S9>/K'
   */
  { -316.0, 101.0, 5050.0 },
  1.5,                                 /* Expression: 1.5
                                        * Referenced by: '<S18>/Constant'
                                        */
  0.172,                               /* Expression: .172
                                        * Referenced by: '<S18>/gain'
                                        */
  0.05,                                /* Expression: .05
                                        * Referenced by: '<S4>/parChangeRate'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S3>/Saturation'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S3>/Saturation'
                                        */

  /*  Expression: zeros(1,4)
   * Referenced by: '<S26>/Memory'
   */
  { 0.0, 0.0, 0.0, 0.0 },
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S4>/parTrajMode'
                                        */
  4.0,                                 /* Expression: 4
                                        * Referenced by: '<S4>/Saturation1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S4>/Saturation1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S7>/unity_traj'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S7>/parP1Des'
                                        */
  50.0,                                /* Expression: 50
                                        * Referenced by: '<S7>/parTHit1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigTargetTime'
                                        */
  0.375,                               /* Expression: .375
                                        * Referenced by: '<S4>/parVThresh'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S55>/Memory'
                                        */
  0.4,                                 /* Expression: .4
                                        * Referenced by: '<S4>/parMaxTrajDur'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S16>/Memory'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S54>/Constant'
                                        */
  0.25,                                /* Expression: 0.25
                                        * Referenced by: '<S4>/parFThresh'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S7>/parP2Des'
                                        */
  40.0,                                /* Expression: 40
                                        * Referenced by: '<S7>/parTHit2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S56>/Memory'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S16>/Memory1'
                                        */
  3.0,                                 /* Expression: 3
                                        * Referenced by: '<S4>/parFixedDur'
                                        */
  10.0,                                /* Expression: 10
                                        * Referenced by: '<S4>/Saturation2'
                                        */
  0.25,                                /* Expression: .25
                                        * Referenced by: '<S4>/Saturation2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S70>/Memory1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S75>/Memory1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S82>/Memory1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S79>/Memory'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S79>/Memory1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S87>/Memory1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S80>/Memory'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S80>/Memory1'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S91>/Constant'
                                        */
  100.0,                               /* Expression: 100
                                        * Referenced by: '<S92>/Gain'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S95>/Memory2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S92>/tDesMem'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S92>/pholdMem'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S92>/stateMem'
                                        */
  100.0,                               /* Expression: 100
                                        * Referenced by: '<S93>/Gain'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S108>/Memory2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S93>/tDesMem'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S93>/pholdMem'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S93>/stateMem'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S4>/parKp1'
                                        */

  /*  Expression: zeros(1,4)
   * Referenced by: '<S35>/Memory'
   */
  { 0.0, 0.0, 0.0, 0.0 },
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S4>/parKp2'
                                        */

  /*  Expression: zeros(1,4)
   * Referenced by: '<S36>/Memory'
   */
  { 0.0, 0.0, 0.0, 0.0 },
  0.0,                                 /* Expression: 0.0
                                        * Referenced by: '<S4>/parKd1'
                                        */

  /*  Expression: zeros(1,4)
   * Referenced by: '<S37>/Memory'
   */
  { 0.0, 0.0, 0.0, 0.0 },
  0.0,                                 /* Expression: 0.0
                                        * Referenced by: '<S4>/parKd2'
                                        */

  /*  Expression: zeros(1,4)
   * Referenced by: '<S38>/Memory'
   */
  { 0.0, 0.0, 0.0, 0.0 },
  2.5,                                 /* Expression: 2.5
                                        * Referenced by: '<S27>/Saturation1'
                                        */
  -2.5,                                /* Expression: -2.5
                                        * Referenced by: '<S27>/Saturation1'
                                        */
  0.75,                                /* Expression: 0.75
                                        * Referenced by: '<S4>/parPStop'
                                        */
  0.0,                                 /* Expression: 0.0
                                        * Referenced by: '<S4>/parKdV1'
                                        */

  /*  Expression: zeros(1,4)
   * Referenced by: '<S39>/Memory'
   */
  { 0.0, 0.0, 0.0, 0.0 },
  0.0,                                 /* Expression: 0.0
                                        * Referenced by: '<S4>/parKdV2'
                                        */

  /*  Expression: zeros(1,4)
   * Referenced by: '<S40>/Memory'
   */
  { 0.0, 0.0, 0.0, 0.0 },
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S4>/parForceTrigger'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S28>/Memory'
                                        */
  0.5,                                 /* Expression: .5
                                        * Referenced by: '<S4>/parWiggleAmp'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S28>/Memory2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S28>/Memory1'
                                        */

  /*  Computed Parameter: PCI6221DA_P1_Size
   * Referenced by: '<S2>/PCI-6221 DA'
   */
  { 1.0, 2.0 },

  /*  Expression: channel
   * Referenced by: '<S2>/PCI-6221 DA'
   */
  { 1.0, 2.0 },

  /*  Computed Parameter: PCI6221DA_P2_Size
   * Referenced by: '<S2>/PCI-6221 DA'
   */
  { 1.0, 2.0 },

  /*  Expression: range
   * Referenced by: '<S2>/PCI-6221 DA'
   */
  { 0.0, 0.0 },

  /*  Computed Parameter: PCI6221DA_P3_Size
   * Referenced by: '<S2>/PCI-6221 DA'
   */
  { 1.0, 2.0 },

  /*  Expression: reset
   * Referenced by: '<S2>/PCI-6221 DA'
   */
  { 1.0, 1.0 },

  /*  Computed Parameter: PCI6221DA_P4_Size
   * Referenced by: '<S2>/PCI-6221 DA'
   */
  { 1.0, 2.0 },

  /*  Expression: initValue
   * Referenced by: '<S2>/PCI-6221 DA'
   */
  { 0.0, 0.0 },

  /*  Computed Parameter: PCI6221DA_P5_Size
   * Referenced by: '<S2>/PCI-6221 DA'
   */
  { 1.0, 1.0 },
  0.001,                               /* Expression: sampletime
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */

  /*  Computed Parameter: PCI6221DA_P6_Size
   * Referenced by: '<S2>/PCI-6221 DA'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: slot
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */

  /*  Computed Parameter: PCI6221DA_P7_Size
   * Referenced by: '<S2>/PCI-6221 DA'
   */
  { 1.0, 1.0 },
  21.0,                                /* Expression: boardType
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */

  /*  Computed Parameter: LowPass100Hz_A
   * Referenced by: '<S16>/Low Pass 100 Hz'
   */
  { 0.97351956087880709, -0.018600534405527919, 0.018600534405527915,
    0.9998246889024921 },

  /*  Computed Parameter: LowPass100Hz_B
   * Referenced by: '<S16>/Low Pass 100 Hz'
   */
  { 0.02630512802368495, 0.00024792733173036719 },

  /*  Computed Parameter: LowPass100Hz_C
   * Referenced by: '<S16>/Low Pass 100 Hz'
   */
  { 0.0065762820059212393, 0.707044799353615 },
  8.7655548754014668E-5,               /* Computed Parameter: LowPass100Hz_D
                                        * Referenced by: '<S16>/Low Pass 100 Hz'
                                        */

  /*  Expression: x0low
   * Referenced by: '<S16>/Low Pass 100 Hz'
   */
  { -0.0, 0.0 },

  /*  Computed Parameter: LowPass100Hz1_A
   * Referenced by: '<S16>/Low Pass 100 Hz1'
   */
  { 0.97351956087880709, -0.018600534405527919, 0.018600534405527915,
    0.9998246889024921 },

  /*  Computed Parameter: LowPass100Hz1_B
   * Referenced by: '<S16>/Low Pass 100 Hz1'
   */
  { 0.02630512802368495, 0.00024792733173036719 },

  /*  Computed Parameter: LowPass100Hz1_C
   * Referenced by: '<S16>/Low Pass 100 Hz1'
   */
  { 0.0065762820059212393, 0.707044799353615 },
  8.7655548754014668E-5,               /* Computed Parameter: LowPass100Hz1_D
                                        * Referenced by: '<S16>/Low Pass 100 Hz1'
                                        */

  /*  Expression: x0low
   * Referenced by: '<S16>/Low Pass 100 Hz1'
   */
  { -0.0, 0.0 },
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S4>/parMarker'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigPos1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigPos2'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigVel1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigVel2'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigPos1Des'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigPos2Des'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigVel1Des'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigVel2Des'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigForce1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigForce2'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigLoadC'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigLoadCF1a'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigLoadCF1b'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigLoadCF2a'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigLoadCF2b'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigForce1Clean'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigForce2Clean'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigGravAccel'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigTimeToThresh1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigTimeToThresh2'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/sigMarker'
                                        */

  /* Start of '<S93>/timeToTrigger' */
  {
    0.0,                               /* Expression: 0
                                        * Referenced by: '<S112>/Memory'
                                        */
    0.0                                /* Expression: 0
                                        * Referenced by: '<S112>/Memory1'
                                        */
  }
  /* End of '<S93>/timeToTrigger' */
  ,

  /* Start of '<S92>/timeToTrigger' */
  {
    0.0,                               /* Expression: 0
                                        * Referenced by: '<S99>/Memory'
                                        */
    0.0                                /* Expression: 0
                                        * Referenced by: '<S99>/Memory1'
                                        */
  }
  /* End of '<S92>/timeToTrigger' */
};
