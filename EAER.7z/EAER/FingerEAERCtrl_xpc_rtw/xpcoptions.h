#ifndef __FingerEAERCtrl_XPCOPTIONS_H___
#define __FingerEAERCtrl_XPCOPTIONS_H___
#include "simstruc_types.h"
#ifndef MT
#define MT                             0                         /* MT may be undefined by simstruc_types.h */
#endif

#include "FingerEAERCtrl.h"
#define XPCMDSSUPPORT                  0
#define MDSTASKSNUM                    0
#define FULLMULTITHREAD                0
#define SIZEOF_PARAMS                  (-1 * (int)sizeof(Parameters_FingerEAERCtrl))
#define SIMMODE                        0
#define LOGTET                         1
#define LOGBUFSIZE                     100000
#define PROFILINGFLAG                  0
#define EVENTNUMBER                    5000
#define IRQ_NO                         0
#define IO_IRQ                         0
#define WWW_ACCESS_LEVEL               0
#define CPUCLOCK                       0
#define MAXOVERLOAD                    0
#define MAXOVERLOADLEN                 0
#define XPCMODELSTACKSIZEKB            64
#define XPCSTARTUPFLAG                 1
#define PTLOADPARAMFLAG                0

/* Change all stepsize using the newBaseRateStepSize */
void FingerEAERCtrl_ChangeStepSize(real_T newBaseRateStepSize,
  rtModel_FingerEAERCtrl *const FingerEAERCtrl_rtM)
{
  real_T ratio = newBaseRateStepSize / 0.001;

  /* update non-zore stepsize of periodic
   * sample time. Stepsize of asynchronous
   * sample time is not changed in this function */
  FingerEAERCtrl_rtM->Timing.stepSize0 = FingerEAERCtrl_rtM->Timing.stepSize0 *
    ratio;
  FingerEAERCtrl_rtM->Timing.stepSize1 = FingerEAERCtrl_rtM->Timing.stepSize1 *
    ratio;
  FingerEAERCtrl_rtM->Timing.stepSize = FingerEAERCtrl_rtM->Timing.stepSize *
    ratio;
}

void XPCCALLCONV changeStepSize(real_T stepSize)
{
  /* Change all stepsize using the newBaseRateStepSize */
  FingerEAERCtrl_ChangeStepSize(stepSize, FingerEAERCtrl_rtM);
}

#endif                                 /* __FingerEAERCtrl_XPCOPTIONS_H___ */
