/*
 * FingerEAERCtrl_dt.h
 *
 * Code generation for model "FingerEAERCtrl".
 *
 * Model version              : 1.750
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Thu Apr 28 15:02:04 2016
 *
 * Target selection: xpctarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ext_types.h"

/* data type size table */
static uint_T rtDataTypeSizes[] = {
  sizeof(real_T),
  sizeof(real32_T),
  sizeof(int8_T),
  sizeof(uint8_T),
  sizeof(int16_T),
  sizeof(uint16_T),
  sizeof(int32_T),
  sizeof(uint32_T),
  sizeof(boolean_T),
  sizeof(fcn_call_T),
  sizeof(int_T),
  sizeof(pointer_T),
  sizeof(action_T),
  2*sizeof(uint32_T)
};

/* data type name table */
static const char_T * rtDataTypeNames[] = {
  "real_T",
  "real32_T",
  "int8_T",
  "uint8_T",
  "int16_T",
  "uint16_T",
  "int32_T",
  "uint32_T",
  "boolean_T",
  "fcn_call_T",
  "int_T",
  "pointer_T",
  "action_T",
  "timer_uint32_pair_T"
};

/* data type transitions for block I/O structure */
static DataTypeTransition rtBTransitions[] = {
  { (char_T *)(&FingerEAERCtrl_B.Integrator[0]), 0, 0, 231 },

  { (char_T *)(&FingerEAERCtrl_B.LogicalOperator), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_B.sf_triggercheck_c.update1), 0, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_B.sf_trajcalc_o.des[0]), 0, 0, 5 },

  { (char_T *)(&FingerEAERCtrl_B.timeToTrigger_e.Memory), 0, 0, 4 },

  { (char_T *)(&FingerEAERCtrl_B.saveTrialStartTime_o.trialStartTime), 0, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_B.paramsbuffer1_i.pDes), 0, 0, 3 },

  { (char_T *)(&FingerEAERCtrl_B.forcebuffer_c.force), 0, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction1_l.change), 0, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_B.sf_detectforceonset1_f.update), 0, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_B.sf_triggercheck.update1), 0, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_B.sf_trajcalc.des[0]), 0, 0, 5 },

  { (char_T *)(&FingerEAERCtrl_B.timeToTrigger.Memory), 0, 0, 4 },

  { (char_T *)(&FingerEAERCtrl_B.saveTrialStartTime.trialStartTime), 0, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_B.paramsbuffer1.pDes), 0, 0, 3 },

  { (char_T *)(&FingerEAERCtrl_B.forcebuffer.force), 0, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction1_k.change), 0, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_B.sf_detectforceonset1.update), 0, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_B.paramsbuffer_a.fixedDur), 0, 0, 3 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction1_h.change), 0, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction_j.des[0]), 0, 0, 5 },

  { (char_T *)(&FingerEAERCtrl_B.paramsbuffer_o.fixedDur), 0, 0, 3 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction1_g.change), 0, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction_c.des[0]), 0, 0, 5 },

  { (char_T *)(&FingerEAERCtrl_B.paramsbuffer_i.fixedDur), 0, 0, 4 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction1_m.change), 0, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction_i.des[0]), 0, 0, 3 },

  { (char_T *)(&FingerEAERCtrl_B.paramsbuffer_k.fixedDur), 0, 0, 4 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction1.change), 0, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction_mh.des[0]), 0, 0, 3 },

  { (char_T *)(&FingerEAERCtrl_B.paramsbuffer_b.pDes), 0, 0, 3 },

  { (char_T *)(&FingerEAERCtrl_B.sf_detectmovementonset_m.update), 0, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_B.sf_detectforceonset_m.update), 0, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction_p.des[0]), 0, 0, 3 },

  { (char_T *)(&FingerEAERCtrl_B.paramsbuffer.pDes), 0, 0, 3 },

  { (char_T *)(&FingerEAERCtrl_B.sf_detectmovementonset.update), 0, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_B.sf_detectforceonset.update), 0, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction_g.des[0]), 0, 0, 3 },

  { (char_T *)(&FingerEAERCtrl_B.sf_gainramp_a.val), 0, 0, 5 },

  { (char_T *)(&FingerEAERCtrl_B.sf_gainramp_f.val), 0, 0, 5 },

  { (char_T *)(&FingerEAERCtrl_B.sf_gainramp_b.val), 0, 0, 5 },

  { (char_T *)(&FingerEAERCtrl_B.sf_gainramp_id.val), 0, 0, 5 },

  { (char_T *)(&FingerEAERCtrl_B.sf_gainramp_i.val), 0, 0, 5 },

  { (char_T *)(&FingerEAERCtrl_B.sf_gainramp_o.val), 0, 0, 5 },

  { (char_T *)(&FingerEAERCtrl_B.sf_gainramp.val), 0, 0, 5 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction.output1), 0, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction_e.output1), 0, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_B.sf_MATLABFunction_my.output1), 0, 0, 2 }
  ,

  { (char_T *)(&FingerEAERCtrl_DWork.UD_DSTATE), 0, 0, 66 },

  { (char_T *)(&FingerEAERCtrl_DWork.PCI6221AD1_PWORK), 11, 0, 3 },

  { (char_T *)(&FingerEAERCtrl_DWork.sfEvent), 6, 0, 8 },

  { (char_T *)(&FingerEAERCtrl_DWork.PCI6221AD1_IWORK[0]), 10, 0, 86 },

  { (char_T *)(&FingerEAERCtrl_DWork.is_active_c42_FingerEAERCtrl), 3, 0, 8 },

  { (char_T *)(&FingerEAERCtrl_DWork.isStable), 8, 0, 16 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_triggercheck_c.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_triggercheck_c.is_active_c55_FingerEAERCtrl), 3, 0,
    1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_triggercheck_c.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_trajcalc_o.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_trajcalc_o.is_active_c23_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_trajcalc_o.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.timeToTrigger_e.Memory_PreviousInput), 0, 0,
    2 },

  { (char_T *)(&FingerEAERCtrl_DWork.timeToTrigger_e.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.timeToTrigger_e.timeToTrigger_SubsysRanBC),
    2, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.timeToTrigger_e.is_active_c53_FingerEAERCtrl), 3, 0,
    1 },

  { (char_T *)(&FingerEAERCtrl_DWork.timeToTrigger_e.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.saveTrialStartTime_o.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.saveTrialStartTime_o.saveTrialStartTime_SubsysRanBC),
    2, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.saveTrialStartTime_o.is_active_c52_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.saveTrialStartTime_o.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer1_i.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer1_i.paramsbuffer1_SubsysRanBC),
    2, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.paramsbuffer1_i.is_active_c51_FingerEAERCtrl), 3, 0,
    1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer1_i.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.forcebuffer_c.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.forcebuffer_c.forcebuffer_SubsysRanBC), 2,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.forcebuffer_c.is_active_c50_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.forcebuffer_c.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction1_l.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction1_l.is_active_c49_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction1_l.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_detectforceonset1_f.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_detectforceonset1_f.is_active_c32_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_detectforceonset1_f.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_triggercheck.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_triggercheck.is_active_c55_FingerEAERCtrl), 3, 0,
    1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_triggercheck.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_trajcalc.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_trajcalc.is_active_c23_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_trajcalc.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.timeToTrigger.Memory_PreviousInput), 0, 0,
    2 },

  { (char_T *)(&FingerEAERCtrl_DWork.timeToTrigger.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.timeToTrigger.timeToTrigger_SubsysRanBC), 2,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.timeToTrigger.is_active_c53_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.timeToTrigger.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.saveTrialStartTime.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.saveTrialStartTime.saveTrialStartTime_SubsysRanBC), 2,
    0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.saveTrialStartTime.is_active_c52_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.saveTrialStartTime.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer1.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer1.paramsbuffer1_SubsysRanBC), 2,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer1.is_active_c51_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer1.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.forcebuffer.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.forcebuffer.forcebuffer_SubsysRanBC), 2, 0,
    1 },

  { (char_T *)(&FingerEAERCtrl_DWork.forcebuffer.is_active_c50_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.forcebuffer.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction1_k.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction1_k.is_active_c49_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction1_k.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_detectforceonset1.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_detectforceonset1.is_active_c32_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_detectforceonset1.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_a.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_a.paramsbuffer_SubsysRanBC), 2,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_a.is_active_c7_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_a.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction1_h.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction1_h.is_active_c36_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction1_h.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_j.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction_j.is_active_c5_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_j.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_o.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_o.paramsbuffer_SubsysRanBC), 2,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_o.is_active_c7_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_o.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction1_g.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction1_g.is_active_c36_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction1_g.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_c.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction_c.is_active_c5_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_c.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_i.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_i.paramsbuffer_SubsysRanBC), 2,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_i.is_active_c38_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_i.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction1_m.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction1_m.is_active_c36_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction1_m.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_i.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction_i.is_active_c34_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_i.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_k.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_k.paramsbuffer_SubsysRanBC), 2,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_k.is_active_c38_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_k.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction1.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction1.is_active_c36_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction1.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_mh.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction_mh.is_active_c34_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_mh.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_b.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_b.paramsbuffer_SubsysRanBC), 2,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_b.is_active_c3_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer_b.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_detectmovementonset_m.sfEvent), 6, 0, 1
  },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_detectmovementonset_m.is_active_c1_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_detectmovementonset_m.isStable), 8, 0, 2
  },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_detectforceonset_m.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_detectforceonset_m.is_active_c46_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_detectforceonset_m.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_p.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction_p.is_active_c4_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_p.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer.paramsbuffer_SubsysRanBC), 2,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer.is_active_c3_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.paramsbuffer.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_detectmovementonset.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_detectmovementonset.is_active_c1_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_detectmovementonset.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_detectforceonset.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_detectforceonset.is_active_c46_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_detectforceonset.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_g.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction_g.is_active_c4_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_g.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_a.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_a.is_active_c8_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_a.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_f.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_f.is_active_c8_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_f.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_b.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_b.is_active_c8_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_b.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_id.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_id.is_active_c8_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_id.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_i.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_i.is_active_c8_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_i.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_o.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_o.is_active_c8_FingerEAERCtrl),
    3, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp_o.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp.sfEvent), 6, 0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp.is_active_c8_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_gainramp.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction.is_active_c11_FingerEAERCtrl), 3, 0,
    1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_e.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction_e.is_active_c11_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_e.isStable), 8, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_my.sfEvent), 6, 0, 1 },

  { (char_T *)
    (&FingerEAERCtrl_DWork.sf_MATLABFunction_my.is_active_c11_FingerEAERCtrl), 3,
    0, 1 },

  { (char_T *)(&FingerEAERCtrl_DWork.sf_MATLABFunction_my.isStable), 8, 0, 2 }
};

/* data type transition table for block I/O structure */
static DataTypeTransitionTable rtBTransTable = {
  208U,
  rtBTransitions
};

/* data type transitions for Parameters structure */
static DataTypeTransition rtPTransitions[] = {
  { (char_T *)(&FingerEAERCtrl_P.ForceOn_Value), 0, 0, 319 },

  { (char_T *)(&FingerEAERCtrl_P.timeToTrigger_e.Memory_X0), 0, 0, 2 },

  { (char_T *)(&FingerEAERCtrl_P.timeToTrigger.Memory_X0), 0, 0, 2 }
};

/* data type transition table for Parameters structure */
static DataTypeTransitionTable rtPTransTable = {
  3U,
  rtPTransitions
};

/* [EOF] FingerEAERCtrl_dt.h */
