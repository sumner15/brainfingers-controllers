/*
 * FingerEAERCtrl_capi.c
 *
 * Code generation for model "FingerEAERCtrl".
 *
 * Model version              : 1.750
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Thu Apr 28 15:02:04 2016
 *
 * Target selection: xpctarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "FingerEAERCtrl.h"
#include "rtw_capi.h"
#include "FingerEAERCtrl_private.h"

/* Block output signal information */
static const rtwCAPI_Signals rtBlockSignals[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  { 0, 0, "Robot/Gain",
    "", 0, 0, 0, 0, 0 },

  { 1, 0, "Robot/Gain1",
    "", 0, 0, 0, 0, 0 },

  { 2, 0, "Robot/PCI 6221 ENC ",
    "", 0, 0, 0, 0, 0 },

  { 3, 0, "Robot/PCI 6221 ENC 1",
    "", 0, 0, 0, 0, 0 },

  { 4, 0, "Robot/PCI-6221 AD1/p1",
    "", 0, 0, 0, 0, 0 },

  { 5, 0, "Robot/PCI-6221 AD1/p2",
    "", 1, 0, 0, 0, 0 },

  { 6, 0, "Robot/PCI-6221 AD1/p3",
    "", 2, 0, 0, 0, 0 },

  { 7, 0, "Robot/PCI-6221 AD1/p4",
    "", 3, 0, 0, 0, 0 },

  { 8, 0, "Robot/PCI-6221 AD1/p5",
    "", 4, 0, 0, 0, 0 },

  { 9, 0, "Robot/PCI-6221 AD1/p6",
    "", 5, 0, 0, 0, 0 },

  { 10, 0, "Robot/PCI-6221 AD1/p7",
    "", 6, 0, 0, 0, 0 },

  { 11, 0, "Robot/PCI-6221 AD1/p8",
    "", 7, 0, 0, 0, 0 },

  { 12, 6, "controller/controller",
    "Forces", 0, 0, 1, 0, 0 },

  { 13, 12, "controller/viccosityAdder",
    "Forces", 0, 0, 1, 0, 0 },

  { 14, 0, "controller/Product",
    "", 0, 0, 1, 0, 0 },

  { 15, 0, "controller/Saturation",
    "", 0, 0, 0, 0, 0 },

  { 16, 0, "controller/Add",
    "", 0, 0, 1, 0, 0 },

  { 17, 0, "parameters/parChangeRate",
    "", 0, 0, 0, 0, 0 },

  { 18, 0, "parameters/parFThresh",
    "", 0, 0, 0, 0, 0 },

  { 19, 0, "parameters/parFixedDur",
    "", 0, 0, 0, 0, 0 },

  { 20, 0, "parameters/parForceTrigger",
    "", 0, 0, 0, 0, 0 },

  { 21, 0, "parameters/parKd1",
    "", 0, 0, 0, 0, 0 },

  { 22, 0, "parameters/parKd2",
    "", 0, 0, 0, 0, 0 },

  { 23, 0, "parameters/parKdV1",
    "", 0, 0, 0, 0, 0 },

  { 24, 0, "parameters/parKdV2",
    "", 0, 0, 0, 0, 0 },

  { 25, 0, "parameters/parKp1",
    "", 0, 0, 0, 0, 0 },

  { 26, 0, "parameters/parKp2",
    "", 0, 0, 0, 0, 0 },

  { 27, 0, "parameters/parLeftMode",
    "", 0, 0, 0, 0, 0 },

  { 28, 0, "parameters/parMarker",
    "", 0, 0, 0, 0, 0 },

  { 29, 0, "parameters/parMaxTrajDur",
    "", 0, 0, 0, 0, 0 },

  { 30, 0, "parameters/parPStop",
    "", 0, 0, 0, 0, 0 },

  { 31, 0, "parameters/parTrajMode",
    "", 0, 0, 0, 0, 0 },

  { 32, 0, "parameters/parVThresh",
    "", 0, 0, 0, 0, 0 },

  { 33, 0, "parameters/parWiggleAmp",
    "", 0, 0, 0, 0, 0 },

  { 34, 0, "parameters/Rounding Function",
    "", 0, 0, 0, 0, 0 },

  { 35, 0, "parameters/Saturation",
    "", 0, 0, 0, 0, 0 },

  { 36, 0, "parameters/Saturation1",
    "", 0, 0, 0, 0, 0 },

  { 37, 0, "parameters/Saturation2",
    "", 0, 0, 0, 0, 0 },

  { 38, 0, "signals/Digital Clock",
    "", 0, 0, 0, 0, 0 },

  { 39, 0, "signals/sigForce1",
    "", 0, 0, 0, 0, 0 },

  { 40, 0, "signals/sigForce1Clean",
    "", 0, 0, 0, 0, 0 },

  { 41, 0, "signals/sigForce2",
    "", 0, 0, 0, 0, 0 },

  { 42, 0, "signals/sigForce2Clean",
    "", 0, 0, 0, 0, 0 },

  { 43, 0, "signals/sigGravAccel",
    "", 0, 0, 0, 0, 0 },

  { 44, 0, "signals/sigLoadC",
    "", 0, 0, 0, 0, 0 },

  { 45, 0, "signals/sigLoadCF1a",
    "", 0, 0, 0, 0, 0 },

  { 46, 0, "signals/sigLoadCF1b",
    "", 0, 0, 0, 0, 0 },

  { 47, 0, "signals/sigLoadCF2a",
    "", 0, 0, 0, 0, 0 },

  { 48, 0, "signals/sigLoadCF2b",
    "", 0, 0, 0, 0, 0 },

  { 49, 0, "signals/sigMarker",
    "", 0, 0, 0, 0, 0 },

  { 50, 0, "signals/sigPos1",
    "", 0, 0, 0, 0, 0 },

  { 51, 0, "signals/sigPos1Des",
    "", 0, 0, 0, 0, 0 },

  { 52, 0, "signals/sigPos2",
    "", 0, 0, 0, 0, 0 },

  { 53, 0, "signals/sigPos2Des",
    "", 0, 0, 0, 0, 0 },

  { 54, 0, "signals/sigTargetTime",
    "", 0, 0, 0, 0, 0 },

  { 55, 0, "signals/sigTimeToThresh1",
    "", 0, 0, 0, 0, 0 },

  { 56, 0, "signals/sigTimeToThresh2",
    "", 0, 0, 0, 0, 0 },

  { 57, 0, "signals/sigVel1",
    "", 0, 0, 0, 0, 0 },

  { 58, 0, "signals/sigVel1Des",
    "", 0, 0, 0, 0, 0 },

  { 59, 0, "signals/sigVel2",
    "", 0, 0, 0, 0, 0 },

  { 60, 0, "signals/sigVel2Des",
    "", 0, 0, 0, 0, 0 },

  { 61, 0, "trajectory calculator/Multiport Switch",
    "", 0, 0, 2, 0, 0 },

  { 62, 0, "trajectory params/parP1Des",
    "", 0, 0, 0, 0, 0 },

  { 63, 0, "trajectory params/parP2Des",
    "", 0, 0, 0, 0, 0 },

  { 64, 0, "trajectory params/parTHit1",
    "", 0, 0, 0, 0, 0 },

  { 65, 0, "trajectory params/parTHit2",
    "", 0, 0, 0, 0, 0 },

  { 66, 0, "Kalman Filter/kalman1/A",
    "", 0, 0, 3, 0, 1 },

  { 67, 0, "Kalman Filter/kalman1/B",
    "", 0, 0, 3, 0, 0 },

  { 68, 0, "Kalman Filter/kalman1/B1",
    "", 0, 0, 0, 0, 0 },

  { 69, 0, "Kalman Filter/kalman1/B2",
    "", 0, 0, 0, 0, 1 },

  { 70, 0, "Kalman Filter/kalman1/B3",
    "", 0, 0, 0, 0, 1 },

  { 71, 0, "Kalman Filter/kalman1/C",
    "", 0, 0, 0, 0, 1 },

  { 72, 0, "Kalman Filter/kalman1/K",
    "", 0, 0, 3, 0, 1 },

  { 73, 0, "Kalman Filter/kalman1/Integrator",
    "", 0, 0, 3, 0, 1 },

  { 74, 0, "Kalman Filter/kalman1/Sum2",
    "", 0, 0, 0, 0, 1 },

  { 75, 0, "Kalman Filter/kalman1/Sum3",
    "", 0, 0, 3, 0, 1 },

  { 76, 0, "Kalman Filter/kalman1/Sum4",
    "", 0, 0, 3, 0, 1 },

  { 77, 0, "Kalman Filter/kalman2/A",
    "", 0, 0, 3, 0, 1 },

  { 78, 0, "Kalman Filter/kalman2/B",
    "", 0, 0, 3, 0, 0 },

  { 79, 0, "Kalman Filter/kalman2/B1",
    "", 0, 0, 0, 0, 0 },

  { 80, 0, "Kalman Filter/kalman2/B2",
    "", 0, 0, 0, 0, 1 },

  { 81, 0, "Kalman Filter/kalman2/B3",
    "", 0, 0, 0, 0, 1 },

  { 82, 0, "Kalman Filter/kalman2/C",
    "", 0, 0, 0, 0, 1 },

  { 83, 0, "Kalman Filter/kalman2/K",
    "", 0, 0, 3, 0, 1 },

  { 84, 0, "Kalman Filter/kalman2/Integrator",
    "", 0, 0, 3, 0, 1 },

  { 85, 0, "Kalman Filter/kalman2/Sum2",
    "", 0, 0, 0, 0, 1 },

  { 86, 0, "Kalman Filter/kalman2/Sum3",
    "", 0, 0, 3, 0, 1 },

  { 87, 0, "Kalman Filter/kalman2/Sum4",
    "", 0, 0, 3, 0, 1 },

  { 88, 1, "Robot/account for handedness/MATLAB Function/p1",
    "output1", 0, 0, 0, 0, 0 },

  { 89, 1, "Robot/account for handedness/MATLAB Function/p2",
    "output2", 1, 0, 0, 0, 0 },

  { 90, 2, "Robot/account for handedness force/MATLAB Function",
    "output", 0, 0, 4, 0, 0 },

  { 91, 3, "Robot/account for handedness1/MATLAB Function/p1",
    "output1", 0, 0, 0, 0, 0 },

  { 92, 3, "Robot/account for handedness1/MATLAB Function/p2",
    "output2", 1, 0, 0, 0, 0 },

  { 93, 4, "Robot/account for handedness2/MATLAB Function/p1",
    "output1", 0, 0, 0, 0, 0 },

  { 94, 4, "Robot/account for handedness2/MATLAB Function/p2",
    "output2", 1, 0, 0, 0, 0 },

  { 95, 0, "Robot/filtered force output/Low Pass 100 Hz",
    "", 0, 0, 0, 0, 0 },

  { 96, 0, "Robot/filtered force output/Low Pass 100 Hz1",
    "", 0, 0, 0, 0, 0 },

  { 97, 0, "Robot/filtered force output/Memory",
    "", 0, 0, 0, 0, 0 },

  { 98, 0, "Robot/filtered force output/Memory1",
    "", 0, 0, 0, 0, 0 },

  { 99, 5, "Robot/get offsets/MATLAB Function/p1",
    "encoder1", 0, 0, 0, 0, 0 },

  { 100, 5, "Robot/get offsets/MATLAB Function/p2",
    "encoder2", 1, 0, 0, 0, 0 },

  { 101, 5, "Robot/get offsets/MATLAB Function/p3",
    "summedVals", 2, 0, 1, 0, 0 },

  { 102, 5, "Robot/get offsets/MATLAB Function/p4",
    "nSamples", 3, 0, 0, 0, 0 },

  { 103, 0, "Robot/get offsets/Digital Clock",
    "", 0, 0, 0, 0, 0 },

  { 104, 0, "Robot/get offsets/Memory",
    "", 0, 0, 0, 0, 0 },

  { 105, 0, "Robot/get offsets/Memory1",
    "", 0, 0, 1, 0, 0 },

  { 106, 0, "Robot/gravDir/gain",
    "", 0, 0, 0, 0, 0 },

  { 107, 0, "Robot/gravDir/Sum",
    "", 0, 0, 0, 0, 0 },

  { 108, 7, "controller/gain transition/gainramp/p1",
    "val", 0, 0, 0, 0, 0 },

  { 109, 7, "controller/gain transition/gainramp/p2",
    "state1", 1, 0, 5, 0, 0 },

  { 110, 0, "controller/gain transition/Memory",
    "", 0, 0, 5, 0, 0 },

  { 111, 8, "controller/initial ramp/MATLAB Function",
    "Force", 0, 0, 1, 0, 0 },

  { 112, 9, "controller/initial ramp/ramp",
    "y", 0, 0, 0, 0, 0 },

  { 113, 0, "controller/initial ramp/Saturation1",
    "", 0, 0, 0, 0, 0 },

  { 114, 10, "controller/make chirp/MATLAB Function/p1",
    "f1", 0, 0, 0, 0, 0 },

  { 115, 10, "controller/make chirp/MATLAB Function/p2",
    "f2", 1, 0, 0, 0, 0 },

  { 116, 10, "controller/make chirp/MATLAB Function/p3",
    "tStart_", 2, 0, 0, 0, 0 },

  { 117, 10, "controller/make chirp/MATLAB Function/p4",
    "fNum_", 3, 0, 0, 0, 0 },

  { 118, 11, "controller/make chirp/MATLAB Function1/p1",
    "pulse", 0, 0, 0, 0, 0 },

  { 119, 11, "controller/make chirp/MATLAB Function1/p2",
    "oldTrigger_", 1, 0, 0, 0, 0 },

  { 120, 0, "controller/make chirp/Memory",
    "", 0, 0, 0, 0, 0 },

  { 121, 0, "controller/make chirp/Memory1",
    "", 0, 0, 0, 0, 0 },

  { 122, 0, "controller/make chirp/Memory2",
    "", 0, 0, 0, 0, 0 },

  { 123, 13, "parameters/gain transition/gainramp/p1",
    "val", 0, 0, 0, 0, 0 },

  { 124, 13, "parameters/gain transition/gainramp/p2",
    "state1", 1, 0, 5, 0, 0 },

  { 125, 0, "parameters/gain transition/Memory",
    "", 0, 0, 5, 0, 0 },

  { 126, 14, "parameters/gain transition1/gainramp/p1",
    "val", 0, 0, 0, 0, 0 },

  { 127, 14, "parameters/gain transition1/gainramp/p2",
    "state1", 1, 0, 5, 0, 0 },

  { 128, 0, "parameters/gain transition1/Memory",
    "", 0, 0, 5, 0, 0 },

  { 129, 15, "parameters/gain transition2/gainramp/p1",
    "val", 0, 0, 0, 0, 0 },

  { 130, 15, "parameters/gain transition2/gainramp/p2",
    "state1", 1, 0, 5, 0, 0 },

  { 131, 0, "parameters/gain transition2/Memory",
    "", 0, 0, 5, 0, 0 },

  { 132, 16, "parameters/gain transition3/gainramp/p1",
    "val", 0, 0, 0, 0, 0 },

  { 133, 16, "parameters/gain transition3/gainramp/p2",
    "state1", 1, 0, 5, 0, 0 },

  { 134, 0, "parameters/gain transition3/Memory",
    "", 0, 0, 5, 0, 0 },

  { 135, 17, "parameters/gain transition4/gainramp/p1",
    "val", 0, 0, 0, 0, 0 },

  { 136, 17, "parameters/gain transition4/gainramp/p2",
    "state1", 1, 0, 5, 0, 0 },

  { 137, 0, "parameters/gain transition4/Memory",
    "", 0, 0, 5, 0, 0 },

  { 138, 18, "parameters/gain transition5/gainramp/p1",
    "val", 0, 0, 0, 0, 0 },

  { 139, 18, "parameters/gain transition5/gainramp/p2",
    "state1", 1, 0, 5, 0, 0 },

  { 140, 0, "parameters/gain transition5/Memory",
    "", 0, 0, 5, 0, 0 },

  { 141, 0, "Kalman Filter/kalman1/Discrete Derivative/Diff",
    "", 0, 0, 0, 0, 0 },

  { 142, 0, "Kalman Filter/kalman1/Discrete Derivative/TSamp",
    "", 0, 0, 0, 0, 0 },

  { 143, 0, "Kalman Filter/kalman1/Discrete Derivative/UD",
    "U(k-1)", 0, 0, 0, 0, 0 },

  { 144, 0, "Kalman Filter/kalman2/Discrete Derivative/Diff",
    "", 0, 0, 0, 0, 0 },

  { 145, 0, "Kalman Filter/kalman2/Discrete Derivative/TSamp",
    "", 0, 0, 0, 0, 0 },

  { 146, 0, "Kalman Filter/kalman2/Discrete Derivative/UD",
    "U(k-1)", 0, 0, 0, 0, 0 },

  { 147, 0, "trajectory calculator/mode 1: sub-init/get human force/Product",
    "", 0, 0, 0, 0, 0 },

  { 148, 0, "trajectory calculator/mode 1: sub-init/get human force/Product1",
    "", 0, 0, 0, 0, 0 },

  { 149, 19,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/MATLAB Function",
    "des", 0, 0, 3, 0, 0 },

  { 150, 20,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/detect force onset",
    "update", 0, 0, 0, 0, 0 },

  { 151, 21,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/detect movement onset",
    "update", 0, 0, 0, 0, 0 },

  { 152, 0,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/Logical Operator",
    "", 0, 1, 0, 0, 0 },

  { 153, 0,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/Memory",
    "", 0, 0, 0, 0, 0 },

  { 154, 24,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1/MATLAB Function",
    "des", 0, 0, 3, 0, 0 },

  { 155, 25,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1/detect force onset",
    "update", 0, 0, 0, 0, 0 },

  { 156, 26,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1/detect movement onset",
    "update", 0, 0, 0, 0, 0 },

  { 157, 0,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1/Logical Operator",
    "", 0, 1, 0, 0, 0 },

  { 158, 0,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1/Memory",
    "", 0, 0, 0, 0, 0 },

  { 159, 29,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/MATLAB Function",
    "des", 0, 0, 3, 0, 0 },

  { 160, 33,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory1/MATLAB Function",
    "des", 0, 0, 3, 0, 0 },

  { 161, 37,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/MATLAB Function/p1",
    "des", 0, 0, 3, 0, 0 },

  { 162, 37,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/MATLAB Function/p2",
    "Phold", 1, 0, 0, 0, 0 },

  { 163, 37,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/MATLAB Function/p3",
    "state", 2, 0, 0, 0, 0 },

  { 164, 0,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/Memory",
    "", 0, 0, 0, 0, 0 },

  { 165, 0,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/Memory1",
    "", 0, 0, 0, 0, 0 },

  { 166, 41,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/MATLAB Function/p1",
    "des", 0, 0, 3, 0, 0 },

  { 167, 41,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/MATLAB Function/p2",
    "Phold", 1, 0, 0, 0, 0 },

  { 168, 41,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/MATLAB Function/p3",
    "state", 2, 0, 0, 0, 0 },

  { 169, 0,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/Memory",
    "", 0, 0, 0, 0, 0 },

  { 170, 0,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/Memory1",
    "", 0, 0, 0, 0, 0 },

  { 171, 0,
    "trajectory calculator/mode 4: sub init no return/get human force/Product",
    "", 0, 0, 0, 0, 0 },

  { 172, 0,
    "trajectory calculator/mode 4: sub init no return/get human force/Product1",
    "", 0, 0, 0, 0, 0 },

  { 173, 45,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/detect force onset1/p1",
    "update", 0, 0, 0, 0, 0 },

  { 174, 45,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/detect force onset1/p2",
    "tDes", 1, 0, 0, 0, 0 },

  { 175, 55,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/traj calc/p1",
    "des", 0, 0, 3, 0, 0 },

  { 176, 55,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/traj calc/p2",
    "Phold", 1, 0, 0, 0, 0 },

  { 177, 55,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/traj calc/p3",
    "state", 2, 0, 0, 0, 0 },

  { 178, 56,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/trigger check/p1",
    "update1", 0, 0, 0, 0, 0 },

  { 179, 56,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/trigger check/p2",
    "tDesLast", 1, 0, 0, 0, 0 },

  { 180, 0,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/Gain",
    "", 0, 0, 0, 0, 0 },

  { 181, 0,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/pholdMem",
    "", 0, 0, 0, 0, 0 },

  { 182, 0,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/stateMem",
    "", 0, 0, 0, 0, 0 },

  { 183, 0,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/tDesMem",
    "", 0, 0, 0, 0, 0 },

  { 184, 57,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/detect force onset1/p1",
    "update", 0, 0, 0, 0, 0 },

  { 185, 57,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/detect force onset1/p2",
    "tDes", 1, 0, 0, 0, 0 },

  { 186, 67,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/traj calc/p1",
    "des", 0, 0, 3, 0, 0 },

  { 187, 67,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/traj calc/p2",
    "Phold", 1, 0, 0, 0, 0 },

  { 188, 67,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/traj calc/p3",
    "state", 2, 0, 0, 0, 0 },

  { 189, 68,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/trigger check/p1",
    "update1", 0, 0, 0, 0, 0 },

  { 190, 68,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/trigger check/p2",
    "tDesLast", 1, 0, 0, 0, 0 },

  { 191, 0,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/Gain",
    "", 0, 0, 0, 0, 0 },

  { 192, 0,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/pholdMem",
    "", 0, 0, 0, 0, 0 },

  { 193, 0,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/stateMem",
    "", 0, 0, 0, 0, 0 },

  { 194, 0,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/tDesMem",
    "", 0, 0, 0, 0, 0 },

  { 195, 22,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/params buffer/buffer the trajectory params/p1",
    "pDes", 0, 0, 0, 0, 2 },

  { 196, 22,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/params buffer/buffer the trajectory params/p2",
    "tHit", 1, 0, 0, 0, 2 },

  { 197, 22,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/params buffer/buffer the trajectory params/p3",
    "dur", 2, 0, 0, 0, 2 },

  { 198, 27,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1/params buffer/buffer the trajectory params/p1",
    "pDes", 0, 0, 0, 0, 2 },

  { 199, 27,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1/params buffer/buffer the trajectory params/p2",
    "tHit", 1, 0, 0, 0, 2 },

  { 200, 27,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1/params buffer/buffer the trajectory params/p3",
    "dur", 2, 0, 0, 0, 2 },

  { 201, 30,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/detect change/MATLAB Function1",
    "change", 0, 0, 0, 0, 0 },

  { 202, 0,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/detect change/Memory1",
    "", 0, 0, 0, 0, 0 },

  { 203, 32,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/params buffer/fixedDur",
    "", 0, 0, 0, 0, 2 },

  { 204, 31,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/params buffer/buffer the trajectory params/p1",
    "pDes", 0, 0, 0, 0, 2 },

  { 205, 31,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/params buffer/buffer the trajectory params/p2",
    "pos", 1, 0, 0, 0, 2 },

  { 206, 31,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/params buffer/buffer the trajectory params/p3",
    "tHit", 2, 0, 0, 0, 2 },

  { 207, 34,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory1/detect change/MATLAB Function1",
    "change", 0, 0, 0, 0, 0 },

  { 208, 0,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory1/detect change/Memory1",
    "", 0, 0, 0, 0, 0 },

  { 209, 36,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory1/params buffer/fixedDur",
    "", 0, 0, 0, 0, 2 },

  { 210, 35,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory1/params buffer/buffer the trajectory params/p1",
    "pDes", 0, 0, 0, 0, 2 },

  { 211, 35,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory1/params buffer/buffer the trajectory params/p2",
    "pos", 1, 0, 0, 0, 2 },

  { 212, 35,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory1/params buffer/buffer the trajectory params/p3",
    "tHit", 2, 0, 0, 0, 2 },

  { 213, 38,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/detect change/MATLAB Function1",
    "change", 0, 0, 0, 0, 0 },

  { 214, 0,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/detect change/Memory1",
    "", 0, 0, 0, 0, 0 },

  { 215, 40,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/params buffer/fixedDur",
    "", 0, 0, 0, 0, 2 },

  { 216, 39,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/params buffer/buffer the trajectory params/p1",
    "pDes", 0, 0, 0, 0, 2 },

  { 217, 39,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/params buffer/buffer the trajectory params/p2",
    "tHit", 1, 0, 0, 0, 2 },

  { 218, 42,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/detect change/MATLAB Function1",
    "change", 0, 0, 0, 0, 0 },

  { 219, 0,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/detect change/Memory1",
    "", 0, 0, 0, 0, 0 },

  { 220, 44,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/params buffer/fixedDur",
    "", 0, 0, 0, 0, 2 },

  { 221, 43,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/params buffer/buffer the trajectory params/p1",
    "pDes", 0, 0, 0, 0, 2 },

  { 222, 43,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/params buffer/buffer the trajectory params/p2",
    "tHit", 1, 0, 0, 0, 2 },

  { 223, 46,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/detect new trajectory/MATLAB Function1/p1",
    "change", 0, 0, 0, 0, 0 },

  { 224, 46,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/detect new trajectory/MATLAB Function1/p2",
    "tDesOut", 1, 0, 0, 0, 0 },

  { 225, 0,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/detect new trajectory/Memory2",
    "", 0, 0, 0, 0, 0 },

  { 226, 47,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/force buffer/buffer the initial force value",
    "force", 0, 0, 0, 0, 2 },

  { 227, 49,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/params buffer1/buffer the trajectory params/p1",
    "pDes", 0, 0, 0, 0, 2 },

  { 228, 49,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/params buffer1/buffer the trajectory params/p2",
    "tHit", 1, 0, 0, 0, 2 },

  { 229, 49,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/params buffer1/buffer the trajectory params/p3",
    "dur", 2, 0, 0, 0, 2 },

  { 230, 51,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/saveTrialStartTime/save the trial start time",
    "trialStartTime", 0, 0, 0, 0, 2 },

  { 231, 53,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/timeToTrigger/save the trigger time/p1",
    "triggerTime", 0, 0, 0, 0, 2 },

  { 232, 53,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/timeToTrigger/save the trigger time/p2",
    "lastStartT", 1, 0, 0, 0, 2 },

  { 233, 54,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/timeToTrigger/Memory",
    "", 0, 0, 0, 0, 2 },

  { 234, 54,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/timeToTrigger/Memory1",
    "", 0, 0, 0, 0, 2 },

  { 235, 58,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/detect new trajectory/MATLAB Function1/p1",
    "change", 0, 0, 0, 0, 0 },

  { 236, 58,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/detect new trajectory/MATLAB Function1/p2",
    "tDesOut", 1, 0, 0, 0, 0 },

  { 237, 0,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/detect new trajectory/Memory2",
    "", 0, 0, 0, 0, 0 },

  { 238, 59,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/force buffer/buffer the initial force value",
    "force", 0, 0, 0, 0, 2 },

  { 239, 61,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/params buffer1/buffer the trajectory params/p1",
    "pDes", 0, 0, 0, 0, 2 },

  { 240, 61,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/params buffer1/buffer the trajectory params/p2",
    "tHit", 1, 0, 0, 0, 2 },

  { 241, 61,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/params buffer1/buffer the trajectory params/p3",
    "dur", 2, 0, 0, 0, 2 },

  { 242, 63,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/saveTrialStartTime/save the trial start time",
    "trialStartTime", 0, 0, 0, 0, 2 },

  { 243, 65,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/timeToTrigger/save the trigger time/p1",
    "triggerTime", 0, 0, 0, 0, 2 },

  { 244, 65,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/timeToTrigger/save the trigger time/p2",
    "lastStartT", 1, 0, 0, 0, 2 },

  { 245, 66,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/timeToTrigger/Memory",
    "", 0, 0, 0, 0, 2 },

  { 246, 66,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/timeToTrigger/Memory1",
    "", 0, 0, 0, 0, 2 },

  {
    0, 0, NULL, NULL, 0, 0, 0, 0, 0
  }
};

/* Tunable block parameters */
static const rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 247, "Force On",
    "Value", 0, 0, 0 },

  { 248, "Robot/Gain",
    "Gain", 0, 0, 0 },

  { 249, "Robot/Gain1",
    "Gain", 0, 0, 0 },

  { 250, "Robot/PCI 6221 ENC ",
    "P1", 0, 0, 0 },

  { 251, "Robot/PCI 6221 ENC ",
    "P2", 0, 0, 0 },

  { 252, "Robot/PCI 6221 ENC ",
    "P3", 0, 0, 0 },

  { 253, "Robot/PCI 6221 ENC ",
    "P4", 0, 0, 0 },

  { 254, "Robot/PCI 6221 ENC ",
    "P5", 0, 0, 0 },

  { 255, "Robot/PCI 6221 ENC ",
    "P6", 0, 0, 0 },

  { 256, "Robot/PCI 6221 ENC ",
    "P7", 0, 0, 0 },

  { 257, "Robot/PCI 6221 ENC ",
    "P8", 0, 0, 0 },

  { 258, "Robot/PCI 6221 ENC ",
    "P9", 0, 0, 0 },

  { 259, "Robot/PCI 6221 ENC ",
    "P10", 0, 0, 0 },

  { 260, "Robot/PCI 6221 ENC 1",
    "P1", 0, 0, 0 },

  { 261, "Robot/PCI 6221 ENC 1",
    "P2", 0, 0, 0 },

  { 262, "Robot/PCI 6221 ENC 1",
    "P3", 0, 0, 0 },

  { 263, "Robot/PCI 6221 ENC 1",
    "P4", 0, 0, 0 },

  { 264, "Robot/PCI 6221 ENC 1",
    "P5", 0, 0, 0 },

  { 265, "Robot/PCI 6221 ENC 1",
    "P6", 0, 0, 0 },

  { 266, "Robot/PCI 6221 ENC 1",
    "P7", 0, 0, 0 },

  { 267, "Robot/PCI 6221 ENC 1",
    "P8", 0, 0, 0 },

  { 268, "Robot/PCI 6221 ENC 1",
    "P9", 0, 0, 0 },

  { 269, "Robot/PCI 6221 ENC 1",
    "P10", 0, 0, 0 },

  { 270, "Robot/PCI-6221 AD1",
    "P1", 0, 6, 0 },

  { 271, "Robot/PCI-6221 AD1",
    "P2", 0, 6, 0 },

  { 272, "Robot/PCI-6221 AD1",
    "P3", 0, 6, 0 },

  { 273, "Robot/PCI-6221 AD1",
    "P4", 0, 0, 0 },

  { 274, "Robot/PCI-6221 AD1",
    "P5", 0, 0, 0 },

  { 275, "Robot/PCI-6221 AD1",
    "P6", 0, 0, 0 },

  { 276, "Robot/PCI-6221 AD1",
    "P7", 0, 0, 0 },

  { 277, "Robot/PCI-6221 DA",
    "P1", 0, 7, 0 },

  { 278, "Robot/PCI-6221 DA",
    "P2", 0, 7, 0 },

  { 279, "Robot/PCI-6221 DA",
    "P3", 0, 7, 0 },

  { 280, "Robot/PCI-6221 DA",
    "P4", 0, 7, 0 },

  { 281, "Robot/PCI-6221 DA",
    "P5", 0, 0, 0 },

  { 282, "Robot/PCI-6221 DA",
    "P6", 0, 0, 0 },

  { 283, "Robot/PCI-6221 DA",
    "P7", 0, 0, 0 },

  { 284, "controller/Saturation",
    "UpperLimit", 0, 0, 0 },

  { 285, "controller/Saturation",
    "LowerLimit", 0, 0, 0 },

  { 286, "parameters/paremeters_ must_be_one",
    "Value", 0, 0, 0 },

  { 287, "parameters/parChangeRate",
    "Gain", 0, 0, 0 },

  { 288, "parameters/parFThresh",
    "Gain", 0, 0, 0 },

  { 289, "parameters/parFixedDur",
    "Gain", 0, 0, 0 },

  { 290, "parameters/parForceTrigger",
    "Gain", 0, 0, 0 },

  { 291, "parameters/parKd1",
    "Gain", 0, 0, 0 },

  { 292, "parameters/parKd2",
    "Gain", 0, 0, 0 },

  { 293, "parameters/parKdV1",
    "Gain", 0, 0, 0 },

  { 294, "parameters/parKdV2",
    "Gain", 0, 0, 0 },

  { 295, "parameters/parKp1",
    "Gain", 0, 0, 0 },

  { 296, "parameters/parKp2",
    "Gain", 0, 0, 0 },

  { 297, "parameters/parLeftMode",
    "Gain", 0, 0, 0 },

  { 298, "parameters/parMarker",
    "Gain", 0, 0, 0 },

  { 299, "parameters/parMaxTrajDur",
    "Gain", 0, 0, 0 },

  { 300, "parameters/parPStop",
    "Gain", 0, 0, 0 },

  { 301, "parameters/parTrajMode",
    "Gain", 0, 0, 0 },

  { 302, "parameters/parVThresh",
    "Gain", 0, 0, 0 },

  { 303, "parameters/parWiggleAmp",
    "Gain", 0, 0, 0 },

  { 304, "parameters/Saturation",
    "UpperLimit", 0, 0, 0 },

  { 305, "parameters/Saturation",
    "LowerLimit", 0, 0, 0 },

  { 306, "parameters/Saturation1",
    "UpperLimit", 0, 0, 0 },

  { 307, "parameters/Saturation1",
    "LowerLimit", 0, 0, 0 },

  { 308, "parameters/Saturation2",
    "UpperLimit", 0, 0, 0 },

  { 309, "parameters/Saturation2",
    "LowerLimit", 0, 0, 0 },

  { 310, "signals/sigForce1",
    "Gain", 0, 0, 0 },

  { 311, "signals/sigForce1Clean",
    "Gain", 0, 0, 0 },

  { 312, "signals/sigForce2",
    "Gain", 0, 0, 0 },

  { 313, "signals/sigForce2Clean",
    "Gain", 0, 0, 0 },

  { 314, "signals/sigGravAccel",
    "Gain", 0, 0, 0 },

  { 315, "signals/sigLoadC",
    "Gain", 0, 0, 0 },

  { 316, "signals/sigLoadCF1a",
    "Gain", 0, 0, 0 },

  { 317, "signals/sigLoadCF1b",
    "Gain", 0, 0, 0 },

  { 318, "signals/sigLoadCF2a",
    "Gain", 0, 0, 0 },

  { 319, "signals/sigLoadCF2b",
    "Gain", 0, 0, 0 },

  { 320, "signals/sigMarker",
    "Gain", 0, 0, 0 },

  { 321, "signals/sigPos1",
    "Gain", 0, 0, 0 },

  { 322, "signals/sigPos1Des",
    "Gain", 0, 0, 0 },

  { 323, "signals/sigPos2",
    "Gain", 0, 0, 0 },

  { 324, "signals/sigPos2Des",
    "Gain", 0, 0, 0 },

  { 325, "signals/sigTargetTime",
    "Gain", 0, 0, 0 },

  { 326, "signals/sigTimeToThresh1",
    "Gain", 0, 0, 0 },

  { 327, "signals/sigTimeToThresh2",
    "Gain", 0, 0, 0 },

  { 328, "signals/sigVel1",
    "Gain", 0, 0, 0 },

  { 329, "signals/sigVel1Des",
    "Gain", 0, 0, 0 },

  { 330, "signals/sigVel2",
    "Gain", 0, 0, 0 },

  { 331, "signals/sigVel2Des",
    "Gain", 0, 0, 0 },

  { 332, "trajectory params/unity_traj",
    "Value", 0, 0, 0 },

  { 333, "trajectory params/parP1Des",
    "Gain", 0, 0, 0 },

  { 334, "trajectory params/parP2Des",
    "Gain", 0, 0, 0 },

  { 335, "trajectory params/parTHit1",
    "Gain", 0, 0, 0 },

  { 336, "trajectory params/parTHit2",
    "Gain", 0, 0, 0 },

  { 337, "Kalman Filter/kalman1/A",
    "Gain", 0, 8, 0 },

  { 338, "Kalman Filter/kalman1/B",
    "Gain", 0, 3, 0 },

  { 339, "Kalman Filter/kalman1/B1",
    "Gain", 0, 0, 0 },

  { 340, "Kalman Filter/kalman1/B2",
    "Gain", 0, 0, 0 },

  { 341, "Kalman Filter/kalman1/B3",
    "Gain", 0, 0, 0 },

  { 342, "Kalman Filter/kalman1/C",
    "Gain", 0, 9, 0 },

  { 343, "Kalman Filter/kalman1/K",
    "Gain", 0, 3, 0 },

  { 344, "Kalman Filter/kalman1/Integrator",
    "InitialCondition", 0, 3, 0 },

  { 345, "Kalman Filter/kalman2/A",
    "Gain", 0, 8, 0 },

  { 346, "Kalman Filter/kalman2/B",
    "Gain", 0, 3, 0 },

  { 347, "Kalman Filter/kalman2/B1",
    "Gain", 0, 0, 0 },

  { 348, "Kalman Filter/kalman2/B2",
    "Gain", 0, 0, 0 },

  { 349, "Kalman Filter/kalman2/B3",
    "Gain", 0, 0, 0 },

  { 350, "Kalman Filter/kalman2/C",
    "Gain", 0, 9, 0 },

  { 351, "Kalman Filter/kalman2/K",
    "Gain", 0, 3, 0 },

  { 352, "Kalman Filter/kalman2/Integrator",
    "InitialCondition", 0, 3, 0 },

  { 353, "Robot/filtered force output/Low Pass 100 Hz",
    "A", 0, 5, 0 },

  { 354, "Robot/filtered force output/Low Pass 100 Hz",
    "B", 0, 1, 0 },

  { 355, "Robot/filtered force output/Low Pass 100 Hz",
    "C", 0, 1, 0 },

  { 356, "Robot/filtered force output/Low Pass 100 Hz",
    "D", 0, 0, 0 },

  { 357, "Robot/filtered force output/Low Pass 100 Hz",
    "X0", 0, 1, 0 },

  { 358, "Robot/filtered force output/Low Pass 100 Hz1",
    "A", 0, 5, 0 },

  { 359, "Robot/filtered force output/Low Pass 100 Hz1",
    "B", 0, 1, 0 },

  { 360, "Robot/filtered force output/Low Pass 100 Hz1",
    "C", 0, 1, 0 },

  { 361, "Robot/filtered force output/Low Pass 100 Hz1",
    "D", 0, 0, 0 },

  { 362, "Robot/filtered force output/Low Pass 100 Hz1",
    "X0", 0, 1, 0 },

  { 363, "Robot/filtered force output/Memory",
    "X0", 0, 0, 0 },

  { 364, "Robot/filtered force output/Memory1",
    "X0", 0, 0, 0 },

  { 365, "Robot/get offsets/Memory",
    "X0", 0, 0, 0 },

  { 366, "Robot/get offsets/Memory1",
    "X0", 0, 7, 0 },

  { 367, "Robot/gravDir/Constant",
    "Value", 0, 0, 0 },

  { 368, "Robot/gravDir/gain",
    "Gain", 0, 0, 0 },

  { 369, "controller/gain transition/Memory",
    "X0", 0, 10, 0 },

  { 370, "controller/initial ramp/Saturation1",
    "UpperLimit", 0, 0, 0 },

  { 371, "controller/initial ramp/Saturation1",
    "LowerLimit", 0, 0, 0 },

  { 372, "controller/make chirp/Memory",
    "X0", 0, 0, 0 },

  { 373, "controller/make chirp/Memory1",
    "X0", 0, 0, 0 },

  { 374, "controller/make chirp/Memory2",
    "X0", 0, 0, 0 },

  { 375, "parameters/gain transition/Memory",
    "X0", 0, 10, 0 },

  { 376, "parameters/gain transition1/Memory",
    "X0", 0, 10, 0 },

  { 377, "parameters/gain transition2/Memory",
    "X0", 0, 10, 0 },

  { 378, "parameters/gain transition3/Memory",
    "X0", 0, 10, 0 },

  { 379, "parameters/gain transition4/Memory",
    "X0", 0, 10, 0 },

  { 380, "parameters/gain transition5/Memory",
    "X0", 0, 10, 0 },

  { 381, "Kalman Filter/kalman1/Discrete Derivative/TSamp",
    "WtEt", 0, 0, 0 },

  { 382, "Kalman Filter/kalman1/Discrete Derivative/UD",
    "InitialCondition", 0, 0, 0 },

  { 383, "Kalman Filter/kalman2/Discrete Derivative/TSamp",
    "WtEt", 0, 0, 0 },

  { 384, "Kalman Filter/kalman2/Discrete Derivative/UD",
    "InitialCondition", 0, 0, 0 },

  { 385, "trajectory calculator/mode 1: sub-init/get human force/Constant",
    "Value", 0, 0, 0 },

  { 386,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/Memory",
    "X0", 0, 0, 0 },

  { 387,
    "trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1/Memory",
    "X0", 0, 0, 0 },

  { 388,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/Memory",
    "X0", 0, 0, 0 },

  { 389,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/Memory1",
    "X0", 0, 0, 0 },

  { 390,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/Memory",
    "X0", 0, 0, 0 },

  { 391,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/Memory1",
    "X0", 0, 0, 0 },

  { 392,
    "trajectory calculator/mode 4: sub init no return/get human force/Constant",
    "Value", 0, 0, 0 },

  { 393,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/Gain",
    "Gain", 0, 0, 0 },

  { 394,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/pholdMem",
    "X0", 0, 0, 0 },

  { 395,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/stateMem",
    "X0", 0, 0, 0 },

  { 396,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/tDesMem",
    "X0", 0, 0, 0 },

  { 397,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/Gain",
    "Gain", 0, 0, 0 },

  { 398,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/pholdMem",
    "X0", 0, 0, 0 },

  { 399,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/stateMem",
    "X0", 0, 0, 0 },

  { 400,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/tDesMem",
    "X0", 0, 0, 0 },

  { 401,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/detect change/Memory1",
    "X0", 0, 0, 0 },

  { 402,
    "trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory1/detect change/Memory1",
    "X0", 0, 0, 0 },

  { 403,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/detect change/Memory1",
    "X0", 0, 0, 0 },

  { 404,
    "trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/detect change/Memory1",
    "X0", 0, 0, 0 },

  { 405,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/detect new trajectory/Memory2",
    "X0", 0, 0, 0 },

  { 406,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/timeToTrigger/Memory",
    "X0", 0, 0, 0 },

  { 407,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/timeToTrigger/Memory1",
    "X0", 0, 0, 0 },

  { 408,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/detect new trajectory/Memory2",
    "X0", 0, 0, 0 },

  { 409,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/timeToTrigger/Memory",
    "X0", 0, 0, 0 },

  { 410,
    "trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/timeToTrigger/Memory1",
    "X0", 0, 0, 0 },

  {
    0, NULL, NULL, 0, 0, 0
  }
};

/* Tunable variable parameters */
static const rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 0, NULL, 0, 0, 0 }
};

/* Declare Data Addresses statically */
static void* rtDataAddrMap[] = {
  &FingerEAERCtrl_B.Gain,              /* 0: Signal */
  &FingerEAERCtrl_B.Gain1,             /* 1: Signal */
  &FingerEAERCtrl_B.PCI6221ENC,        /* 2: Signal */
  &FingerEAERCtrl_B.PCI6221ENC1,       /* 3: Signal */
  &FingerEAERCtrl_B.PCI6221AD1_o1,     /* 4: Signal */
  &FingerEAERCtrl_B.PCI6221AD1_o2,     /* 5: Signal */
  &FingerEAERCtrl_B.PCI6221AD1_o3,     /* 6: Signal */
  &FingerEAERCtrl_B.PCI6221AD1_o4,     /* 7: Signal */
  &FingerEAERCtrl_B.PCI6221AD1_o5,     /* 8: Signal */
  &FingerEAERCtrl_B.PCI6221AD1_o6,     /* 9: Signal */
  &FingerEAERCtrl_B.PCI6221AD1_o7,     /* 10: Signal */
  &FingerEAERCtrl_B.PCI6221AD1_o8,     /* 11: Signal */
  &FingerEAERCtrl_B.Forces_a[0],       /* 12: Signal */
  &FingerEAERCtrl_B.Forces[0],         /* 13: Signal */
  &FingerEAERCtrl_B.Product_m[0],      /* 14: Signal */
  &FingerEAERCtrl_B.Saturation_m,      /* 15: Signal */
  &FingerEAERCtrl_B.Add[0],            /* 16: Signal */
  &FingerEAERCtrl_B.parChangeRate,     /* 17: Signal */
  &FingerEAERCtrl_B.parFThresh,        /* 18: Signal */
  &FingerEAERCtrl_B.parFixedDur,       /* 19: Signal */
  &FingerEAERCtrl_B.parForceTrigger,   /* 20: Signal */
  &FingerEAERCtrl_B.parKd1,            /* 21: Signal */
  &FingerEAERCtrl_B.parKd2,            /* 22: Signal */
  &FingerEAERCtrl_B.parKdV1,           /* 23: Signal */
  &FingerEAERCtrl_B.parKdV2,           /* 24: Signal */
  &FingerEAERCtrl_B.parKp1,            /* 25: Signal */
  &FingerEAERCtrl_B.parKp2,            /* 26: Signal */
  &FingerEAERCtrl_B.parLeftMode,       /* 27: Signal */
  &FingerEAERCtrl_B.parMarker,         /* 28: Signal */
  &FingerEAERCtrl_B.parMaxTrajDur,     /* 29: Signal */
  &FingerEAERCtrl_B.parPStop,          /* 30: Signal */
  &FingerEAERCtrl_B.parTrajMode,       /* 31: Signal */
  &FingerEAERCtrl_B.parVThresh,        /* 32: Signal */
  &FingerEAERCtrl_B.parWiggleAmp,      /* 33: Signal */
  &FingerEAERCtrl_B.RoundingFunction,  /* 34: Signal */
  &FingerEAERCtrl_B.Saturation,        /* 35: Signal */
  &FingerEAERCtrl_B.Saturation1,       /* 36: Signal */
  &FingerEAERCtrl_B.Saturation2,       /* 37: Signal */
  &FingerEAERCtrl_B.DigitalClock_f,    /* 38: Signal */
  &FingerEAERCtrl_B.sigForce1,         /* 39: Signal */
  &FingerEAERCtrl_B.sigForce1Clean,    /* 40: Signal */
  &FingerEAERCtrl_B.sigForce2,         /* 41: Signal */
  &FingerEAERCtrl_B.sigForce2Clean,    /* 42: Signal */
  &FingerEAERCtrl_B.sigGravAccel,      /* 43: Signal */
  &FingerEAERCtrl_B.sigLoadC,          /* 44: Signal */
  &FingerEAERCtrl_B.sigLoadCF1a,       /* 45: Signal */
  &FingerEAERCtrl_B.sigLoadCF1b,       /* 46: Signal */
  &FingerEAERCtrl_B.sigLoadCF2a,       /* 47: Signal */
  &FingerEAERCtrl_B.sigLoadCF2b,       /* 48: Signal */
  &FingerEAERCtrl_B.sigMarker,         /* 49: Signal */
  &FingerEAERCtrl_B.sigPos1,           /* 50: Signal */
  &FingerEAERCtrl_B.sigPos1Des,        /* 51: Signal */
  &FingerEAERCtrl_B.sigPos2,           /* 52: Signal */
  &FingerEAERCtrl_B.sigPos2Des,        /* 53: Signal */
  &FingerEAERCtrl_B.sigTargetTime,     /* 54: Signal */
  &FingerEAERCtrl_B.sigTimeToThresh1,  /* 55: Signal */
  &FingerEAERCtrl_B.sigTimeToThresh2,  /* 56: Signal */
  &FingerEAERCtrl_B.sigVel1,           /* 57: Signal */
  &FingerEAERCtrl_B.sigVel1Des,        /* 58: Signal */
  &FingerEAERCtrl_B.sigVel2,           /* 59: Signal */
  &FingerEAERCtrl_B.sigVel2Des,        /* 60: Signal */
  &FingerEAERCtrl_B.MultiportSwitch[0],/* 61: Signal */
  &FingerEAERCtrl_B.parP1Des,          /* 62: Signal */
  &FingerEAERCtrl_B.parP2Des,          /* 63: Signal */
  &FingerEAERCtrl_B.parTHit1,          /* 64: Signal */
  &FingerEAERCtrl_B.parTHit2,          /* 65: Signal */
  &FingerEAERCtrl_B.A[0],              /* 66: Signal */
  &FingerEAERCtrl_B.B[0],              /* 67: Signal */
  &FingerEAERCtrl_B.B1,                /* 68: Signal */
  &FingerEAERCtrl_B.B2,                /* 69: Signal */
  &FingerEAERCtrl_B.B3,                /* 70: Signal */
  &FingerEAERCtrl_B.C,                 /* 71: Signal */
  &FingerEAERCtrl_B.K[0],              /* 72: Signal */
  &FingerEAERCtrl_B.Integrator[0],     /* 73: Signal */
  &FingerEAERCtrl_B.Sum2,              /* 74: Signal */
  &FingerEAERCtrl_B.Sum3[0],           /* 75: Signal */
  &FingerEAERCtrl_B.Sum4[0],           /* 76: Signal */
  &FingerEAERCtrl_B.A_o[0],            /* 77: Signal */
  &FingerEAERCtrl_B.B_d[0],            /* 78: Signal */
  &FingerEAERCtrl_B.B1_o,              /* 79: Signal */
  &FingerEAERCtrl_B.B2_o,              /* 80: Signal */
  &FingerEAERCtrl_B.B3_l,              /* 81: Signal */
  &FingerEAERCtrl_B.C_m,               /* 82: Signal */
  &FingerEAERCtrl_B.K_d[0],            /* 83: Signal */
  &FingerEAERCtrl_B.Integrator_a[0],   /* 84: Signal */
  &FingerEAERCtrl_B.Sum2_j,            /* 85: Signal */
  &FingerEAERCtrl_B.Sum3_j[0],         /* 86: Signal */
  &FingerEAERCtrl_B.Sum4_l[0],         /* 87: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction_my.output1,/* 88: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction_my.output2,/* 89: Signal */
  &FingerEAERCtrl_B.output[0],         /* 90: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction_e.output1,/* 91: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction_e.output2,/* 92: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction.output1,/* 93: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction.output2,/* 94: Signal */
  &FingerEAERCtrl_B.LowPass100Hz,      /* 95: Signal */
  &FingerEAERCtrl_B.LowPass100Hz1,     /* 96: Signal */
  &FingerEAERCtrl_B.Memory_n,          /* 97: Signal */
  &FingerEAERCtrl_B.Memory1_j,         /* 98: Signal */
  &FingerEAERCtrl_B.encoder1,          /* 99: Signal */
  &FingerEAERCtrl_B.encoder2,          /* 100: Signal */
  &FingerEAERCtrl_B.summedVals[0],     /* 101: Signal */
  &FingerEAERCtrl_B.nSamples,          /* 102: Signal */
  &FingerEAERCtrl_B.DigitalClock,      /* 103: Signal */
  &FingerEAERCtrl_B.Memory,            /* 104: Signal */
  &FingerEAERCtrl_B.Memory1[0],        /* 105: Signal */
  &FingerEAERCtrl_B.gain,              /* 106: Signal */
  &FingerEAERCtrl_B.Sum,               /* 107: Signal */
  &FingerEAERCtrl_B.sf_gainramp.val,   /* 108: Signal */
  &FingerEAERCtrl_B.sf_gainramp.state1[0],/* 109: Signal */
  &FingerEAERCtrl_B.Memory_c[0],       /* 110: Signal */
  &FingerEAERCtrl_B.Force[0],          /* 111: Signal */
  &FingerEAERCtrl_B.y,                 /* 112: Signal */
  &FingerEAERCtrl_B.Saturation1_i,     /* 113: Signal */
  &FingerEAERCtrl_B.f1,                /* 114: Signal */
  &FingerEAERCtrl_B.f2,                /* 115: Signal */
  &FingerEAERCtrl_B.tStart_,           /* 116: Signal */
  &FingerEAERCtrl_B.fNum_,             /* 117: Signal */
  &FingerEAERCtrl_B.pulse,             /* 118: Signal */
  &FingerEAERCtrl_B.oldTrigger_,       /* 119: Signal */
  &FingerEAERCtrl_B.Memory_b,          /* 120: Signal */
  &FingerEAERCtrl_B.Memory1_a,         /* 121: Signal */
  &FingerEAERCtrl_B.Memory2_a,         /* 122: Signal */
  &FingerEAERCtrl_B.sf_gainramp_o.val, /* 123: Signal */
  &FingerEAERCtrl_B.sf_gainramp_o.state1[0],/* 124: Signal */
  &FingerEAERCtrl_B.Memory_g[0],       /* 125: Signal */
  &FingerEAERCtrl_B.sf_gainramp_i.val, /* 126: Signal */
  &FingerEAERCtrl_B.sf_gainramp_i.state1[0],/* 127: Signal */
  &FingerEAERCtrl_B.Memory_i[0],       /* 128: Signal */
  &FingerEAERCtrl_B.sf_gainramp_id.val,/* 129: Signal */
  &FingerEAERCtrl_B.sf_gainramp_id.state1[0],/* 130: Signal */
  &FingerEAERCtrl_B.Memory_e3[0],      /* 131: Signal */
  &FingerEAERCtrl_B.sf_gainramp_b.val, /* 132: Signal */
  &FingerEAERCtrl_B.sf_gainramp_b.state1[0],/* 133: Signal */
  &FingerEAERCtrl_B.Memory_o[0],       /* 134: Signal */
  &FingerEAERCtrl_B.sf_gainramp_f.val, /* 135: Signal */
  &FingerEAERCtrl_B.sf_gainramp_f.state1[0],/* 136: Signal */
  &FingerEAERCtrl_B.Memory_nk[0],      /* 137: Signal */
  &FingerEAERCtrl_B.sf_gainramp_a.val, /* 138: Signal */
  &FingerEAERCtrl_B.sf_gainramp_a.state1[0],/* 139: Signal */
  &FingerEAERCtrl_B.Memory_os[0],      /* 140: Signal */
  &FingerEAERCtrl_B.Diff,              /* 141: Signal */
  &FingerEAERCtrl_B.TSamp,             /* 142: Signal */
  &FingerEAERCtrl_B.Uk1,               /* 143: Signal */
  &FingerEAERCtrl_B.Diff_a,            /* 144: Signal */
  &FingerEAERCtrl_B.TSamp_l,           /* 145: Signal */
  &FingerEAERCtrl_B.Uk1_c,             /* 146: Signal */
  &FingerEAERCtrl_B.Product,           /* 147: Signal */
  &FingerEAERCtrl_B.Product1,          /* 148: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction_g.des[0],/* 149: Signal */
  &FingerEAERCtrl_B.sf_detectforceonset.update,/* 150: Signal */
  &FingerEAERCtrl_B.sf_detectmovementonset.update,/* 151: Signal */
  &FingerEAERCtrl_B.LogicalOperator,   /* 152: Signal */
  &FingerEAERCtrl_B.Memory_e,          /* 153: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction_p.des[0],/* 154: Signal */
  &FingerEAERCtrl_B.sf_detectforceonset_m.update,/* 155: Signal */
  &FingerEAERCtrl_B.sf_detectmovementonset_m.update,/* 156: Signal */
  &FingerEAERCtrl_B.LogicalOperator_a, /* 157: Signal */
  &FingerEAERCtrl_B.Memory_c1,         /* 158: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction_mh.des[0],/* 159: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction_i.des[0],/* 160: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction_c.des[0],/* 161: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction_c.Phold,/* 162: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction_c.state,/* 163: Signal */
  &FingerEAERCtrl_B.Memory_ch,         /* 164: Signal */
  &FingerEAERCtrl_B.Memory1_c,         /* 165: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction_j.des[0],/* 166: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction_j.Phold,/* 167: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction_j.state,/* 168: Signal */
  &FingerEAERCtrl_B.Memory_p,          /* 169: Signal */
  &FingerEAERCtrl_B.Memory1_m,         /* 170: Signal */
  &FingerEAERCtrl_B.Product_b,         /* 171: Signal */
  &FingerEAERCtrl_B.Product1_l,        /* 172: Signal */
  &FingerEAERCtrl_B.sf_detectforceonset1.update,/* 173: Signal */
  &FingerEAERCtrl_B.sf_detectforceonset1.tDes,/* 174: Signal */
  &FingerEAERCtrl_B.sf_trajcalc.des[0],/* 175: Signal */
  &FingerEAERCtrl_B.sf_trajcalc.Phold, /* 176: Signal */
  &FingerEAERCtrl_B.sf_trajcalc.state, /* 177: Signal */
  &FingerEAERCtrl_B.sf_triggercheck.update1,/* 178: Signal */
  &FingerEAERCtrl_B.sf_triggercheck.tDesLast,/* 179: Signal */
  &FingerEAERCtrl_B.Gain_g,            /* 180: Signal */
  &FingerEAERCtrl_B.pholdMem,          /* 181: Signal */
  &FingerEAERCtrl_B.stateMem,          /* 182: Signal */
  &FingerEAERCtrl_B.tDesMem,           /* 183: Signal */
  &FingerEAERCtrl_B.sf_detectforceonset1_f.update,/* 184: Signal */
  &FingerEAERCtrl_B.sf_detectforceonset1_f.tDes,/* 185: Signal */
  &FingerEAERCtrl_B.sf_trajcalc_o.des[0],/* 186: Signal */
  &FingerEAERCtrl_B.sf_trajcalc_o.Phold,/* 187: Signal */
  &FingerEAERCtrl_B.sf_trajcalc_o.state,/* 188: Signal */
  &FingerEAERCtrl_B.sf_triggercheck_c.update1,/* 189: Signal */
  &FingerEAERCtrl_B.sf_triggercheck_c.tDesLast,/* 190: Signal */
  &FingerEAERCtrl_B.Gain_c,            /* 191: Signal */
  &FingerEAERCtrl_B.pholdMem_c,        /* 192: Signal */
  &FingerEAERCtrl_B.stateMem_h,        /* 193: Signal */
  &FingerEAERCtrl_B.tDesMem_l,         /* 194: Signal */
  &FingerEAERCtrl_B.paramsbuffer.pDes, /* 195: Signal */
  &FingerEAERCtrl_B.paramsbuffer.tHit, /* 196: Signal */
  &FingerEAERCtrl_B.paramsbuffer.dur,  /* 197: Signal */
  &FingerEAERCtrl_B.paramsbuffer_b.pDes,/* 198: Signal */
  &FingerEAERCtrl_B.paramsbuffer_b.tHit,/* 199: Signal */
  &FingerEAERCtrl_B.paramsbuffer_b.dur,/* 200: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction1.change,/* 201: Signal */
  &FingerEAERCtrl_B.Memory1_i,         /* 202: Signal */
  &FingerEAERCtrl_B.paramsbuffer_k.fixedDur,/* 203: Signal */
  &FingerEAERCtrl_B.paramsbuffer_k.pDes,/* 204: Signal */
  &FingerEAERCtrl_B.paramsbuffer_k.pos,/* 205: Signal */
  &FingerEAERCtrl_B.paramsbuffer_k.tHit,/* 206: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction1_m.change,/* 207: Signal */
  &FingerEAERCtrl_B.Memory1_o,         /* 208: Signal */
  &FingerEAERCtrl_B.paramsbuffer_i.fixedDur,/* 209: Signal */
  &FingerEAERCtrl_B.paramsbuffer_i.pDes,/* 210: Signal */
  &FingerEAERCtrl_B.paramsbuffer_i.pos,/* 211: Signal */
  &FingerEAERCtrl_B.paramsbuffer_i.tHit,/* 212: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction1_g.change,/* 213: Signal */
  &FingerEAERCtrl_B.Memory1_e,         /* 214: Signal */
  &FingerEAERCtrl_B.paramsbuffer_o.fixedDur,/* 215: Signal */
  &FingerEAERCtrl_B.paramsbuffer_o.pDes,/* 216: Signal */
  &FingerEAERCtrl_B.paramsbuffer_o.tHit,/* 217: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction1_h.change,/* 218: Signal */
  &FingerEAERCtrl_B.Memory1_n,         /* 219: Signal */
  &FingerEAERCtrl_B.paramsbuffer_a.fixedDur,/* 220: Signal */
  &FingerEAERCtrl_B.paramsbuffer_a.pDes,/* 221: Signal */
  &FingerEAERCtrl_B.paramsbuffer_a.tHit,/* 222: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction1_k.change,/* 223: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction1_k.tDesOut,/* 224: Signal */
  &FingerEAERCtrl_B.Memory2,           /* 225: Signal */
  &FingerEAERCtrl_B.forcebuffer.force, /* 226: Signal */
  &FingerEAERCtrl_B.paramsbuffer1.pDes,/* 227: Signal */
  &FingerEAERCtrl_B.paramsbuffer1.tHit,/* 228: Signal */
  &FingerEAERCtrl_B.paramsbuffer1.dur, /* 229: Signal */
  &FingerEAERCtrl_B.saveTrialStartTime.trialStartTime,/* 230: Signal */
  &FingerEAERCtrl_B.timeToTrigger.triggerTime,/* 231: Signal */
  &FingerEAERCtrl_B.timeToTrigger.lastStartT,/* 232: Signal */
  &FingerEAERCtrl_B.timeToTrigger.Memory,/* 233: Signal */
  &FingerEAERCtrl_B.timeToTrigger.Memory1,/* 234: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction1_l.change,/* 235: Signal */
  &FingerEAERCtrl_B.sf_MATLABFunction1_l.tDesOut,/* 236: Signal */
  &FingerEAERCtrl_B.Memory2_d,         /* 237: Signal */
  &FingerEAERCtrl_B.forcebuffer_c.force,/* 238: Signal */
  &FingerEAERCtrl_B.paramsbuffer1_i.pDes,/* 239: Signal */
  &FingerEAERCtrl_B.paramsbuffer1_i.tHit,/* 240: Signal */
  &FingerEAERCtrl_B.paramsbuffer1_i.dur,/* 241: Signal */
  &FingerEAERCtrl_B.saveTrialStartTime_o.trialStartTime,/* 242: Signal */
  &FingerEAERCtrl_B.timeToTrigger_e.triggerTime,/* 243: Signal */
  &FingerEAERCtrl_B.timeToTrigger_e.lastStartT,/* 244: Signal */
  &FingerEAERCtrl_B.timeToTrigger_e.Memory,/* 245: Signal */
  &FingerEAERCtrl_B.timeToTrigger_e.Memory1,/* 246: Signal */
  &FingerEAERCtrl_P.ForceOn_Value,     /* 247: Block Parameter */
  &FingerEAERCtrl_P.Gain_Gain,         /* 248: Block Parameter */
  &FingerEAERCtrl_P.Gain1_Gain,        /* 249: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC_P1,     /* 250: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC_P2,     /* 251: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC_P3,     /* 252: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC_P4,     /* 253: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC_P5,     /* 254: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC_P6,     /* 255: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC_P7,     /* 256: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC_P8,     /* 257: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC_P9,     /* 258: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC_P10,    /* 259: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC1_P1,    /* 260: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC1_P2,    /* 261: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC1_P3,    /* 262: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC1_P4,    /* 263: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC1_P5,    /* 264: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC1_P6,    /* 265: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC1_P7,    /* 266: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC1_P8,    /* 267: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC1_P9,    /* 268: Block Parameter */
  &FingerEAERCtrl_P.PCI6221ENC1_P10,   /* 269: Block Parameter */
  &FingerEAERCtrl_P.PCI6221AD1_P1[0],  /* 270: Block Parameter */
  &FingerEAERCtrl_P.PCI6221AD1_P2[0],  /* 271: Block Parameter */
  &FingerEAERCtrl_P.PCI6221AD1_P3[0],  /* 272: Block Parameter */
  &FingerEAERCtrl_P.PCI6221AD1_P4,     /* 273: Block Parameter */
  &FingerEAERCtrl_P.PCI6221AD1_P5,     /* 274: Block Parameter */
  &FingerEAERCtrl_P.PCI6221AD1_P6,     /* 275: Block Parameter */
  &FingerEAERCtrl_P.PCI6221AD1_P7,     /* 276: Block Parameter */
  &FingerEAERCtrl_P.PCI6221DA_P1[0],   /* 277: Block Parameter */
  &FingerEAERCtrl_P.PCI6221DA_P2[0],   /* 278: Block Parameter */
  &FingerEAERCtrl_P.PCI6221DA_P3[0],   /* 279: Block Parameter */
  &FingerEAERCtrl_P.PCI6221DA_P4[0],   /* 280: Block Parameter */
  &FingerEAERCtrl_P.PCI6221DA_P5,      /* 281: Block Parameter */
  &FingerEAERCtrl_P.PCI6221DA_P6,      /* 282: Block Parameter */
  &FingerEAERCtrl_P.PCI6221DA_P7,      /* 283: Block Parameter */
  &FingerEAERCtrl_P.Saturation_UpperSat_f,/* 284: Block Parameter */
  &FingerEAERCtrl_P.Saturation_LowerSat_o,/* 285: Block Parameter */
  &FingerEAERCtrl_P.paremeters_must_be_one_Value,/* 286: Block Parameter */
  &FingerEAERCtrl_P.parChangeRate_Gain,/* 287: Block Parameter */
  &FingerEAERCtrl_P.parFThresh_Gain,   /* 288: Block Parameter */
  &FingerEAERCtrl_P.parFixedDur_Gain,  /* 289: Block Parameter */
  &FingerEAERCtrl_P.parForceTrigger_Gain,/* 290: Block Parameter */
  &FingerEAERCtrl_P.parKd1_Gain,       /* 291: Block Parameter */
  &FingerEAERCtrl_P.parKd2_Gain,       /* 292: Block Parameter */
  &FingerEAERCtrl_P.parKdV1_Gain,      /* 293: Block Parameter */
  &FingerEAERCtrl_P.parKdV2_Gain,      /* 294: Block Parameter */
  &FingerEAERCtrl_P.parKp1_Gain,       /* 295: Block Parameter */
  &FingerEAERCtrl_P.parKp2_Gain,       /* 296: Block Parameter */
  &FingerEAERCtrl_P.parLeftMode_Gain,  /* 297: Block Parameter */
  &FingerEAERCtrl_P.parMarker_Gain,    /* 298: Block Parameter */
  &FingerEAERCtrl_P.parMaxTrajDur_Gain,/* 299: Block Parameter */
  &FingerEAERCtrl_P.parPStop_Gain,     /* 300: Block Parameter */
  &FingerEAERCtrl_P.parTrajMode_Gain,  /* 301: Block Parameter */
  &FingerEAERCtrl_P.parVThresh_Gain,   /* 302: Block Parameter */
  &FingerEAERCtrl_P.parWiggleAmp_Gain, /* 303: Block Parameter */
  &FingerEAERCtrl_P.Saturation_UpperSat,/* 304: Block Parameter */
  &FingerEAERCtrl_P.Saturation_LowerSat,/* 305: Block Parameter */
  &FingerEAERCtrl_P.Saturation1_UpperSat,/* 306: Block Parameter */
  &FingerEAERCtrl_P.Saturation1_LowerSat,/* 307: Block Parameter */
  &FingerEAERCtrl_P.Saturation2_UpperSat,/* 308: Block Parameter */
  &FingerEAERCtrl_P.Saturation2_LowerSat,/* 309: Block Parameter */
  &FingerEAERCtrl_P.sigForce1_Gain,    /* 310: Block Parameter */
  &FingerEAERCtrl_P.sigForce1Clean_Gain,/* 311: Block Parameter */
  &FingerEAERCtrl_P.sigForce2_Gain,    /* 312: Block Parameter */
  &FingerEAERCtrl_P.sigForce2Clean_Gain,/* 313: Block Parameter */
  &FingerEAERCtrl_P.sigGravAccel_Gain, /* 314: Block Parameter */
  &FingerEAERCtrl_P.sigLoadC_Gain,     /* 315: Block Parameter */
  &FingerEAERCtrl_P.sigLoadCF1a_Gain,  /* 316: Block Parameter */
  &FingerEAERCtrl_P.sigLoadCF1b_Gain,  /* 317: Block Parameter */
  &FingerEAERCtrl_P.sigLoadCF2a_Gain,  /* 318: Block Parameter */
  &FingerEAERCtrl_P.sigLoadCF2b_Gain,  /* 319: Block Parameter */
  &FingerEAERCtrl_P.sigMarker_Gain,    /* 320: Block Parameter */
  &FingerEAERCtrl_P.sigPos1_Gain,      /* 321: Block Parameter */
  &FingerEAERCtrl_P.sigPos1Des_Gain,   /* 322: Block Parameter */
  &FingerEAERCtrl_P.sigPos2_Gain,      /* 323: Block Parameter */
  &FingerEAERCtrl_P.sigPos2Des_Gain,   /* 324: Block Parameter */
  &FingerEAERCtrl_P.sigTargetTime_Gain,/* 325: Block Parameter */
  &FingerEAERCtrl_P.sigTimeToThresh1_Gain,/* 326: Block Parameter */
  &FingerEAERCtrl_P.sigTimeToThresh2_Gain,/* 327: Block Parameter */
  &FingerEAERCtrl_P.sigVel1_Gain,      /* 328: Block Parameter */
  &FingerEAERCtrl_P.sigVel1Des_Gain,   /* 329: Block Parameter */
  &FingerEAERCtrl_P.sigVel2_Gain,      /* 330: Block Parameter */
  &FingerEAERCtrl_P.sigVel2Des_Gain,   /* 331: Block Parameter */
  &FingerEAERCtrl_P.unity_traj_Value,  /* 332: Block Parameter */
  &FingerEAERCtrl_P.parP1Des_Gain,     /* 333: Block Parameter */
  &FingerEAERCtrl_P.parP2Des_Gain,     /* 334: Block Parameter */
  &FingerEAERCtrl_P.parTHit1_Gain,     /* 335: Block Parameter */
  &FingerEAERCtrl_P.parTHit2_Gain,     /* 336: Block Parameter */
  &FingerEAERCtrl_P.A_Gain[0],         /* 337: Block Parameter */
  &FingerEAERCtrl_P.B_Gain[0],         /* 338: Block Parameter */
  &FingerEAERCtrl_P.B1_Gain,           /* 339: Block Parameter */
  &FingerEAERCtrl_P.B2_Gain,           /* 340: Block Parameter */
  &FingerEAERCtrl_P.B3_Gain,           /* 341: Block Parameter */
  &FingerEAERCtrl_P.C_Gain[0],         /* 342: Block Parameter */
  &FingerEAERCtrl_P.K_Gain[0],         /* 343: Block Parameter */
  &FingerEAERCtrl_P.Integrator_IC[0],  /* 344: Block Parameter */
  &FingerEAERCtrl_P.A_Gain_l[0],       /* 345: Block Parameter */
  &FingerEAERCtrl_P.B_Gain_f[0],       /* 346: Block Parameter */
  &FingerEAERCtrl_P.B1_Gain_n,         /* 347: Block Parameter */
  &FingerEAERCtrl_P.B2_Gain_e,         /* 348: Block Parameter */
  &FingerEAERCtrl_P.B3_Gain_g,         /* 349: Block Parameter */
  &FingerEAERCtrl_P.C_Gain_h[0],       /* 350: Block Parameter */
  &FingerEAERCtrl_P.K_Gain_n[0],       /* 351: Block Parameter */
  &FingerEAERCtrl_P.Integrator_IC_f[0],/* 352: Block Parameter */
  &FingerEAERCtrl_P.LowPass100Hz_A[0], /* 353: Block Parameter */
  &FingerEAERCtrl_P.LowPass100Hz_B[0], /* 354: Block Parameter */
  &FingerEAERCtrl_P.LowPass100Hz_C[0], /* 355: Block Parameter */
  &FingerEAERCtrl_P.LowPass100Hz_D,    /* 356: Block Parameter */
  &FingerEAERCtrl_P.LowPass100Hz_X0[0],/* 357: Block Parameter */
  &FingerEAERCtrl_P.LowPass100Hz1_A[0],/* 358: Block Parameter */
  &FingerEAERCtrl_P.LowPass100Hz1_B[0],/* 359: Block Parameter */
  &FingerEAERCtrl_P.LowPass100Hz1_C[0],/* 360: Block Parameter */
  &FingerEAERCtrl_P.LowPass100Hz1_D,   /* 361: Block Parameter */
  &FingerEAERCtrl_P.LowPass100Hz1_X0[0],/* 362: Block Parameter */
  &FingerEAERCtrl_P.Memory_X0_h,       /* 363: Block Parameter */
  &FingerEAERCtrl_P.Memory1_X0_a,      /* 364: Block Parameter */
  &FingerEAERCtrl_P.Memory_X0,         /* 365: Block Parameter */
  &FingerEAERCtrl_P.Memory1_X0[0],     /* 366: Block Parameter */
  &FingerEAERCtrl_P.Constant_Value,    /* 367: Block Parameter */
  &FingerEAERCtrl_P.gain_Gain,         /* 368: Block Parameter */
  &FingerEAERCtrl_P.Memory_X0_e[0],    /* 369: Block Parameter */
  &FingerEAERCtrl_P.Saturation1_UpperSat_i,/* 370: Block Parameter */
  &FingerEAERCtrl_P.Saturation1_LowerSat_k,/* 371: Block Parameter */
  &FingerEAERCtrl_P.Memory_X0_hx,      /* 372: Block Parameter */
  &FingerEAERCtrl_P.Memory1_X0_c,      /* 373: Block Parameter */
  &FingerEAERCtrl_P.Memory2_X0_l,      /* 374: Block Parameter */
  &FingerEAERCtrl_P.Memory_X0_g[0],    /* 375: Block Parameter */
  &FingerEAERCtrl_P.Memory_X0_a[0],    /* 376: Block Parameter */
  &FingerEAERCtrl_P.Memory_X0_b[0],    /* 377: Block Parameter */
  &FingerEAERCtrl_P.Memory_X0_g0[0],   /* 378: Block Parameter */
  &FingerEAERCtrl_P.Memory_X0_bp[0],   /* 379: Block Parameter */
  &FingerEAERCtrl_P.Memory_X0_eq[0],   /* 380: Block Parameter */
  &FingerEAERCtrl_P.TSamp_WtEt,        /* 381: Block Parameter */
  &FingerEAERCtrl_P.UD_InitialCondition,/* 382: Block Parameter */
  &FingerEAERCtrl_P.TSamp_WtEt_p,      /* 383: Block Parameter */
  &FingerEAERCtrl_P.UD_InitialCondition_p,/* 384: Block Parameter */
  &FingerEAERCtrl_P.Constant_Value_c,  /* 385: Block Parameter */
  &FingerEAERCtrl_P.Memory_X0_n,       /* 386: Block Parameter */
  &FingerEAERCtrl_P.Memory_X0_c,       /* 387: Block Parameter */
  &FingerEAERCtrl_P.Memory_X0_d,       /* 388: Block Parameter */
  &FingerEAERCtrl_P.Memory1_X0_m,      /* 389: Block Parameter */
  &FingerEAERCtrl_P.Memory_X0_o,       /* 390: Block Parameter */
  &FingerEAERCtrl_P.Memory1_X0_b,      /* 391: Block Parameter */
  &FingerEAERCtrl_P.Constant_Value_j,  /* 392: Block Parameter */
  &FingerEAERCtrl_P.Gain_Gain_b,       /* 393: Block Parameter */
  &FingerEAERCtrl_P.pholdMem_X0,       /* 394: Block Parameter */
  &FingerEAERCtrl_P.stateMem_X0,       /* 395: Block Parameter */
  &FingerEAERCtrl_P.tDesMem_X0,        /* 396: Block Parameter */
  &FingerEAERCtrl_P.Gain_Gain_p,       /* 397: Block Parameter */
  &FingerEAERCtrl_P.pholdMem_X0_p,     /* 398: Block Parameter */
  &FingerEAERCtrl_P.stateMem_X0_l,     /* 399: Block Parameter */
  &FingerEAERCtrl_P.tDesMem_X0_a,      /* 400: Block Parameter */
  &FingerEAERCtrl_P.Memory1_X0_e,      /* 401: Block Parameter */
  &FingerEAERCtrl_P.Memory1_X0_j,      /* 402: Block Parameter */
  &FingerEAERCtrl_P.Memory1_X0_k,      /* 403: Block Parameter */
  &FingerEAERCtrl_P.Memory1_X0_ja,     /* 404: Block Parameter */
  &FingerEAERCtrl_P.Memory2_X0,        /* 405: Block Parameter */
  &FingerEAERCtrl_P.timeToTrigger.Memory_X0,/* 406: Block Parameter */
  &FingerEAERCtrl_P.timeToTrigger.Memory1_X0,/* 407: Block Parameter */
  &FingerEAERCtrl_P.Memory2_X0_k,      /* 408: Block Parameter */
  &FingerEAERCtrl_P.timeToTrigger_e.Memory_X0,/* 409: Block Parameter */
  &FingerEAERCtrl_P.timeToTrigger_e.Memory1_X0/* 410: Block Parameter */
};

/* Declare Data Run-Time Dimension Buffer Addresses statically */
static int32_T* rtVarDimsAddrMap[] = {
  (NULL)
};

/* Data Type Map - use dataTypeMapIndex to access this structure */
static const rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer */
  { "double", "real_T", 0, 0, sizeof(real_T), SS_DOUBLE, 0, 0 },

  { "unsigned char", "boolean_T", 0, 0, sizeof(boolean_T), SS_BOOLEAN, 0, 0 }
};

/* Structure Element Map - use elemMapIndex to access this structure */
static const rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { NULL, 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static const rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_SCALAR, 0, 2, 0 },

  { rtwCAPI_VECTOR, 2, 2, 0 },

  { rtwCAPI_VECTOR, 4, 2, 0 },

  { rtwCAPI_VECTOR, 6, 2, 0 },

  { rtwCAPI_VECTOR, 8, 2, 0 },

  { rtwCAPI_VECTOR, 10, 2, 0 },

  { rtwCAPI_VECTOR, 12, 2, 0 },

  { rtwCAPI_VECTOR, 14, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 16, 2, 0 },

  { rtwCAPI_VECTOR, 18, 2, 0 },

  { rtwCAPI_VECTOR, 20, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static const uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  1,                                   /* 1 */
  2,                                   /* 2 */
  1,                                   /* 3 */
  6,                                   /* 4 */
  1,                                   /* 5 */
  3,                                   /* 6 */
  1,                                   /* 7 */
  5,                                   /* 8 */
  1,                                   /* 9 */
  4,                                   /* 10 */
  1,                                   /* 11 */
  1,                                   /* 12 */
  8,                                   /* 13 */
  1,                                   /* 14 */
  2,                                   /* 15 */
  3,                                   /* 16 */
  3,                                   /* 17 */
  1,                                   /* 18 */
  3,                                   /* 19 */
  1,                                   /* 20 */
  4                                    /* 21 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.001, 0.0
};

/* Fixed Point Map */
static const rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { NULL, NULL, rtwCAPI_FIX_RESERVED, 0, 0, 0 },
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static const rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[1],
    1, 0 },

  { (const void *) &rtcapiStoredFloats[1], (const void *) &rtcapiStoredFloats[1],
    0, 0 },

  { (NULL), (NULL), -1, 0 }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { rtBlockSignals, 247 },

  { rtBlockParameters, 164,
    rtModelParameters, 0 },

  { NULL, 0 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float", NULL
};

/* Cache pointers into DataMapInfo substructure of RTModel */
void FingerEAERCtrl_InitializeDataMapInfo(rtModel_FingerEAERCtrl
  *FingerEAERCtrl_rtM
  )
{
  /* Set C-API version */
  rtwCAPI_SetVersion(FingerEAERCtrl_rtM->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(FingerEAERCtrl_rtM->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(FingerEAERCtrl_rtM->DataMapInfo.mmi, NULL);

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetDataAddressMap(FingerEAERCtrl_rtM->DataMapInfo.mmi, rtDataAddrMap);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetVarDimsAddressMap(FingerEAERCtrl_rtM->DataMapInfo.mmi,
    rtVarDimsAddrMap);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(FingerEAERCtrl_rtM->DataMapInfo.mmi, NULL);

  /* Set Reference to submodels */
  rtwCAPI_SetChildMMIArray(FingerEAERCtrl_rtM->DataMapInfo.mmi, NULL);
  rtwCAPI_SetChildMMIArrayLen(FingerEAERCtrl_rtM->DataMapInfo.mmi, 0);
}

/* EOF: FingerEAERCtrl_capi.c */
