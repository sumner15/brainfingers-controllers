/*
 * FingerEAERCtrl.h
 *
 * Code generation for model "FingerEAERCtrl".
 *
 * Model version              : 1.750
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Thu Apr 28 15:02:04 2016
 *
 * Target selection: xpctarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_FingerEAERCtrl_h_
#define RTW_HEADER_FingerEAERCtrl_h_
#include "rtw_modelmap.h"
#ifndef FingerEAERCtrl_COMMON_INCLUDES_
# define FingerEAERCtrl_COMMON_INCLUDES_
#include <xpcimports.h>
#include <xpcdatatypes.h>
#include <math.h>
#include <stddef.h>
#include <string.h>
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rt_logging.h"
#include "dt_info.h"
#include "ext_work.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"
#include "rtGetNaN.h"
#include "rt_defines.h"
#include "rt_zcfcn.h"
#endif                                 /* FingerEAERCtrl_COMMON_INCLUDES_ */

#include "FingerEAERCtrl_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetBlkStateChangeFlag
# define rtmGetBlkStateChangeFlag(rtm) ((rtm)->ModelData.blkStateChange)
#endif

#ifndef rtmSetBlkStateChangeFlag
# define rtmSetBlkStateChangeFlag(rtm, val) ((rtm)->ModelData.blkStateChange = (val))
#endif

#ifndef rtmGetBlockIO
# define rtmGetBlockIO(rtm)            ((rtm)->ModelData.blockIO)
#endif

#ifndef rtmSetBlockIO
# define rtmSetBlockIO(rtm, val)       ((rtm)->ModelData.blockIO = (val))
#endif

#ifndef rtmGetChecksums
# define rtmGetChecksums(rtm)          ((rtm)->Sizes.checksums)
#endif

#ifndef rtmSetChecksums
# define rtmSetChecksums(rtm, val)     ((rtm)->Sizes.checksums = (val))
#endif

#ifndef rtmGetConstBlockIO
# define rtmGetConstBlockIO(rtm)       ((rtm)->ModelData.constBlockIO)
#endif

#ifndef rtmSetConstBlockIO
# define rtmSetConstBlockIO(rtm, val)  ((rtm)->ModelData.constBlockIO = (val))
#endif

#ifndef rtmGetContStateDisabled
# define rtmGetContStateDisabled(rtm)  ((rtm)->ModelData.contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
# define rtmSetContStateDisabled(rtm, val) ((rtm)->ModelData.contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
# define rtmGetContStates(rtm)         ((rtm)->ModelData.contStates)
#endif

#ifndef rtmSetContStates
# define rtmSetContStates(rtm, val)    ((rtm)->ModelData.contStates = (val))
#endif

#ifndef rtmGetDataMapInfo
# define rtmGetDataMapInfo(rtm)        ((rtm)->DataMapInfo)
#endif

#ifndef rtmSetDataMapInfo
# define rtmSetDataMapInfo(rtm, val)   ((rtm)->DataMapInfo = (val))
#endif

#ifndef rtmGetDefaultParam
# define rtmGetDefaultParam(rtm)       ((rtm)->ModelData.defaultParam)
#endif

#ifndef rtmSetDefaultParam
# define rtmSetDefaultParam(rtm, val)  ((rtm)->ModelData.defaultParam = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
# define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->ModelData.derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
# define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->ModelData.derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetDirectFeedThrough
# define rtmGetDirectFeedThrough(rtm)  ((rtm)->Sizes.sysDirFeedThru)
#endif

#ifndef rtmSetDirectFeedThrough
# define rtmSetDirectFeedThrough(rtm, val) ((rtm)->Sizes.sysDirFeedThru = (val))
#endif

#ifndef rtmGetErrorStatusFlag
# define rtmGetErrorStatusFlag(rtm)    ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatusFlag
# define rtmSetErrorStatusFlag(rtm, val) ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetFinalTime
# define rtmSetFinalTime(rtm, val)     ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetFirstInitCondFlag
# define rtmGetFirstInitCondFlag(rtm)  ()
#endif

#ifndef rtmSetFirstInitCondFlag
# define rtmSetFirstInitCondFlag(rtm, val) ()
#endif

#ifndef rtmGetIntgData
# define rtmGetIntgData(rtm)           ((rtm)->ModelData.intgData)
#endif

#ifndef rtmSetIntgData
# define rtmSetIntgData(rtm, val)      ((rtm)->ModelData.intgData = (val))
#endif

#ifndef rtmGetMdlRefGlobalTID
# define rtmGetMdlRefGlobalTID(rtm)    ()
#endif

#ifndef rtmSetMdlRefGlobalTID
# define rtmSetMdlRefGlobalTID(rtm, val) ()
#endif

#ifndef rtmGetMdlRefTriggerTID
# define rtmGetMdlRefTriggerTID(rtm)   ()
#endif

#ifndef rtmSetMdlRefTriggerTID
# define rtmSetMdlRefTriggerTID(rtm, val) ()
#endif

#ifndef rtmGetModelMappingInfo
# define rtmGetModelMappingInfo(rtm)   ((rtm)->SpecialInfo.mappingInfo)
#endif

#ifndef rtmSetModelMappingInfo
# define rtmSetModelMappingInfo(rtm, val) ((rtm)->SpecialInfo.mappingInfo = (val))
#endif

#ifndef rtmGetModelName
# define rtmGetModelName(rtm)          ((rtm)->modelName)
#endif

#ifndef rtmSetModelName
# define rtmSetModelName(rtm, val)     ((rtm)->modelName = (val))
#endif

#ifndef rtmGetNonInlinedSFcns
# define rtmGetNonInlinedSFcns(rtm)    ((rtm)->NonInlinedSFcns)
#endif

#ifndef rtmSetNonInlinedSFcns
# define rtmSetNonInlinedSFcns(rtm, val) ((rtm)->NonInlinedSFcns = (val))
#endif

#ifndef rtmGetNumBlockIO
# define rtmGetNumBlockIO(rtm)         ((rtm)->Sizes.numBlockIO)
#endif

#ifndef rtmSetNumBlockIO
# define rtmSetNumBlockIO(rtm, val)    ((rtm)->Sizes.numBlockIO = (val))
#endif

#ifndef rtmGetNumBlockParams
# define rtmGetNumBlockParams(rtm)     ((rtm)->Sizes.numBlockPrms)
#endif

#ifndef rtmSetNumBlockParams
# define rtmSetNumBlockParams(rtm, val) ((rtm)->Sizes.numBlockPrms = (val))
#endif

#ifndef rtmGetNumBlocks
# define rtmGetNumBlocks(rtm)          ((rtm)->Sizes.numBlocks)
#endif

#ifndef rtmSetNumBlocks
# define rtmSetNumBlocks(rtm, val)     ((rtm)->Sizes.numBlocks = (val))
#endif

#ifndef rtmGetNumContStates
# define rtmGetNumContStates(rtm)      ((rtm)->Sizes.numContStates)
#endif

#ifndef rtmSetNumContStates
# define rtmSetNumContStates(rtm, val) ((rtm)->Sizes.numContStates = (val))
#endif

#ifndef rtmGetNumDWork
# define rtmGetNumDWork(rtm)           ((rtm)->Sizes.numDwork)
#endif

#ifndef rtmSetNumDWork
# define rtmSetNumDWork(rtm, val)      ((rtm)->Sizes.numDwork = (val))
#endif

#ifndef rtmGetNumInputPorts
# define rtmGetNumInputPorts(rtm)      ((rtm)->Sizes.numIports)
#endif

#ifndef rtmSetNumInputPorts
# define rtmSetNumInputPorts(rtm, val) ((rtm)->Sizes.numIports = (val))
#endif

#ifndef rtmGetNumNonSampledZCs
# define rtmGetNumNonSampledZCs(rtm)   ((rtm)->Sizes.numNonSampZCs)
#endif

#ifndef rtmSetNumNonSampledZCs
# define rtmSetNumNonSampledZCs(rtm, val) ((rtm)->Sizes.numNonSampZCs = (val))
#endif

#ifndef rtmGetNumOutputPorts
# define rtmGetNumOutputPorts(rtm)     ((rtm)->Sizes.numOports)
#endif

#ifndef rtmSetNumOutputPorts
# define rtmSetNumOutputPorts(rtm, val) ((rtm)->Sizes.numOports = (val))
#endif

#ifndef rtmGetNumSFcnParams
# define rtmGetNumSFcnParams(rtm)      ((rtm)->Sizes.numSFcnPrms)
#endif

#ifndef rtmSetNumSFcnParams
# define rtmSetNumSFcnParams(rtm, val) ((rtm)->Sizes.numSFcnPrms = (val))
#endif

#ifndef rtmGetNumSFunctions
# define rtmGetNumSFunctions(rtm)      ((rtm)->Sizes.numSFcns)
#endif

#ifndef rtmSetNumSFunctions
# define rtmSetNumSFunctions(rtm, val) ((rtm)->Sizes.numSFcns = (val))
#endif

#ifndef rtmGetNumSampleTimes
# define rtmGetNumSampleTimes(rtm)     ((rtm)->Sizes.numSampTimes)
#endif

#ifndef rtmSetNumSampleTimes
# define rtmSetNumSampleTimes(rtm, val) ((rtm)->Sizes.numSampTimes = (val))
#endif

#ifndef rtmGetNumU
# define rtmGetNumU(rtm)               ((rtm)->Sizes.numU)
#endif

#ifndef rtmSetNumU
# define rtmSetNumU(rtm, val)          ((rtm)->Sizes.numU = (val))
#endif

#ifndef rtmGetNumY
# define rtmGetNumY(rtm)               ((rtm)->Sizes.numY)
#endif

#ifndef rtmSetNumY
# define rtmSetNumY(rtm, val)          ((rtm)->Sizes.numY = (val))
#endif

#ifndef rtmGetOdeF
# define rtmGetOdeF(rtm)               ((rtm)->ModelData.odeF)
#endif

#ifndef rtmSetOdeF
# define rtmSetOdeF(rtm, val)          ((rtm)->ModelData.odeF = (val))
#endif

#ifndef rtmGetOdeY
# define rtmGetOdeY(rtm)               ((rtm)->ModelData.odeY)
#endif

#ifndef rtmSetOdeY
# define rtmSetOdeY(rtm, val)          ((rtm)->ModelData.odeY = (val))
#endif

#ifndef rtmGetOffsetTimeArray
# define rtmGetOffsetTimeArray(rtm)    ((rtm)->Timing.offsetTimesArray)
#endif

#ifndef rtmSetOffsetTimeArray
# define rtmSetOffsetTimeArray(rtm, val) ((rtm)->Timing.offsetTimesArray = (val))
#endif

#ifndef rtmGetOffsetTimePtr
# define rtmGetOffsetTimePtr(rtm)      ((rtm)->Timing.offsetTimes)
#endif

#ifndef rtmSetOffsetTimePtr
# define rtmSetOffsetTimePtr(rtm, val) ((rtm)->Timing.offsetTimes = (val))
#endif

#ifndef rtmGetOptions
# define rtmGetOptions(rtm)            ((rtm)->Sizes.options)
#endif

#ifndef rtmSetOptions
# define rtmSetOptions(rtm, val)       ((rtm)->Sizes.options = (val))
#endif

#ifndef rtmGetParamIsMalloced
# define rtmGetParamIsMalloced(rtm)    ()
#endif

#ifndef rtmSetParamIsMalloced
# define rtmSetParamIsMalloced(rtm, val) ()
#endif

#ifndef rtmGetPath
# define rtmGetPath(rtm)               ((rtm)->path)
#endif

#ifndef rtmSetPath
# define rtmSetPath(rtm, val)          ((rtm)->path = (val))
#endif

#ifndef rtmGetPerTaskSampleHits
# define rtmGetPerTaskSampleHits(rtm)  ()
#endif

#ifndef rtmSetPerTaskSampleHits
# define rtmSetPerTaskSampleHits(rtm, val) ()
#endif

#ifndef rtmGetPerTaskSampleHitsArray
# define rtmGetPerTaskSampleHitsArray(rtm) ((rtm)->Timing.perTaskSampleHitsArray)
#endif

#ifndef rtmSetPerTaskSampleHitsArray
# define rtmSetPerTaskSampleHitsArray(rtm, val) ((rtm)->Timing.perTaskSampleHitsArray = (val))
#endif

#ifndef rtmGetPerTaskSampleHitsPtr
# define rtmGetPerTaskSampleHitsPtr(rtm) ((rtm)->Timing.perTaskSampleHits)
#endif

#ifndef rtmSetPerTaskSampleHitsPtr
# define rtmSetPerTaskSampleHitsPtr(rtm, val) ((rtm)->Timing.perTaskSampleHits = (val))
#endif

#ifndef rtmGetPrevZCSigState
# define rtmGetPrevZCSigState(rtm)     ((rtm)->ModelData.prevZCSigState)
#endif

#ifndef rtmSetPrevZCSigState
# define rtmSetPrevZCSigState(rtm, val) ((rtm)->ModelData.prevZCSigState = (val))
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmSetRTWExtModeInfo
# define rtmSetRTWExtModeInfo(rtm, val) ((rtm)->extModeInfo = (val))
#endif

#ifndef rtmGetRTWGeneratedSFcn
# define rtmGetRTWGeneratedSFcn(rtm)   ((rtm)->Sizes.rtwGenSfcn)
#endif

#ifndef rtmSetRTWGeneratedSFcn
# define rtmSetRTWGeneratedSFcn(rtm, val) ((rtm)->Sizes.rtwGenSfcn = (val))
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmSetRTWLogInfo
# define rtmSetRTWLogInfo(rtm, val)    ((rtm)->rtwLogInfo = (val))
#endif

#ifndef rtmGetRTWRTModelMethodsInfo
# define rtmGetRTWRTModelMethodsInfo(rtm) ()
#endif

#ifndef rtmSetRTWRTModelMethodsInfo
# define rtmSetRTWRTModelMethodsInfo(rtm, val) ()
#endif

#ifndef rtmGetRTWSfcnInfo
# define rtmGetRTWSfcnInfo(rtm)        ((rtm)->sfcnInfo)
#endif

#ifndef rtmSetRTWSfcnInfo
# define rtmSetRTWSfcnInfo(rtm, val)   ((rtm)->sfcnInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfo
# define rtmGetRTWSolverInfo(rtm)      ((rtm)->solverInfo)
#endif

#ifndef rtmSetRTWSolverInfo
# define rtmSetRTWSolverInfo(rtm, val) ((rtm)->solverInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfoPtr
# define rtmGetRTWSolverInfoPtr(rtm)   ((rtm)->solverInfoPtr)
#endif

#ifndef rtmSetRTWSolverInfoPtr
# define rtmSetRTWSolverInfoPtr(rtm, val) ((rtm)->solverInfoPtr = (val))
#endif

#ifndef rtmGetReservedForXPC
# define rtmGetReservedForXPC(rtm)     ((rtm)->SpecialInfo.xpcData)
#endif

#ifndef rtmSetReservedForXPC
# define rtmSetReservedForXPC(rtm, val) ((rtm)->SpecialInfo.xpcData = (val))
#endif

#ifndef rtmGetRootDWork
# define rtmGetRootDWork(rtm)          ((rtm)->Work.dwork)
#endif

#ifndef rtmSetRootDWork
# define rtmSetRootDWork(rtm, val)     ((rtm)->Work.dwork = (val))
#endif

#ifndef rtmGetSFunctions
# define rtmGetSFunctions(rtm)         ((rtm)->childSfunctions)
#endif

#ifndef rtmSetSFunctions
# define rtmSetSFunctions(rtm, val)    ((rtm)->childSfunctions = (val))
#endif

#ifndef rtmGetSampleHitArray
# define rtmGetSampleHitArray(rtm)     ((rtm)->Timing.sampleHitArray)
#endif

#ifndef rtmSetSampleHitArray
# define rtmSetSampleHitArray(rtm, val) ((rtm)->Timing.sampleHitArray = (val))
#endif

#ifndef rtmGetSampleHitPtr
# define rtmGetSampleHitPtr(rtm)       ((rtm)->Timing.sampleHits)
#endif

#ifndef rtmSetSampleHitPtr
# define rtmSetSampleHitPtr(rtm, val)  ((rtm)->Timing.sampleHits = (val))
#endif

#ifndef rtmGetSampleTimeArray
# define rtmGetSampleTimeArray(rtm)    ((rtm)->Timing.sampleTimesArray)
#endif

#ifndef rtmSetSampleTimeArray
# define rtmSetSampleTimeArray(rtm, val) ((rtm)->Timing.sampleTimesArray = (val))
#endif

#ifndef rtmGetSampleTimePtr
# define rtmGetSampleTimePtr(rtm)      ((rtm)->Timing.sampleTimes)
#endif

#ifndef rtmSetSampleTimePtr
# define rtmSetSampleTimePtr(rtm, val) ((rtm)->Timing.sampleTimes = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDArray
# define rtmGetSampleTimeTaskIDArray(rtm) ((rtm)->Timing.sampleTimeTaskIDArray)
#endif

#ifndef rtmSetSampleTimeTaskIDArray
# define rtmSetSampleTimeTaskIDArray(rtm, val) ((rtm)->Timing.sampleTimeTaskIDArray = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDPtr
# define rtmGetSampleTimeTaskIDPtr(rtm) ((rtm)->Timing.sampleTimeTaskIDPtr)
#endif

#ifndef rtmSetSampleTimeTaskIDPtr
# define rtmSetSampleTimeTaskIDPtr(rtm, val) ((rtm)->Timing.sampleTimeTaskIDPtr = (val))
#endif

#ifndef rtmGetSimMode
# define rtmGetSimMode(rtm)            ((rtm)->simMode)
#endif

#ifndef rtmSetSimMode
# define rtmSetSimMode(rtm, val)       ((rtm)->simMode = (val))
#endif

#ifndef rtmGetSimTimeStep
# define rtmGetSimTimeStep(rtm)        ((rtm)->Timing.simTimeStep)
#endif

#ifndef rtmSetSimTimeStep
# define rtmSetSimTimeStep(rtm, val)   ((rtm)->Timing.simTimeStep = (val))
#endif

#ifndef rtmGetStartTime
# define rtmGetStartTime(rtm)          ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetStartTime
# define rtmSetStartTime(rtm, val)     ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmGetStepSize
# define rtmGetStepSize(rtm)           ((rtm)->Timing.stepSize)
#endif

#ifndef rtmSetStepSize
# define rtmSetStepSize(rtm, val)      ((rtm)->Timing.stepSize = (val))
#endif

#ifndef rtmGetStopRequestedFlag
# define rtmGetStopRequestedFlag(rtm)  ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequestedFlag
# define rtmSetStopRequestedFlag(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetTaskCounters
# define rtmGetTaskCounters(rtm)       ()
#endif

#ifndef rtmSetTaskCounters
# define rtmSetTaskCounters(rtm, val)  ()
#endif

#ifndef rtmGetTaskTimeArray
# define rtmGetTaskTimeArray(rtm)      ((rtm)->Timing.tArray)
#endif

#ifndef rtmSetTaskTimeArray
# define rtmSetTaskTimeArray(rtm, val) ((rtm)->Timing.tArray = (val))
#endif

#ifndef rtmGetTimePtr
# define rtmGetTimePtr(rtm)            ((rtm)->Timing.t)
#endif

#ifndef rtmSetTimePtr
# define rtmSetTimePtr(rtm, val)       ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTimingData
# define rtmGetTimingData(rtm)         ((rtm)->Timing.timingData)
#endif

#ifndef rtmSetTimingData
# define rtmSetTimingData(rtm, val)    ((rtm)->Timing.timingData = (val))
#endif

#ifndef rtmGetU
# define rtmGetU(rtm)                  ((rtm)->ModelData.inputs)
#endif

#ifndef rtmSetU
# define rtmSetU(rtm, val)             ((rtm)->ModelData.inputs = (val))
#endif

#ifndef rtmGetVarNextHitTimesListPtr
# define rtmGetVarNextHitTimesListPtr(rtm) ((rtm)->Timing.varNextHitTimesList)
#endif

#ifndef rtmSetVarNextHitTimesListPtr
# define rtmSetVarNextHitTimesListPtr(rtm, val) ((rtm)->Timing.varNextHitTimesList = (val))
#endif

#ifndef rtmGetY
# define rtmGetY(rtm)                  ((rtm)->ModelData.outputs)
#endif

#ifndef rtmSetY
# define rtmSetY(rtm, val)             ((rtm)->ModelData.outputs = (val))
#endif

#ifndef rtmGetZCCacheNeedsReset
# define rtmGetZCCacheNeedsReset(rtm)  ((rtm)->ModelData.zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
# define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->ModelData.zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetZCSignalValues
# define rtmGetZCSignalValues(rtm)     ((rtm)->ModelData.zcSignalValues)
#endif

#ifndef rtmSetZCSignalValues
# define rtmSetZCSignalValues(rtm, val) ((rtm)->ModelData.zcSignalValues = (val))
#endif

#ifndef rtmGet_TimeOfLastOutput
# define rtmGet_TimeOfLastOutput(rtm)  ((rtm)->Timing.timeOfLastOutput)
#endif

#ifndef rtmSet_TimeOfLastOutput
# define rtmSet_TimeOfLastOutput(rtm, val) ((rtm)->Timing.timeOfLastOutput = (val))
#endif

#ifndef rtmGetdX
# define rtmGetdX(rtm)                 ((rtm)->ModelData.derivs)
#endif

#ifndef rtmSetdX
# define rtmSetdX(rtm, val)            ((rtm)->ModelData.derivs = (val))
#endif

#ifndef rtmGetChecksumVal
# define rtmGetChecksumVal(rtm, idx)   ((rtm)->Sizes.checksums[idx])
#endif

#ifndef rtmSetChecksumVal
# define rtmSetChecksumVal(rtm, idx, val) ((rtm)->Sizes.checksums[idx] = (val))
#endif

#ifndef rtmGetDWork
# define rtmGetDWork(rtm, idx)         ((rtm)->Work.dwork[idx])
#endif

#ifndef rtmSetDWork
# define rtmSetDWork(rtm, idx, val)    ((rtm)->Work.dwork[idx] = (val))
#endif

#ifndef rtmGetOffsetTime
# define rtmGetOffsetTime(rtm, idx)    ((rtm)->Timing.offsetTimes[idx])
#endif

#ifndef rtmSetOffsetTime
# define rtmSetOffsetTime(rtm, idx, val) ((rtm)->Timing.offsetTimes[idx] = (val))
#endif

#ifndef rtmGetSFunction
# define rtmGetSFunction(rtm, idx)     ((rtm)->childSfunctions[idx])
#endif

#ifndef rtmSetSFunction
# define rtmSetSFunction(rtm, idx, val) ((rtm)->childSfunctions[idx] = (val))
#endif

#ifndef rtmGetSampleTime
# define rtmGetSampleTime(rtm, idx)    ((rtm)->Timing.sampleTimes[idx])
#endif

#ifndef rtmSetSampleTime
# define rtmSetSampleTime(rtm, idx, val) ((rtm)->Timing.sampleTimes[idx] = (val))
#endif

#ifndef rtmGetSampleTimeTaskID
# define rtmGetSampleTimeTaskID(rtm, idx) ((rtm)->Timing.sampleTimeTaskIDPtr[idx])
#endif

#ifndef rtmSetSampleTimeTaskID
# define rtmSetSampleTimeTaskID(rtm, idx, val) ((rtm)->Timing.sampleTimeTaskIDPtr[idx] = (val))
#endif

#ifndef rtmGetVarNextHitTimeList
# define rtmGetVarNextHitTimeList(rtm, idx) ((rtm)->Timing.varNextHitTimesList[idx])
#endif

#ifndef rtmSetVarNextHitTimeList
# define rtmSetVarNextHitTimeList(rtm, idx, val) ((rtm)->Timing.varNextHitTimesList[idx] = (val))
#endif

#ifndef rtmIsContinuousTask
# define rtmIsContinuousTask(rtm, tid) ((tid) == 0)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmIsMajorTimeStep
# define rtmIsMajorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
# define rtmIsMinorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmIsSampleHit
# define rtmIsSampleHit(rtm, sti, tid) ((rtmIsMajorTimeStep((rtm)) && (rtm)->Timing.sampleHits[(rtm)->Timing.sampleTimeTaskIDPtr[sti]]))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmSetT
# define rtmSetT(rtm, val)                                       /* Do Nothing */
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetTFinal
# define rtmSetTFinal(rtm, val)        ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

#ifndef rtmSetTPtr
# define rtmSetTPtr(rtm, val)          ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTStart
# define rtmGetTStart(rtm)             ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetTStart
# define rtmSetTStart(rtm, val)        ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmGetTaskTime
# define rtmGetTaskTime(rtm, sti)      (rtmGetTPtr((rtm))[(rtm)->Timing.sampleTimeTaskIDPtr[sti]])
#endif

#ifndef rtmSetTaskTime
# define rtmSetTaskTime(rtm, sti, val) (rtmGetTPtr((rtm))[sti] = (val))
#endif

#ifndef rtmGetTimeOfLastOutput
# define rtmGetTimeOfLastOutput(rtm)   ((rtm)->Timing.timeOfLastOutput)
#endif

#ifdef rtmGetRTWSolverInfo
#undef rtmGetRTWSolverInfo
#endif

#define rtmGetRTWSolverInfo(rtm)       &((rtm)->solverInfo)

/* Definition for use in the target main file */
#define FingerEAERCtrl_rtModel         rtModel_FingerEAERCtrl

/* user code (top of export header file) */
#include "xpcdatatypes.h"

/* Block signals for system '<S12>/MATLAB Function' */
typedef struct {
  real_T output1;                      /* '<S12>/MATLAB Function' */
  real_T output2;                      /* '<S12>/MATLAB Function' */
} rtB_MATLABFunction_FingerEAERCt;

/* Block states (auto storage) for system '<S12>/MATLAB Function' */
typedef struct {
  int32_T sfEvent;                     /* '<S12>/MATLAB Function' */
  uint8_T is_active_c11_FingerEAERCtrl;/* '<S12>/MATLAB Function' */
  boolean_T isStable;                  /* '<S12>/MATLAB Function' */
  boolean_T doneDoubleBufferReInit;    /* '<S12>/MATLAB Function' */
} rtDW_MATLABFunction_FingerEAERC;

/* Block signals for system '<S26>/gainramp' */
typedef struct {
  real_T val;                          /* '<S26>/gainramp' */
  real_T state1[4];                    /* '<S26>/gainramp' */
} rtB_gainramp_FingerEAERCtrl;

/* Block states (auto storage) for system '<S26>/gainramp' */
typedef struct {
  int32_T sfEvent;                     /* '<S26>/gainramp' */
  uint8_T is_active_c8_FingerEAERCtrl; /* '<S26>/gainramp' */
  boolean_T isStable;                  /* '<S26>/gainramp' */
  boolean_T doneDoubleBufferReInit;    /* '<S26>/gainramp' */
} rtDW_gainramp_FingerEAERCtrl;

/* Block signals for system '<S55>/MATLAB Function' */
typedef struct {
  real_T des[3];                       /* '<S55>/MATLAB Function' */
} rtB_MATLABFunction_FingerEAER_h;

/* Block states (auto storage) for system '<S55>/MATLAB Function' */
typedef struct {
  int32_T sfEvent;                     /* '<S55>/MATLAB Function' */
  uint8_T is_active_c4_FingerEAERCtrl; /* '<S55>/MATLAB Function' */
  boolean_T isStable;                  /* '<S55>/MATLAB Function' */
  boolean_T doneDoubleBufferReInit;    /* '<S55>/MATLAB Function' */
} rtDW_MATLABFunction_FingerEAE_i;

/* Block signals for system '<S55>/detect force onset' */
typedef struct {
  real_T update;                       /* '<S55>/detect force onset' */
} rtB_detectforceonset_FingerEAER;

/* Block states (auto storage) for system '<S55>/detect force onset' */
typedef struct {
  int32_T sfEvent;                     /* '<S55>/detect force onset' */
  uint8_T is_active_c46_FingerEAERCtrl;/* '<S55>/detect force onset' */
  boolean_T isStable;                  /* '<S55>/detect force onset' */
  boolean_T doneDoubleBufferReInit;    /* '<S55>/detect force onset' */
} rtDW_detectforceonset_FingerEAE;

/* Block signals for system '<S55>/detect movement onset' */
typedef struct {
  real_T update;                       /* '<S55>/detect movement onset' */
} rtB_detectmovementonset_FingerE;

/* Block states (auto storage) for system '<S55>/detect movement onset' */
typedef struct {
  int32_T sfEvent;                     /* '<S55>/detect movement onset' */
  uint8_T is_active_c1_FingerEAERCtrl; /* '<S55>/detect movement onset' */
  boolean_T isStable;                  /* '<S55>/detect movement onset' */
  boolean_T doneDoubleBufferReInit;    /* '<S55>/detect movement onset' */
} rtDW_detectmovementonset_Finger;

/* Block signals for system '<S55>/params buffer' */
typedef struct {
  real_T pDes;                         /* '<S60>/buffer the trajectory params' */
  real_T tHit;                         /* '<S60>/buffer the trajectory params' */
  real_T dur;                          /* '<S60>/buffer the trajectory params' */
} rtB_paramsbuffer_FingerEAERCtrl;

/* Block states (auto storage) for system '<S55>/params buffer' */
typedef struct {
  int32_T sfEvent;                     /* '<S60>/buffer the trajectory params' */
  int8_T paramsbuffer_SubsysRanBC;     /* '<S55>/params buffer' */
  uint8_T is_active_c3_FingerEAERCtrl; /* '<S60>/buffer the trajectory params' */
  boolean_T isStable;                  /* '<S60>/buffer the trajectory params' */
  boolean_T doneDoubleBufferReInit;    /* '<S60>/buffer the trajectory params' */
} rtDW_paramsbuffer_FingerEAERCtr;

/* Zero-crossing (trigger) state for system '<S55>/params buffer' */
typedef struct {
  ZCSigState paramsbuffer_Trig_ZCE_n;  /* '<S55>/params buffer' */
} rtZCE_paramsbuffer_FingerEAERCt;

/* Block signals for system '<S67>/MATLAB Function' */
typedef struct {
  real_T des[3];                       /* '<S67>/MATLAB Function' */
} rtB_MATLABFunction_FingerEAER_b;

/* Block states (auto storage) for system '<S67>/MATLAB Function' */
typedef struct {
  int32_T sfEvent;                     /* '<S67>/MATLAB Function' */
  uint8_T is_active_c34_FingerEAERCtrl;/* '<S67>/MATLAB Function' */
  boolean_T isStable;                  /* '<S67>/MATLAB Function' */
  boolean_T doneDoubleBufferReInit;    /* '<S67>/MATLAB Function' */
} rtDW_MATLABFunction_FingerEA_ig;

/* Block signals for system '<S70>/MATLAB Function1' */
typedef struct {
  real_T change;                       /* '<S70>/MATLAB Function1' */
} rtB_MATLABFunction1_FingerEAERC;

/* Block states (auto storage) for system '<S70>/MATLAB Function1' */
typedef struct {
  int32_T sfEvent;                     /* '<S70>/MATLAB Function1' */
  uint8_T is_active_c36_FingerEAERCtrl;/* '<S70>/MATLAB Function1' */
  boolean_T isStable;                  /* '<S70>/MATLAB Function1' */
  boolean_T doneDoubleBufferReInit;    /* '<S70>/MATLAB Function1' */
} rtDW_MATLABFunction1_FingerEAER;

/* Block signals for system '<S67>/params buffer' */
typedef struct {
  real_T fixedDur;                     /* '<S71>/fixedDur' */
  real_T pDes;                         /* '<S71>/buffer the trajectory params' */
  real_T pos;                          /* '<S71>/buffer the trajectory params' */
  real_T tHit;                         /* '<S71>/buffer the trajectory params' */
} rtB_paramsbuffer_FingerEAERCt_c;

/* Block states (auto storage) for system '<S67>/params buffer' */
typedef struct {
  int32_T sfEvent;                     /* '<S71>/buffer the trajectory params' */
  int8_T paramsbuffer_SubsysRanBC;     /* '<S67>/params buffer' */
  uint8_T is_active_c38_FingerEAERCtrl;/* '<S71>/buffer the trajectory params' */
  boolean_T isStable;                  /* '<S71>/buffer the trajectory params' */
  boolean_T doneDoubleBufferReInit;    /* '<S71>/buffer the trajectory params' */
} rtDW_paramsbuffer_FingerEAERC_p;

/* Zero-crossing (trigger) state for system '<S67>/params buffer' */
typedef struct {
  ZCSigState paramsbuffer_Trig_ZCE_p;  /* '<S67>/params buffer' */
} rtZCE_paramsbuffer_FingerEAER_a;

/* Block signals for system '<S79>/MATLAB Function' */
typedef struct {
  real_T des[3];                       /* '<S79>/MATLAB Function' */
  real_T Phold;                        /* '<S79>/MATLAB Function' */
  real_T state;                        /* '<S79>/MATLAB Function' */
} rtB_MATLABFunction_FingerEAER_i;

/* Block states (auto storage) for system '<S79>/MATLAB Function' */
typedef struct {
  int32_T sfEvent;                     /* '<S79>/MATLAB Function' */
  uint8_T is_active_c5_FingerEAERCtrl; /* '<S79>/MATLAB Function' */
  boolean_T isStable;                  /* '<S79>/MATLAB Function' */
  boolean_T doneDoubleBufferReInit;    /* '<S79>/MATLAB Function' */
} rtDW_MATLABFunction_FingerEAE_l;

/* Block signals for system '<S79>/params buffer' */
typedef struct {
  real_T fixedDur;                     /* '<S83>/fixedDur' */
  real_T pDes;                         /* '<S83>/buffer the trajectory params' */
  real_T tHit;                         /* '<S83>/buffer the trajectory params' */
} rtB_paramsbuffer_FingerEAERCt_d;

/* Block states (auto storage) for system '<S79>/params buffer' */
typedef struct {
  int32_T sfEvent;                     /* '<S83>/buffer the trajectory params' */
  int8_T paramsbuffer_SubsysRanBC;     /* '<S79>/params buffer' */
  uint8_T is_active_c7_FingerEAERCtrl; /* '<S83>/buffer the trajectory params' */
  boolean_T isStable;                  /* '<S83>/buffer the trajectory params' */
  boolean_T doneDoubleBufferReInit;    /* '<S83>/buffer the trajectory params' */
} rtDW_paramsbuffer_FingerEAERC_j;

/* Zero-crossing (trigger) state for system '<S79>/params buffer' */
typedef struct {
  ZCSigState paramsbuffer_Trig_ZCE;    /* '<S79>/params buffer' */
} rtZCE_paramsbuffer_FingerEAER_l;

/* Block signals for system '<S92>/detect force onset1' */
typedef struct {
  real_T update;                       /* '<S92>/detect force onset1' */
  real_T tDes;                         /* '<S92>/detect force onset1' */
} rtB_detectforceonset1_FingerEAE;

/* Block states (auto storage) for system '<S92>/detect force onset1' */
typedef struct {
  int32_T sfEvent;                     /* '<S92>/detect force onset1' */
  uint8_T is_active_c32_FingerEAERCtrl;/* '<S92>/detect force onset1' */
  boolean_T isStable;                  /* '<S92>/detect force onset1' */
  boolean_T doneDoubleBufferReInit;    /* '<S92>/detect force onset1' */
} rtDW_detectforceonset1_FingerEA;

/* Block signals for system '<S95>/MATLAB Function1' */
typedef struct {
  real_T change;                       /* '<S95>/MATLAB Function1' */
  real_T tDesOut;                      /* '<S95>/MATLAB Function1' */
} rtB_MATLABFunction1_FingerEAE_l;

/* Block states (auto storage) for system '<S95>/MATLAB Function1' */
typedef struct {
  int32_T sfEvent;                     /* '<S95>/MATLAB Function1' */
  uint8_T is_active_c49_FingerEAERCtrl;/* '<S95>/MATLAB Function1' */
  boolean_T isStable;                  /* '<S95>/MATLAB Function1' */
  boolean_T doneDoubleBufferReInit;    /* '<S95>/MATLAB Function1' */
} rtDW_MATLABFunction1_FingerEA_m;

/* Block signals for system '<S92>/force buffer' */
typedef struct {
  real_T force;                        /* '<S96>/buffer the initial force value' */
} rtB_forcebuffer_FingerEAERCtrl;

/* Block states (auto storage) for system '<S92>/force buffer' */
typedef struct {
  int32_T sfEvent;                     /* '<S96>/buffer the initial force value' */
  int8_T forcebuffer_SubsysRanBC;      /* '<S92>/force buffer' */
  uint8_T is_active_c50_FingerEAERCtrl;/* '<S96>/buffer the initial force value' */
  boolean_T isStable;                  /* '<S96>/buffer the initial force value' */
  boolean_T doneDoubleBufferReInit;    /* '<S96>/buffer the initial force value' */
} rtDW_forcebuffer_FingerEAERCtrl;

/* Zero-crossing (trigger) state for system '<S92>/force buffer' */
typedef struct {
  ZCSigState forcebuffer_Trig_ZCE;     /* '<S92>/force buffer' */
} rtZCE_forcebuffer_FingerEAERCtr;

/* Block signals for system '<S92>/params buffer1' */
typedef struct {
  real_T pDes;                         /* '<S97>/buffer the trajectory params' */
  real_T tHit;                         /* '<S97>/buffer the trajectory params' */
  real_T dur;                          /* '<S97>/buffer the trajectory params' */
} rtB_paramsbuffer1_FingerEAERCtr;

/* Block states (auto storage) for system '<S92>/params buffer1' */
typedef struct {
  int32_T sfEvent;                     /* '<S97>/buffer the trajectory params' */
  int8_T paramsbuffer1_SubsysRanBC;    /* '<S92>/params buffer1' */
  uint8_T is_active_c51_FingerEAERCtrl;/* '<S97>/buffer the trajectory params' */
  boolean_T isStable;                  /* '<S97>/buffer the trajectory params' */
  boolean_T doneDoubleBufferReInit;    /* '<S97>/buffer the trajectory params' */
} rtDW_paramsbuffer1_FingerEAERCt;

/* Zero-crossing (trigger) state for system '<S92>/params buffer1' */
typedef struct {
  ZCSigState paramsbuffer1_Trig_ZCE;   /* '<S92>/params buffer1' */
} rtZCE_paramsbuffer1_FingerEAERC;

/* Block signals for system '<S92>/saveTrialStartTime' */
typedef struct {
  real_T trialStartTime;               /* '<S98>/save the trial start time' */
} rtB_saveTrialStartTime_FingerEA;

/* Block states (auto storage) for system '<S92>/saveTrialStartTime' */
typedef struct {
  int32_T sfEvent;                     /* '<S98>/save the trial start time' */
  int8_T saveTrialStartTime_SubsysRanBC;/* '<S92>/saveTrialStartTime' */
  uint8_T is_active_c52_FingerEAERCtrl;/* '<S98>/save the trial start time' */
  boolean_T isStable;                  /* '<S98>/save the trial start time' */
  boolean_T doneDoubleBufferReInit;    /* '<S98>/save the trial start time' */
} rtDW_saveTrialStartTime_FingerE;

/* Zero-crossing (trigger) state for system '<S92>/saveTrialStartTime' */
typedef struct {
  ZCSigState saveTrialStartTime_Trig_ZCE;/* '<S92>/saveTrialStartTime' */
} rtZCE_saveTrialStartTime_Finger;

/* Block signals for system '<S92>/timeToTrigger' */
typedef struct {
  real_T Memory;                       /* '<S99>/Memory' */
  real_T Memory1;                      /* '<S99>/Memory1' */
  real_T triggerTime;                  /* '<S99>/save the trigger time' */
  real_T lastStartT;                   /* '<S99>/save the trigger time' */
} rtB_timeToTrigger_FingerEAERCtr;

/* Block states (auto storage) for system '<S92>/timeToTrigger' */
typedef struct {
  real_T Memory_PreviousInput;         /* '<S99>/Memory' */
  real_T Memory1_PreviousInput;        /* '<S99>/Memory1' */
  int32_T sfEvent;                     /* '<S99>/save the trigger time' */
  int8_T timeToTrigger_SubsysRanBC;    /* '<S92>/timeToTrigger' */
  uint8_T is_active_c53_FingerEAERCtrl;/* '<S99>/save the trigger time' */
  boolean_T isStable;                  /* '<S99>/save the trigger time' */
  boolean_T doneDoubleBufferReInit;    /* '<S99>/save the trigger time' */
} rtDW_timeToTrigger_FingerEAERCt;

/* Zero-crossing (trigger) state for system '<S92>/timeToTrigger' */
typedef struct {
  ZCSigState timeToTrigger_Trig_ZCE;   /* '<S92>/timeToTrigger' */
} rtZCE_timeToTrigger_FingerEAERC;

/* Block signals for system '<S92>/traj calc' */
typedef struct {
  real_T des[3];                       /* '<S92>/traj calc' */
  real_T Phold;                        /* '<S92>/traj calc' */
  real_T state;                        /* '<S92>/traj calc' */
} rtB_trajcalc_FingerEAERCtrl;

/* Block states (auto storage) for system '<S92>/traj calc' */
typedef struct {
  int32_T sfEvent;                     /* '<S92>/traj calc' */
  uint8_T is_active_c23_FingerEAERCtrl;/* '<S92>/traj calc' */
  boolean_T isStable;                  /* '<S92>/traj calc' */
  boolean_T doneDoubleBufferReInit;    /* '<S92>/traj calc' */
} rtDW_trajcalc_FingerEAERCtrl;

/* Block signals for system '<S92>/trigger check' */
typedef struct {
  real_T update1;                      /* '<S92>/trigger check' */
  real_T tDesLast;                     /* '<S92>/trigger check' */
} rtB_triggercheck_FingerEAERCtrl;

/* Block states (auto storage) for system '<S92>/trigger check' */
typedef struct {
  int32_T sfEvent;                     /* '<S92>/trigger check' */
  uint8_T is_active_c55_FingerEAERCtrl;/* '<S92>/trigger check' */
  boolean_T isStable;                  /* '<S92>/trigger check' */
  boolean_T doneDoubleBufferReInit;    /* '<S92>/trigger check' */
} rtDW_triggercheck_FingerEAERCtr;

/* Block signals (auto storage) */
typedef struct {
  real_T Integrator[3];                /* '<S8>/Integrator' */
  real_T A[3];                         /* '<S8>/A' */
  real_T PCI6221AD1_o1;                /* '<S2>/PCI-6221 AD1' */
  real_T PCI6221AD1_o2;                /* '<S2>/PCI-6221 AD1' */
  real_T PCI6221AD1_o3;                /* '<S2>/PCI-6221 AD1' */
  real_T PCI6221AD1_o4;                /* '<S2>/PCI-6221 AD1' */
  real_T PCI6221AD1_o5;                /* '<S2>/PCI-6221 AD1' */
  real_T PCI6221AD1_o6;                /* '<S2>/PCI-6221 AD1' */
  real_T PCI6221AD1_o7;                /* '<S2>/PCI-6221 AD1' */
  real_T PCI6221AD1_o8;                /* '<S2>/PCI-6221 AD1' */
  real_T parLeftMode;                  /* '<S4>/parLeftMode' */
  real_T Saturation;                   /* '<S4>/Saturation' */
  real_T B[3];                         /* '<S8>/B' */
  real_T PCI6221ENC;                   /* '<S2>/PCI 6221 ENC ' */
  real_T PCI6221ENC1;                  /* '<S2>/PCI 6221 ENC 1' */
  real_T DigitalClock;                 /* '<S17>/Digital Clock' */
  real_T Memory1[2];                   /* '<S17>/Memory1' */
  real_T Memory;                       /* '<S17>/Memory' */
  real_T Gain;                         /* '<S2>/Gain' */
  real_T B1;                           /* '<S8>/B1' */
  real_T B2;                           /* '<S8>/B2' */
  real_T B3;                           /* '<S8>/B3' */
  real_T C;                            /* '<S8>/C' */
  real_T TSamp;                        /* '<S10>/TSamp' */
  real_T Uk1;                          /* '<S10>/UD' */
  real_T Diff;                         /* '<S10>/Diff' */
  real_T Sum2;                         /* '<S8>/Sum2' */
  real_T K[3];                         /* '<S8>/K' */
  real_T Sum3[3];                      /* '<S8>/Sum3' */
  real_T Sum4[3];                      /* '<S8>/Sum4' */
  real_T Integrator_a[3];              /* '<S9>/Integrator' */
  real_T A_o[3];                       /* '<S9>/A' */
  real_T B_d[3];                       /* '<S9>/B' */
  real_T Gain1;                        /* '<S2>/Gain1' */
  real_T B1_o;                         /* '<S9>/B1' */
  real_T B2_o;                         /* '<S9>/B2' */
  real_T B3_l;                         /* '<S9>/B3' */
  real_T C_m;                          /* '<S9>/C' */
  real_T TSamp_l;                      /* '<S11>/TSamp' */
  real_T Uk1_c;                        /* '<S11>/UD' */
  real_T Diff_a;                       /* '<S11>/Diff' */
  real_T Sum2_j;                       /* '<S9>/Sum2' */
  real_T K_d[3];                       /* '<S9>/K' */
  real_T Sum3_j[3];                    /* '<S9>/Sum3' */
  real_T Sum4_l[3];                    /* '<S9>/Sum4' */
  real_T Sum;                          /* '<S18>/Sum' */
  real_T gain;                         /* '<S18>/gain' */
  real_T parChangeRate;                /* '<S4>/parChangeRate' */
  real_T Saturation_m;                 /* '<S3>/Saturation' */
  real_T Memory_c[4];                  /* '<S26>/Memory' */
  real_T parTrajMode;                  /* '<S4>/parTrajMode' */
  real_T RoundingFunction;             /* '<S4>/Rounding Function' */
  real_T Saturation1;                  /* '<S4>/Saturation1' */
  real_T parP1Des;                     /* '<S7>/parP1Des' */
  real_T parTHit1;                     /* '<S7>/parTHit1' */
  real_T DigitalClock_f;               /* '<S5>/Digital Clock' */
  real_T sigTargetTime;                /* '<S5>/sigTargetTime' */
  real_T parVThresh;                   /* '<S4>/parVThresh' */
  real_T Memory_e;                     /* '<S55>/Memory' */
  real_T parMaxTrajDur;                /* '<S4>/parMaxTrajDur' */
  real_T Memory_n;                     /* '<S16>/Memory' */
  real_T Product;                      /* '<S54>/Product' */
  real_T parFThresh;                   /* '<S4>/parFThresh' */
  real_T parP2Des;                     /* '<S7>/parP2Des' */
  real_T parTHit2;                     /* '<S7>/parTHit2' */
  real_T Memory_c1;                    /* '<S56>/Memory' */
  real_T Memory1_j;                    /* '<S16>/Memory1' */
  real_T Product1;                     /* '<S54>/Product1' */
  real_T parFixedDur;                  /* '<S4>/parFixedDur' */
  real_T Saturation2;                  /* '<S4>/Saturation2' */
  real_T Memory1_i;                    /* '<S70>/Memory1' */
  real_T Memory1_o;                    /* '<S75>/Memory1' */
  real_T Memory1_e;                    /* '<S82>/Memory1' */
  real_T Memory_ch;                    /* '<S79>/Memory' */
  real_T Memory1_c;                    /* '<S79>/Memory1' */
  real_T Memory1_n;                    /* '<S87>/Memory1' */
  real_T Memory_p;                     /* '<S80>/Memory' */
  real_T Memory1_m;                    /* '<S80>/Memory1' */
  real_T Product_b;                    /* '<S91>/Product' */
  real_T Gain_g;                       /* '<S92>/Gain' */
  real_T Memory2;                      /* '<S95>/Memory2' */
  real_T tDesMem;                      /* '<S92>/tDesMem' */
  real_T pholdMem;                     /* '<S92>/pholdMem' */
  real_T stateMem;                     /* '<S92>/stateMem' */
  real_T Product1_l;                   /* '<S91>/Product1' */
  real_T Gain_c;                       /* '<S93>/Gain' */
  real_T Memory2_d;                    /* '<S108>/Memory2' */
  real_T tDesMem_l;                    /* '<S93>/tDesMem' */
  real_T pholdMem_c;                   /* '<S93>/pholdMem' */
  real_T stateMem_h;                   /* '<S93>/stateMem' */
  real_T MultiportSwitch[6];           /* '<S6>/Multiport Switch' */
  real_T parKp1;                       /* '<S4>/parKp1' */
  real_T Memory_g[4];                  /* '<S35>/Memory' */
  real_T parKp2;                       /* '<S4>/parKp2' */
  real_T Memory_i[4];                  /* '<S36>/Memory' */
  real_T parKd1;                       /* '<S4>/parKd1' */
  real_T Memory_e3[4];                 /* '<S37>/Memory' */
  real_T parKd2;                       /* '<S4>/parKd2' */
  real_T Memory_o[4];                  /* '<S38>/Memory' */
  real_T Product_m[2];                 /* '<S3>/Product' */
  real_T Saturation1_i;                /* '<S27>/Saturation1' */
  real_T parPStop;                     /* '<S4>/parPStop' */
  real_T parKdV1;                      /* '<S4>/parKdV1' */
  real_T Memory_nk[4];                 /* '<S39>/Memory' */
  real_T parKdV2;                      /* '<S4>/parKdV2' */
  real_T Memory_os[4];                 /* '<S40>/Memory' */
  real_T parForceTrigger;              /* '<S4>/parForceTrigger' */
  real_T Memory_b;                     /* '<S28>/Memory' */
  real_T parWiggleAmp;                 /* '<S4>/parWiggleAmp' */
  real_T Memory2_a;                    /* '<S28>/Memory2' */
  real_T Memory1_a;                    /* '<S28>/Memory1' */
  real_T Add[2];                       /* '<S3>/Add' */
  real_T LowPass100Hz;                 /* '<S16>/Low Pass 100 Hz' */
  real_T LowPass100Hz1;                /* '<S16>/Low Pass 100 Hz1' */
  real_T parMarker;                    /* '<S4>/parMarker' */
  real_T sigPos1;                      /* '<S5>/sigPos1' */
  real_T sigPos2;                      /* '<S5>/sigPos2' */
  real_T sigVel1;                      /* '<S5>/sigVel1' */
  real_T sigVel2;                      /* '<S5>/sigVel2' */
  real_T sigPos1Des;                   /* '<S5>/sigPos1Des' */
  real_T sigPos2Des;                   /* '<S5>/sigPos2Des' */
  real_T sigVel1Des;                   /* '<S5>/sigVel1Des' */
  real_T sigVel2Des;                   /* '<S5>/sigVel2Des' */
  real_T sigForce1;                    /* '<S5>/sigForce1' */
  real_T sigForce2;                    /* '<S5>/sigForce2' */
  real_T sigLoadC;                     /* '<S5>/sigLoadC' */
  real_T sigLoadCF1a;                  /* '<S5>/sigLoadCF1a' */
  real_T sigLoadCF1b;                  /* '<S5>/sigLoadCF1b' */
  real_T sigLoadCF2a;                  /* '<S5>/sigLoadCF2a' */
  real_T sigLoadCF2b;                  /* '<S5>/sigLoadCF2b' */
  real_T sigForce1Clean;               /* '<S5>/sigForce1Clean' */
  real_T sigForce2Clean;               /* '<S5>/sigForce2Clean' */
  real_T sigGravAccel;                 /* '<S5>/sigGravAccel' */
  real_T sigTimeToThresh1;             /* '<S5>/sigTimeToThresh1' */
  real_T sigTimeToThresh2;             /* '<S5>/sigTimeToThresh2' */
  real_T sigMarker;                    /* '<S5>/sigMarker' */
  real_T TmpSignalConversionAtSFunctionI[4];/* '<S3>/viccosityAdder' */
  real_T TmpSignalConversionAtSFunctio_j[2];/* '<S3>/viccosityAdder' */
  real_T Forces[2];                    /* '<S3>/viccosityAdder' */
  real_T pulse;                        /* '<S28>/MATLAB Function1' */
  real_T oldTrigger_;                  /* '<S28>/MATLAB Function1' */
  real_T f1;                           /* '<S28>/MATLAB Function' */
  real_T f2;                           /* '<S28>/MATLAB Function' */
  real_T tStart_;                      /* '<S28>/MATLAB Function' */
  real_T fNum_;                        /* '<S28>/MATLAB Function' */
  real_T y;                            /* '<S27>/ramp' */
  real_T Force[2];                     /* '<S27>/MATLAB Function' */
  real_T TmpSignalConversionAtSFunctio_h[4];/* '<S3>/controller' */
  real_T TmpSignalConversionAtSFunctio_b[2];/* '<S3>/controller' */
  real_T TmpSignalConversionAtSFunctio_m[2];/* '<S3>/controller' */
  real_T Forces_a[2];                  /* '<S3>/controller' */
  real_T encoder1;                     /* '<S17>/MATLAB Function' */
  real_T encoder2;                     /* '<S17>/MATLAB Function' */
  real_T summedVals[2];                /* '<S17>/MATLAB Function' */
  real_T nSamples;                     /* '<S17>/MATLAB Function' */
  real_T TmpSignalConversionAtSFunctio_g[5];/* '<S13>/MATLAB Function' */
  real_T output[5];                    /* '<S13>/MATLAB Function' */
  boolean_T LogicalOperator;           /* '<S55>/Logical Operator' */
  boolean_T LogicalOperator_a;         /* '<S56>/Logical Operator' */
  rtB_triggercheck_FingerEAERCtrl sf_triggercheck_c;/* '<S93>/trigger check' */
  rtB_trajcalc_FingerEAERCtrl sf_trajcalc_o;/* '<S93>/traj calc' */
  rtB_timeToTrigger_FingerEAERCtr timeToTrigger_e;/* '<S93>/timeToTrigger' */
  rtB_saveTrialStartTime_FingerEA saveTrialStartTime_o;/* '<S93>/saveTrialStartTime' */
  rtB_paramsbuffer1_FingerEAERCtr paramsbuffer1_i;/* '<S93>/params buffer1' */
  rtB_forcebuffer_FingerEAERCtrl forcebuffer_c;/* '<S93>/force buffer' */
  rtB_MATLABFunction1_FingerEAE_l sf_MATLABFunction1_l;/* '<S108>/MATLAB Function1' */
  rtB_detectforceonset1_FingerEAE sf_detectforceonset1_f;/* '<S93>/detect force onset1' */
  rtB_triggercheck_FingerEAERCtrl sf_triggercheck;/* '<S92>/trigger check' */
  rtB_trajcalc_FingerEAERCtrl sf_trajcalc;/* '<S92>/traj calc' */
  rtB_timeToTrigger_FingerEAERCtr timeToTrigger;/* '<S92>/timeToTrigger' */
  rtB_saveTrialStartTime_FingerEA saveTrialStartTime;/* '<S92>/saveTrialStartTime' */
  rtB_paramsbuffer1_FingerEAERCtr paramsbuffer1;/* '<S92>/params buffer1' */
  rtB_forcebuffer_FingerEAERCtrl forcebuffer;/* '<S92>/force buffer' */
  rtB_MATLABFunction1_FingerEAE_l sf_MATLABFunction1_k;/* '<S95>/MATLAB Function1' */
  rtB_detectforceonset1_FingerEAE sf_detectforceonset1;/* '<S92>/detect force onset1' */
  rtB_paramsbuffer_FingerEAERCt_d paramsbuffer_a;/* '<S80>/params buffer' */
  rtB_MATLABFunction1_FingerEAERC sf_MATLABFunction1_h;/* '<S87>/MATLAB Function1' */
  rtB_MATLABFunction_FingerEAER_i sf_MATLABFunction_j;/* '<S80>/MATLAB Function' */
  rtB_paramsbuffer_FingerEAERCt_d paramsbuffer_o;/* '<S79>/params buffer' */
  rtB_MATLABFunction1_FingerEAERC sf_MATLABFunction1_g;/* '<S82>/MATLAB Function1' */
  rtB_MATLABFunction_FingerEAER_i sf_MATLABFunction_c;/* '<S79>/MATLAB Function' */
  rtB_paramsbuffer_FingerEAERCt_c paramsbuffer_i;/* '<S68>/params buffer' */
  rtB_MATLABFunction1_FingerEAERC sf_MATLABFunction1_m;/* '<S75>/MATLAB Function1' */
  rtB_MATLABFunction_FingerEAER_b sf_MATLABFunction_i;/* '<S68>/MATLAB Function' */
  rtB_paramsbuffer_FingerEAERCt_c paramsbuffer_k;/* '<S67>/params buffer' */
  rtB_MATLABFunction1_FingerEAERC sf_MATLABFunction1;/* '<S70>/MATLAB Function1' */
  rtB_MATLABFunction_FingerEAER_b sf_MATLABFunction_mh;/* '<S67>/MATLAB Function' */
  rtB_paramsbuffer_FingerEAERCtrl paramsbuffer_b;/* '<S56>/params buffer' */
  rtB_detectmovementonset_FingerE sf_detectmovementonset_m;/* '<S56>/detect movement onset' */
  rtB_detectforceonset_FingerEAER sf_detectforceonset_m;/* '<S56>/detect force onset' */
  rtB_MATLABFunction_FingerEAER_h sf_MATLABFunction_p;/* '<S56>/MATLAB Function' */
  rtB_paramsbuffer_FingerEAERCtrl paramsbuffer;/* '<S55>/params buffer' */
  rtB_detectmovementonset_FingerE sf_detectmovementonset;/* '<S55>/detect movement onset' */
  rtB_detectforceonset_FingerEAER sf_detectforceonset;/* '<S55>/detect force onset' */
  rtB_MATLABFunction_FingerEAER_h sf_MATLABFunction_g;/* '<S55>/MATLAB Function' */
  rtB_gainramp_FingerEAERCtrl sf_gainramp_a;/* '<S40>/gainramp' */
  rtB_gainramp_FingerEAERCtrl sf_gainramp_f;/* '<S39>/gainramp' */
  rtB_gainramp_FingerEAERCtrl sf_gainramp_b;/* '<S38>/gainramp' */
  rtB_gainramp_FingerEAERCtrl sf_gainramp_id;/* '<S37>/gainramp' */
  rtB_gainramp_FingerEAERCtrl sf_gainramp_i;/* '<S36>/gainramp' */
  rtB_gainramp_FingerEAERCtrl sf_gainramp_o;/* '<S35>/gainramp' */
  rtB_gainramp_FingerEAERCtrl sf_gainramp;/* '<S26>/gainramp' */
  rtB_MATLABFunction_FingerEAERCt sf_MATLABFunction;/* '<S15>/MATLAB Function' */
  rtB_MATLABFunction_FingerEAERCt sf_MATLABFunction_e;/* '<S14>/MATLAB Function' */
  rtB_MATLABFunction_FingerEAERCt sf_MATLABFunction_my;/* '<S12>/MATLAB Function' */
} BlockIO_FingerEAERCtrl;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T UD_DSTATE;                    /* '<S10>/UD' */
  real_T UD_DSTATE_h;                  /* '<S11>/UD' */
  real_T LowPass100Hz_DSTATE[2];       /* '<S16>/Low Pass 100 Hz' */
  real_T LowPass100Hz1_DSTATE[2];      /* '<S16>/Low Pass 100 Hz1' */
  real_T Memory1_PreviousInput[2];     /* '<S17>/Memory1' */
  real_T Memory_PreviousInput;         /* '<S17>/Memory' */
  real_T Memory_PreviousInput_i[4];    /* '<S26>/Memory' */
  real_T Memory_PreviousInput_k;       /* '<S55>/Memory' */
  real_T Memory_PreviousInput_l;       /* '<S16>/Memory' */
  real_T Memory_PreviousInput_k0;      /* '<S56>/Memory' */
  real_T Memory1_PreviousInput_d;      /* '<S16>/Memory1' */
  real_T Memory1_PreviousInput_h;      /* '<S70>/Memory1' */
  real_T Memory1_PreviousInput_e;      /* '<S75>/Memory1' */
  real_T Memory1_PreviousInput_l;      /* '<S82>/Memory1' */
  real_T Memory_PreviousInput_h;       /* '<S79>/Memory' */
  real_T Memory1_PreviousInput_ld;     /* '<S79>/Memory1' */
  real_T Memory1_PreviousInput_f;      /* '<S87>/Memory1' */
  real_T Memory_PreviousInput_la;      /* '<S80>/Memory' */
  real_T Memory1_PreviousInput_hw;     /* '<S80>/Memory1' */
  real_T Memory2_PreviousInput;        /* '<S95>/Memory2' */
  real_T tDesMem_PreviousInput;        /* '<S92>/tDesMem' */
  real_T pholdMem_PreviousInput;       /* '<S92>/pholdMem' */
  real_T stateMem_PreviousInput;       /* '<S92>/stateMem' */
  real_T Memory2_PreviousInput_o;      /* '<S108>/Memory2' */
  real_T tDesMem_PreviousInput_n;      /* '<S93>/tDesMem' */
  real_T pholdMem_PreviousInput_k;     /* '<S93>/pholdMem' */
  real_T stateMem_PreviousInput_g;     /* '<S93>/stateMem' */
  real_T Memory_PreviousInput_k1[4];   /* '<S35>/Memory' */
  real_T Memory_PreviousInput_n[4];    /* '<S36>/Memory' */
  real_T Memory_PreviousInput_b[4];    /* '<S37>/Memory' */
  real_T Memory_PreviousInput_j[4];    /* '<S38>/Memory' */
  real_T Memory_PreviousInput_ix[4];   /* '<S39>/Memory' */
  real_T Memory_PreviousInput_c[4];    /* '<S40>/Memory' */
  real_T Memory_PreviousInput_i3;      /* '<S28>/Memory' */
  real_T Memory2_PreviousInput_f;      /* '<S28>/Memory2' */
  real_T Memory1_PreviousInput_k;      /* '<S28>/Memory1' */
  real_T PCI6221DA_RWORK[6];           /* '<S2>/PCI-6221 DA' */
  void *PCI6221AD1_PWORK;              /* '<S2>/PCI-6221 AD1' */
  void *PCI6221ENC_PWORK;              /* '<S2>/PCI 6221 ENC ' */
  void *PCI6221ENC1_PWORK;             /* '<S2>/PCI 6221 ENC 1' */
  int32_T sfEvent;                     /* '<S3>/viccosityAdder' */
  int32_T sfEvent_c;                   /* '<S28>/MATLAB Function1' */
  int32_T sfEvent_b;                   /* '<S28>/MATLAB Function' */
  int32_T sfEvent_d;                   /* '<S27>/ramp' */
  int32_T sfEvent_cn;                  /* '<S27>/MATLAB Function' */
  int32_T sfEvent_g;                   /* '<S3>/controller' */
  int32_T sfEvent_p;                   /* '<S17>/MATLAB Function' */
  int32_T sfEvent_a;                   /* '<S13>/MATLAB Function' */
  int_T PCI6221AD1_IWORK[41];          /* '<S2>/PCI-6221 AD1' */
  struct {
    int_T AcquireOK;
  } SFunction_IWORK;                   /* '<S24>/S-Function' */

  int_T PCI6221DA_IWORK[41];           /* '<S2>/PCI-6221 DA' */
  struct {
    int_T AcquireOK;
  } SFunction_IWORK_l;                 /* '<S48>/S-Function' */

  struct {
    int_T AcquireOK;
  } SFunction_IWORK_a;                 /* '<S49>/S-Function' */

  struct {
    int_T AcquireOK;
  } SFunction_IWORK_g;                 /* '<S47>/S-Function' */

  uint8_T is_active_c42_FingerEAERCtrl;/* '<S3>/viccosityAdder' */
  uint8_T is_active_c31_FingerEAERCtrl;/* '<S28>/MATLAB Function1' */
  uint8_T is_active_c30_FingerEAERCtrl;/* '<S28>/MATLAB Function' */
  uint8_T is_active_c45_FingerEAERCtrl;/* '<S27>/ramp' */
  uint8_T is_active_c10_FingerEAERCtrl;/* '<S27>/MATLAB Function' */
  uint8_T is_active_c2_FingerEAERCtrl; /* '<S3>/controller' */
  uint8_T is_active_c9_FingerEAERCtrl; /* '<S17>/MATLAB Function' */
  uint8_T is_active_c26_FingerEAERCtrl;/* '<S13>/MATLAB Function' */
  boolean_T isStable;                  /* '<S3>/viccosityAdder' */
  boolean_T doneDoubleBufferReInit;    /* '<S3>/viccosityAdder' */
  boolean_T isStable_i;                /* '<S28>/MATLAB Function1' */
  boolean_T doneDoubleBufferReInit_o;  /* '<S28>/MATLAB Function1' */
  boolean_T isStable_p;                /* '<S28>/MATLAB Function' */
  boolean_T doneDoubleBufferReInit_l;  /* '<S28>/MATLAB Function' */
  boolean_T isStable_l;                /* '<S27>/ramp' */
  boolean_T doneDoubleBufferReInit_c;  /* '<S27>/ramp' */
  boolean_T isStable_m;                /* '<S27>/MATLAB Function' */
  boolean_T doneDoubleBufferReInit_p;  /* '<S27>/MATLAB Function' */
  boolean_T isStable_h;                /* '<S3>/controller' */
  boolean_T doneDoubleBufferReInit_d;  /* '<S3>/controller' */
  boolean_T isStable_a;                /* '<S17>/MATLAB Function' */
  boolean_T doneDoubleBufferReInit_lt; /* '<S17>/MATLAB Function' */
  boolean_T isStable_g;                /* '<S13>/MATLAB Function' */
  boolean_T doneDoubleBufferReInit_b;  /* '<S13>/MATLAB Function' */
  rtDW_triggercheck_FingerEAERCtr sf_triggercheck_c;/* '<S93>/trigger check' */
  rtDW_trajcalc_FingerEAERCtrl sf_trajcalc_o;/* '<S93>/traj calc' */
  rtDW_timeToTrigger_FingerEAERCt timeToTrigger_e;/* '<S93>/timeToTrigger' */
  rtDW_saveTrialStartTime_FingerE saveTrialStartTime_o;/* '<S93>/saveTrialStartTime' */
  rtDW_paramsbuffer1_FingerEAERCt paramsbuffer1_i;/* '<S93>/params buffer1' */
  rtDW_forcebuffer_FingerEAERCtrl forcebuffer_c;/* '<S93>/force buffer' */
  rtDW_MATLABFunction1_FingerEA_m sf_MATLABFunction1_l;/* '<S108>/MATLAB Function1' */
  rtDW_detectforceonset1_FingerEA sf_detectforceonset1_f;/* '<S93>/detect force onset1' */
  rtDW_triggercheck_FingerEAERCtr sf_triggercheck;/* '<S92>/trigger check' */
  rtDW_trajcalc_FingerEAERCtrl sf_trajcalc;/* '<S92>/traj calc' */
  rtDW_timeToTrigger_FingerEAERCt timeToTrigger;/* '<S92>/timeToTrigger' */
  rtDW_saveTrialStartTime_FingerE saveTrialStartTime;/* '<S92>/saveTrialStartTime' */
  rtDW_paramsbuffer1_FingerEAERCt paramsbuffer1;/* '<S92>/params buffer1' */
  rtDW_forcebuffer_FingerEAERCtrl forcebuffer;/* '<S92>/force buffer' */
  rtDW_MATLABFunction1_FingerEA_m sf_MATLABFunction1_k;/* '<S95>/MATLAB Function1' */
  rtDW_detectforceonset1_FingerEA sf_detectforceonset1;/* '<S92>/detect force onset1' */
  rtDW_paramsbuffer_FingerEAERC_j paramsbuffer_a;/* '<S80>/params buffer' */
  rtDW_MATLABFunction1_FingerEAER sf_MATLABFunction1_h;/* '<S87>/MATLAB Function1' */
  rtDW_MATLABFunction_FingerEAE_l sf_MATLABFunction_j;/* '<S80>/MATLAB Function' */
  rtDW_paramsbuffer_FingerEAERC_j paramsbuffer_o;/* '<S79>/params buffer' */
  rtDW_MATLABFunction1_FingerEAER sf_MATLABFunction1_g;/* '<S82>/MATLAB Function1' */
  rtDW_MATLABFunction_FingerEAE_l sf_MATLABFunction_c;/* '<S79>/MATLAB Function' */
  rtDW_paramsbuffer_FingerEAERC_p paramsbuffer_i;/* '<S68>/params buffer' */
  rtDW_MATLABFunction1_FingerEAER sf_MATLABFunction1_m;/* '<S75>/MATLAB Function1' */
  rtDW_MATLABFunction_FingerEA_ig sf_MATLABFunction_i;/* '<S68>/MATLAB Function' */
  rtDW_paramsbuffer_FingerEAERC_p paramsbuffer_k;/* '<S67>/params buffer' */
  rtDW_MATLABFunction1_FingerEAER sf_MATLABFunction1;/* '<S70>/MATLAB Function1' */
  rtDW_MATLABFunction_FingerEA_ig sf_MATLABFunction_mh;/* '<S67>/MATLAB Function' */
  rtDW_paramsbuffer_FingerEAERCtr paramsbuffer_b;/* '<S56>/params buffer' */
  rtDW_detectmovementonset_Finger sf_detectmovementonset_m;/* '<S56>/detect movement onset' */
  rtDW_detectforceonset_FingerEAE sf_detectforceonset_m;/* '<S56>/detect force onset' */
  rtDW_MATLABFunction_FingerEAE_i sf_MATLABFunction_p;/* '<S56>/MATLAB Function' */
  rtDW_paramsbuffer_FingerEAERCtr paramsbuffer;/* '<S55>/params buffer' */
  rtDW_detectmovementonset_Finger sf_detectmovementonset;/* '<S55>/detect movement onset' */
  rtDW_detectforceonset_FingerEAE sf_detectforceonset;/* '<S55>/detect force onset' */
  rtDW_MATLABFunction_FingerEAE_i sf_MATLABFunction_g;/* '<S55>/MATLAB Function' */
  rtDW_gainramp_FingerEAERCtrl sf_gainramp_a;/* '<S40>/gainramp' */
  rtDW_gainramp_FingerEAERCtrl sf_gainramp_f;/* '<S39>/gainramp' */
  rtDW_gainramp_FingerEAERCtrl sf_gainramp_b;/* '<S38>/gainramp' */
  rtDW_gainramp_FingerEAERCtrl sf_gainramp_id;/* '<S37>/gainramp' */
  rtDW_gainramp_FingerEAERCtrl sf_gainramp_i;/* '<S36>/gainramp' */
  rtDW_gainramp_FingerEAERCtrl sf_gainramp_o;/* '<S35>/gainramp' */
  rtDW_gainramp_FingerEAERCtrl sf_gainramp;/* '<S26>/gainramp' */
  rtDW_MATLABFunction_FingerEAERC sf_MATLABFunction;/* '<S15>/MATLAB Function' */
  rtDW_MATLABFunction_FingerEAERC sf_MATLABFunction_e;/* '<S14>/MATLAB Function' */
  rtDW_MATLABFunction_FingerEAERC sf_MATLABFunction_my;/* '<S12>/MATLAB Function' */
} D_Work_FingerEAERCtrl;

/* Continuous states (auto storage) */
typedef struct {
  real_T Integrator_CSTATE[3];         /* '<S8>/Integrator' */
  real_T Integrator_CSTATE_h[3];       /* '<S9>/Integrator' */
} ContinuousStates_FingerEAERCtrl;

/* State derivatives (auto storage) */
typedef struct {
  real_T Integrator_CSTATE[3];         /* '<S8>/Integrator' */
  real_T Integrator_CSTATE_h[3];       /* '<S9>/Integrator' */
} StateDerivatives_FingerEAERCtrl;

/* State disabled  */
typedef struct {
  boolean_T Integrator_CSTATE[3];      /* '<S8>/Integrator' */
  boolean_T Integrator_CSTATE_h[3];    /* '<S9>/Integrator' */
} StateDisabled_FingerEAERCtrl;

/* Zero-crossing (trigger) state */
typedef struct {
  rtZCE_timeToTrigger_FingerEAERC timeToTrigger_e;/* '<S92>/timeToTrigger' */
  rtZCE_saveTrialStartTime_Finger saveTrialStartTime_o;/* '<S92>/saveTrialStartTime' */
  rtZCE_paramsbuffer1_FingerEAERC paramsbuffer1_i;/* '<S92>/params buffer1' */
  rtZCE_forcebuffer_FingerEAERCtr forcebuffer_c;/* '<S92>/force buffer' */
  rtZCE_timeToTrigger_FingerEAERC timeToTrigger;/* '<S92>/timeToTrigger' */
  rtZCE_saveTrialStartTime_Finger saveTrialStartTime;/* '<S92>/saveTrialStartTime' */
  rtZCE_paramsbuffer1_FingerEAERC paramsbuffer1;/* '<S92>/params buffer1' */
  rtZCE_forcebuffer_FingerEAERCtr forcebuffer;/* '<S92>/force buffer' */
  rtZCE_paramsbuffer_FingerEAER_l paramsbuffer_a;/* '<S79>/params buffer' */
  rtZCE_paramsbuffer_FingerEAER_l paramsbuffer_o;/* '<S79>/params buffer' */
  rtZCE_paramsbuffer_FingerEAER_a paramsbuffer_i;/* '<S67>/params buffer' */
  rtZCE_paramsbuffer_FingerEAER_a paramsbuffer_k;/* '<S67>/params buffer' */
  rtZCE_paramsbuffer_FingerEAERCt paramsbuffer_b;/* '<S55>/params buffer' */
  rtZCE_paramsbuffer_FingerEAERCt paramsbuffer;/* '<S55>/params buffer' */
} PrevZCSigStates_FingerEAERCtrl;

#ifndef ODE3_INTG
#define ODE3_INTG

/* ODE3 Integration Data */
typedef struct {
  real_T *y;                           /* output */
  real_T *f[3];                        /* derivatives */
} ODE3_IntgData;

#endif

/* Backward compatible GRT Identifiers */
#define rtB                            FingerEAERCtrl_B
#define BlockIO                        BlockIO_FingerEAERCtrl
#define rtX                            FingerEAERCtrl_X
#define ContinuousStates               ContinuousStates_FingerEAERCtrl
#define rtXdot                         FingerEAERCtrl_Xdot
#define StateDerivatives               StateDerivatives_FingerEAERCtrl
#define tXdis                          FingerEAERCtrl_Xdis
#define StateDisabled                  StateDisabled_FingerEAERCtrl
#define rtP                            FingerEAERCtrl_P
#define Parameters                     Parameters_FingerEAERCtrl
#define rtDWork                        FingerEAERCtrl_DWork
#define D_Work                         D_Work_FingerEAERCtrl
#define rtPrevZCSigState               FingerEAERCtrl_PrevZCSigState
#define PrevZCSigStates                PrevZCSigStates_FingerEAERCtrl

/* Parameters for system: '<S92>/timeToTrigger' */
struct rtP_timeToTrigger_FingerEAERCtr_ {
  real_T Memory_X0;                    /* Expression: 0
                                        * Referenced by: '<S99>/Memory'
                                        */
  real_T Memory1_X0;                   /* Expression: 0
                                        * Referenced by: '<S99>/Memory1'
                                        */
};

/* Parameters (auto storage) */
struct Parameters_FingerEAERCtrl_ {
  real_T ForceOn_Value;                /* Expression: 1
                                        * Referenced by: '<Root>/Force On'
                                        */
  real_T Integrator_IC[3];             /* Expression: [1.5;0;0]
                                        * Referenced by: '<S8>/Integrator'
                                        */
  real_T A_Gain[9];                    /* Expression: [0 0 0;0 0 1;-70 0 0]
                                        * Referenced by: '<S8>/A'
                                        */
  real_T PCI6221AD1_P1_Size[2];        /* Computed Parameter: PCI6221AD1_P1_Size
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  real_T PCI6221AD1_P1[8];             /* Expression: channel
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  real_T PCI6221AD1_P2_Size[2];        /* Computed Parameter: PCI6221AD1_P2_Size
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  real_T PCI6221AD1_P2[8];             /* Expression: range
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  real_T PCI6221AD1_P3_Size[2];        /* Computed Parameter: PCI6221AD1_P3_Size
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  real_T PCI6221AD1_P3[8];             /* Expression: coupling
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  real_T PCI6221AD1_P4_Size[2];        /* Computed Parameter: PCI6221AD1_P4_Size
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  real_T PCI6221AD1_P4;                /* Expression: scantime
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  real_T PCI6221AD1_P5_Size[2];        /* Computed Parameter: PCI6221AD1_P5_Size
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  real_T PCI6221AD1_P5;                /* Expression: sampletime
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  real_T PCI6221AD1_P6_Size[2];        /* Computed Parameter: PCI6221AD1_P6_Size
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  real_T PCI6221AD1_P6;                /* Expression: slot
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  real_T PCI6221AD1_P7_Size[2];        /* Computed Parameter: PCI6221AD1_P7_Size
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  real_T PCI6221AD1_P7;                /* Expression: boardType
                                        * Referenced by: '<S2>/PCI-6221 AD1'
                                        */
  real_T paremeters_must_be_one_Value; /* Expression: 1
                                        * Referenced by: '<S4>/paremeters_ must_be_one'
                                        */
  real_T parLeftMode_Gain;             /* Expression: 0
                                        * Referenced by: '<S4>/parLeftMode'
                                        */
  real_T Saturation_UpperSat;          /* Expression: 1
                                        * Referenced by: '<S4>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: 0
                                        * Referenced by: '<S4>/Saturation'
                                        */
  real_T B_Gain[3];                    /* Expression: [0;0;70]
                                        * Referenced by: '<S8>/B'
                                        */
  real_T PCI6221ENC_P1_Size[2];        /* Computed Parameter: PCI6221ENC_P1_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P1;                /* Expression: device
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P2_Size[2];        /* Computed Parameter: PCI6221ENC_P2_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P2;                /* Expression: channel
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P3_Size[2];        /* Computed Parameter: PCI6221ENC_P3_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P3;                /* Expression: countMode
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P4_Size[2];        /* Computed Parameter: PCI6221ENC_P4_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P4;                /* Expression: initCount
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P5_Size[2];        /* Computed Parameter: PCI6221ENC_P5_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P5;                /* Expression: reload
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P6_Size[2];        /* Computed Parameter: PCI6221ENC_P6_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P6;                /* Expression: indexPhase
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P7_Size[2];        /* Computed Parameter: PCI6221ENC_P7_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P7;                /* Expression: filter
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P8_Size[2];        /* Computed Parameter: PCI6221ENC_P8_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P8;                /* Expression: outmask
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P9_Size[2];        /* Computed Parameter: PCI6221ENC_P9_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P9;                /* Expression: sampleTime
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P10_Size[2];       /* Computed Parameter: PCI6221ENC_P10_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC_P10;               /* Expression: slot
                                        * Referenced by: '<S2>/PCI 6221 ENC '
                                        */
  real_T PCI6221ENC1_P1_Size[2];       /* Computed Parameter: PCI6221ENC1_P1_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P1;               /* Expression: device
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P2_Size[2];       /* Computed Parameter: PCI6221ENC1_P2_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P2;               /* Expression: channel
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P3_Size[2];       /* Computed Parameter: PCI6221ENC1_P3_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P3;               /* Expression: countMode
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P4_Size[2];       /* Computed Parameter: PCI6221ENC1_P4_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P4;               /* Expression: initCount
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P5_Size[2];       /* Computed Parameter: PCI6221ENC1_P5_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P5;               /* Expression: reload
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P6_Size[2];       /* Computed Parameter: PCI6221ENC1_P6_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P6;               /* Expression: indexPhase
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P7_Size[2];       /* Computed Parameter: PCI6221ENC1_P7_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P7;               /* Expression: filter
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P8_Size[2];       /* Computed Parameter: PCI6221ENC1_P8_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P8;               /* Expression: outmask
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P9_Size[2];       /* Computed Parameter: PCI6221ENC1_P9_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P9;               /* Expression: sampleTime
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P10_Size[2];      /* Computed Parameter: PCI6221ENC1_P10_Size
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T PCI6221ENC1_P10;              /* Expression: slot
                                        * Referenced by: '<S2>/PCI 6221 ENC 1'
                                        */
  real_T Memory1_X0[2];                /* Expression: [0,0]
                                        * Referenced by: '<S17>/Memory1'
                                        */
  real_T Memory_X0;                    /* Expression: 0
                                        * Referenced by: '<S17>/Memory'
                                        */
  real_T Gain_Gain;                    /* Expression: 1/4500.0
                                        * Referenced by: '<S2>/Gain'
                                        */
  real_T B1_Gain;                      /* Expression: -1
                                        * Referenced by: '<S8>/B1'
                                        */
  real_T B2_Gain;                      /* Expression: 1
                                        * Referenced by: '<S8>/B2'
                                        */
  real_T B3_Gain;                      /* Expression: -1
                                        * Referenced by: '<S8>/B3'
                                        */
  real_T C_Gain[3];                    /* Expression: [0 1 0]
                                        * Referenced by: '<S8>/C'
                                        */
  real_T TSamp_WtEt;                   /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S10>/TSamp'
                                        */
  real_T UD_InitialCondition;          /* Expression: ICPrevScaledInput
                                        * Referenced by: '<S10>/UD'
                                        */
  real_T K_Gain[3];                    /* Expression: [-316;101;5050]
                                        * Referenced by: '<S8>/K'
                                        */
  real_T Integrator_IC_f[3];           /* Expression: [1.5;0;0]
                                        * Referenced by: '<S9>/Integrator'
                                        */
  real_T A_Gain_l[9];                  /* Expression: [0 0 0;0 0 1;-65 0 0]
                                        * Referenced by: '<S9>/A'
                                        */
  real_T B_Gain_f[3];                  /* Expression: [0;0;65]
                                        * Referenced by: '<S9>/B'
                                        */
  real_T Gain1_Gain;                   /* Expression: 1/4500.0
                                        * Referenced by: '<S2>/Gain1'
                                        */
  real_T B1_Gain_n;                    /* Expression: -1
                                        * Referenced by: '<S9>/B1'
                                        */
  real_T B2_Gain_e;                    /* Expression: 1
                                        * Referenced by: '<S9>/B2'
                                        */
  real_T B3_Gain_g;                    /* Expression: -1
                                        * Referenced by: '<S9>/B3'
                                        */
  real_T C_Gain_h[3];                  /* Expression: [0 1 0]
                                        * Referenced by: '<S9>/C'
                                        */
  real_T TSamp_WtEt_p;                 /* Computed Parameter: TSamp_WtEt_p
                                        * Referenced by: '<S11>/TSamp'
                                        */
  real_T UD_InitialCondition_p;        /* Expression: ICPrevScaledInput
                                        * Referenced by: '<S11>/UD'
                                        */
  real_T K_Gain_n[3];                  /* Expression: [-316;101;5050]
                                        * Referenced by: '<S9>/K'
                                        */
  real_T Constant_Value;               /* Expression: 1.5
                                        * Referenced by: '<S18>/Constant'
                                        */
  real_T gain_Gain;                    /* Expression: .172
                                        * Referenced by: '<S18>/gain'
                                        */
  real_T parChangeRate_Gain;           /* Expression: .05
                                        * Referenced by: '<S4>/parChangeRate'
                                        */
  real_T Saturation_UpperSat_f;        /* Expression: 1
                                        * Referenced by: '<S3>/Saturation'
                                        */
  real_T Saturation_LowerSat_o;        /* Expression: 0
                                        * Referenced by: '<S3>/Saturation'
                                        */
  real_T Memory_X0_e[4];               /* Expression: zeros(1,4)
                                        * Referenced by: '<S26>/Memory'
                                        */
  real_T parTrajMode_Gain;             /* Expression: 1
                                        * Referenced by: '<S4>/parTrajMode'
                                        */
  real_T Saturation1_UpperSat;         /* Expression: 4
                                        * Referenced by: '<S4>/Saturation1'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: 1
                                        * Referenced by: '<S4>/Saturation1'
                                        */
  real_T unity_traj_Value;             /* Expression: 1
                                        * Referenced by: '<S7>/unity_traj'
                                        */
  real_T parP1Des_Gain;                /* Expression: 0
                                        * Referenced by: '<S7>/parP1Des'
                                        */
  real_T parTHit1_Gain;                /* Expression: 50
                                        * Referenced by: '<S7>/parTHit1'
                                        */
  real_T sigTargetTime_Gain;           /* Expression: 1
                                        * Referenced by: '<S5>/sigTargetTime'
                                        */
  real_T parVThresh_Gain;              /* Expression: .375
                                        * Referenced by: '<S4>/parVThresh'
                                        */
  real_T Memory_X0_n;                  /* Expression: 0
                                        * Referenced by: '<S55>/Memory'
                                        */
  real_T parMaxTrajDur_Gain;           /* Expression: .4
                                        * Referenced by: '<S4>/parMaxTrajDur'
                                        */
  real_T Memory_X0_h;                  /* Expression: 0
                                        * Referenced by: '<S16>/Memory'
                                        */
  real_T Constant_Value_c;             /* Expression: -1
                                        * Referenced by: '<S54>/Constant'
                                        */
  real_T parFThresh_Gain;              /* Expression: 0.25
                                        * Referenced by: '<S4>/parFThresh'
                                        */
  real_T parP2Des_Gain;                /* Expression: 0
                                        * Referenced by: '<S7>/parP2Des'
                                        */
  real_T parTHit2_Gain;                /* Expression: 40
                                        * Referenced by: '<S7>/parTHit2'
                                        */
  real_T Memory_X0_c;                  /* Expression: 0
                                        * Referenced by: '<S56>/Memory'
                                        */
  real_T Memory1_X0_a;                 /* Expression: 0
                                        * Referenced by: '<S16>/Memory1'
                                        */
  real_T parFixedDur_Gain;             /* Expression: 3
                                        * Referenced by: '<S4>/parFixedDur'
                                        */
  real_T Saturation2_UpperSat;         /* Expression: 10
                                        * Referenced by: '<S4>/Saturation2'
                                        */
  real_T Saturation2_LowerSat;         /* Expression: .25
                                        * Referenced by: '<S4>/Saturation2'
                                        */
  real_T Memory1_X0_e;                 /* Expression: 0
                                        * Referenced by: '<S70>/Memory1'
                                        */
  real_T Memory1_X0_j;                 /* Expression: 0
                                        * Referenced by: '<S75>/Memory1'
                                        */
  real_T Memory1_X0_k;                 /* Expression: 0
                                        * Referenced by: '<S82>/Memory1'
                                        */
  real_T Memory_X0_d;                  /* Expression: 0
                                        * Referenced by: '<S79>/Memory'
                                        */
  real_T Memory1_X0_m;                 /* Expression: 0
                                        * Referenced by: '<S79>/Memory1'
                                        */
  real_T Memory1_X0_ja;                /* Expression: 0
                                        * Referenced by: '<S87>/Memory1'
                                        */
  real_T Memory_X0_o;                  /* Expression: 0
                                        * Referenced by: '<S80>/Memory'
                                        */
  real_T Memory1_X0_b;                 /* Expression: 0
                                        * Referenced by: '<S80>/Memory1'
                                        */
  real_T Constant_Value_j;             /* Expression: -1
                                        * Referenced by: '<S91>/Constant'
                                        */
  real_T Gain_Gain_b;                  /* Expression: 100
                                        * Referenced by: '<S92>/Gain'
                                        */
  real_T Memory2_X0;                   /* Expression: 0
                                        * Referenced by: '<S95>/Memory2'
                                        */
  real_T tDesMem_X0;                   /* Expression: 0
                                        * Referenced by: '<S92>/tDesMem'
                                        */
  real_T pholdMem_X0;                  /* Expression: 0
                                        * Referenced by: '<S92>/pholdMem'
                                        */
  real_T stateMem_X0;                  /* Expression: 0
                                        * Referenced by: '<S92>/stateMem'
                                        */
  real_T Gain_Gain_p;                  /* Expression: 100
                                        * Referenced by: '<S93>/Gain'
                                        */
  real_T Memory2_X0_k;                 /* Expression: 0
                                        * Referenced by: '<S108>/Memory2'
                                        */
  real_T tDesMem_X0_a;                 /* Expression: 0
                                        * Referenced by: '<S93>/tDesMem'
                                        */
  real_T pholdMem_X0_p;                /* Expression: 0
                                        * Referenced by: '<S93>/pholdMem'
                                        */
  real_T stateMem_X0_l;                /* Expression: 0
                                        * Referenced by: '<S93>/stateMem'
                                        */
  real_T parKp1_Gain;                  /* Expression: 0
                                        * Referenced by: '<S4>/parKp1'
                                        */
  real_T Memory_X0_g[4];               /* Expression: zeros(1,4)
                                        * Referenced by: '<S35>/Memory'
                                        */
  real_T parKp2_Gain;                  /* Expression: 0
                                        * Referenced by: '<S4>/parKp2'
                                        */
  real_T Memory_X0_a[4];               /* Expression: zeros(1,4)
                                        * Referenced by: '<S36>/Memory'
                                        */
  real_T parKd1_Gain;                  /* Expression: 0.0
                                        * Referenced by: '<S4>/parKd1'
                                        */
  real_T Memory_X0_b[4];               /* Expression: zeros(1,4)
                                        * Referenced by: '<S37>/Memory'
                                        */
  real_T parKd2_Gain;                  /* Expression: 0.0
                                        * Referenced by: '<S4>/parKd2'
                                        */
  real_T Memory_X0_g0[4];              /* Expression: zeros(1,4)
                                        * Referenced by: '<S38>/Memory'
                                        */
  real_T Saturation1_UpperSat_i;       /* Expression: 2.5
                                        * Referenced by: '<S27>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_k;       /* Expression: -2.5
                                        * Referenced by: '<S27>/Saturation1'
                                        */
  real_T parPStop_Gain;                /* Expression: 0.75
                                        * Referenced by: '<S4>/parPStop'
                                        */
  real_T parKdV1_Gain;                 /* Expression: 0.0
                                        * Referenced by: '<S4>/parKdV1'
                                        */
  real_T Memory_X0_bp[4];              /* Expression: zeros(1,4)
                                        * Referenced by: '<S39>/Memory'
                                        */
  real_T parKdV2_Gain;                 /* Expression: 0.0
                                        * Referenced by: '<S4>/parKdV2'
                                        */
  real_T Memory_X0_eq[4];              /* Expression: zeros(1,4)
                                        * Referenced by: '<S40>/Memory'
                                        */
  real_T parForceTrigger_Gain;         /* Expression: 0
                                        * Referenced by: '<S4>/parForceTrigger'
                                        */
  real_T Memory_X0_hx;                 /* Expression: 0
                                        * Referenced by: '<S28>/Memory'
                                        */
  real_T parWiggleAmp_Gain;            /* Expression: .5
                                        * Referenced by: '<S4>/parWiggleAmp'
                                        */
  real_T Memory2_X0_l;                 /* Expression: 0
                                        * Referenced by: '<S28>/Memory2'
                                        */
  real_T Memory1_X0_c;                 /* Expression: 0
                                        * Referenced by: '<S28>/Memory1'
                                        */
  real_T PCI6221DA_P1_Size[2];         /* Computed Parameter: PCI6221DA_P1_Size
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */
  real_T PCI6221DA_P1[2];              /* Expression: channel
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */
  real_T PCI6221DA_P2_Size[2];         /* Computed Parameter: PCI6221DA_P2_Size
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */
  real_T PCI6221DA_P2[2];              /* Expression: range
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */
  real_T PCI6221DA_P3_Size[2];         /* Computed Parameter: PCI6221DA_P3_Size
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */
  real_T PCI6221DA_P3[2];              /* Expression: reset
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */
  real_T PCI6221DA_P4_Size[2];         /* Computed Parameter: PCI6221DA_P4_Size
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */
  real_T PCI6221DA_P4[2];              /* Expression: initValue
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */
  real_T PCI6221DA_P5_Size[2];         /* Computed Parameter: PCI6221DA_P5_Size
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */
  real_T PCI6221DA_P5;                 /* Expression: sampletime
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */
  real_T PCI6221DA_P6_Size[2];         /* Computed Parameter: PCI6221DA_P6_Size
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */
  real_T PCI6221DA_P6;                 /* Expression: slot
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */
  real_T PCI6221DA_P7_Size[2];         /* Computed Parameter: PCI6221DA_P7_Size
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */
  real_T PCI6221DA_P7;                 /* Expression: boardType
                                        * Referenced by: '<S2>/PCI-6221 DA'
                                        */
  real_T LowPass100Hz_A[4];            /* Computed Parameter: LowPass100Hz_A
                                        * Referenced by: '<S16>/Low Pass 100 Hz'
                                        */
  real_T LowPass100Hz_B[2];            /* Computed Parameter: LowPass100Hz_B
                                        * Referenced by: '<S16>/Low Pass 100 Hz'
                                        */
  real_T LowPass100Hz_C[2];            /* Computed Parameter: LowPass100Hz_C
                                        * Referenced by: '<S16>/Low Pass 100 Hz'
                                        */
  real_T LowPass100Hz_D;               /* Computed Parameter: LowPass100Hz_D
                                        * Referenced by: '<S16>/Low Pass 100 Hz'
                                        */
  real_T LowPass100Hz_X0[2];           /* Expression: x0low
                                        * Referenced by: '<S16>/Low Pass 100 Hz'
                                        */
  real_T LowPass100Hz1_A[4];           /* Computed Parameter: LowPass100Hz1_A
                                        * Referenced by: '<S16>/Low Pass 100 Hz1'
                                        */
  real_T LowPass100Hz1_B[2];           /* Computed Parameter: LowPass100Hz1_B
                                        * Referenced by: '<S16>/Low Pass 100 Hz1'
                                        */
  real_T LowPass100Hz1_C[2];           /* Computed Parameter: LowPass100Hz1_C
                                        * Referenced by: '<S16>/Low Pass 100 Hz1'
                                        */
  real_T LowPass100Hz1_D;              /* Computed Parameter: LowPass100Hz1_D
                                        * Referenced by: '<S16>/Low Pass 100 Hz1'
                                        */
  real_T LowPass100Hz1_X0[2];          /* Expression: x0low
                                        * Referenced by: '<S16>/Low Pass 100 Hz1'
                                        */
  real_T parMarker_Gain;               /* Expression: 0
                                        * Referenced by: '<S4>/parMarker'
                                        */
  real_T sigPos1_Gain;                 /* Expression: 1
                                        * Referenced by: '<S5>/sigPos1'
                                        */
  real_T sigPos2_Gain;                 /* Expression: 1
                                        * Referenced by: '<S5>/sigPos2'
                                        */
  real_T sigVel1_Gain;                 /* Expression: 1
                                        * Referenced by: '<S5>/sigVel1'
                                        */
  real_T sigVel2_Gain;                 /* Expression: 1
                                        * Referenced by: '<S5>/sigVel2'
                                        */
  real_T sigPos1Des_Gain;              /* Expression: 1
                                        * Referenced by: '<S5>/sigPos1Des'
                                        */
  real_T sigPos2Des_Gain;              /* Expression: 1
                                        * Referenced by: '<S5>/sigPos2Des'
                                        */
  real_T sigVel1Des_Gain;              /* Expression: 1
                                        * Referenced by: '<S5>/sigVel1Des'
                                        */
  real_T sigVel2Des_Gain;              /* Expression: 1
                                        * Referenced by: '<S5>/sigVel2Des'
                                        */
  real_T sigForce1_Gain;               /* Expression: 1
                                        * Referenced by: '<S5>/sigForce1'
                                        */
  real_T sigForce2_Gain;               /* Expression: 1
                                        * Referenced by: '<S5>/sigForce2'
                                        */
  real_T sigLoadC_Gain;                /* Expression: 1
                                        * Referenced by: '<S5>/sigLoadC'
                                        */
  real_T sigLoadCF1a_Gain;             /* Expression: 1
                                        * Referenced by: '<S5>/sigLoadCF1a'
                                        */
  real_T sigLoadCF1b_Gain;             /* Expression: 1
                                        * Referenced by: '<S5>/sigLoadCF1b'
                                        */
  real_T sigLoadCF2a_Gain;             /* Expression: 1
                                        * Referenced by: '<S5>/sigLoadCF2a'
                                        */
  real_T sigLoadCF2b_Gain;             /* Expression: 1
                                        * Referenced by: '<S5>/sigLoadCF2b'
                                        */
  real_T sigForce1Clean_Gain;          /* Expression: 1
                                        * Referenced by: '<S5>/sigForce1Clean'
                                        */
  real_T sigForce2Clean_Gain;          /* Expression: 1
                                        * Referenced by: '<S5>/sigForce2Clean'
                                        */
  real_T sigGravAccel_Gain;            /* Expression: 1
                                        * Referenced by: '<S5>/sigGravAccel'
                                        */
  real_T sigTimeToThresh1_Gain;        /* Expression: 1
                                        * Referenced by: '<S5>/sigTimeToThresh1'
                                        */
  real_T sigTimeToThresh2_Gain;        /* Expression: 1
                                        * Referenced by: '<S5>/sigTimeToThresh2'
                                        */
  real_T sigMarker_Gain;               /* Expression: 1
                                        * Referenced by: '<S5>/sigMarker'
                                        */
  rtP_timeToTrigger_FingerEAERCtr timeToTrigger_e;/* '<S93>/timeToTrigger' */
  rtP_timeToTrigger_FingerEAERCtr timeToTrigger;/* '<S92>/timeToTrigger' */
};

/* Real-time Model Data Structure */
struct tag_rtM_FingerEAERCtrl {
  const char_T *path;
  const char_T *modelName;
  struct SimStruct_tag * *childSfunctions;
  const char_T *errorStatus;
  SS_SimMode simMode;
  RTWLogInfo *rtwLogInfo;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;
  RTWSolverInfo *solverInfoPtr;
  void *sfcnInfo;

  /*
   * NonInlinedSFcns:
   * The following substructure contains information regarding
   * non-inlined s-functions used in the model.
   */
  struct {
    RTWSfcnInfo sfcnInfo;
    time_T *taskTimePtrs[2];
    SimStruct childSFunctions[4];
    SimStruct *childSFunctionPtrs[4];
    struct _ssBlkInfo2 blkInfo2[4];
    struct _ssSFcnModelMethods2 methods2[4];
    struct _ssSFcnModelMethods3 methods3[4];
    struct _ssStatesInfo2 statesInfo2[4];
    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[8];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn0;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[1];
      uint_T attribs[10];
      mxArray *params[10];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn1;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[1];
      uint_T attribs[10];
      mxArray *params[10];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn2;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[2];
      real_T const *UPtrs0[1];
      real_T const *UPtrs1[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn3;
  } NonInlinedSFcns;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
  } DataMapInfo;

  /*
   * ModelData:
   * The following substructure contains information regarding
   * the data used in the model.
   */
  struct {
    void *blockIO;
    const void *constBlockIO;
    void *defaultParam;
    ZCSigState *prevZCSigState;
    real_T *contStates;
    real_T *derivs;
    void *zcSignalValues;
    void *inputs;
    void *outputs;
    boolean_T *contStateDisabled;
    boolean_T zCCacheNeedsReset;
    boolean_T derivCacheNeedsReset;
    boolean_T blkStateChange;
    real_T odeY[6];
    real_T odeF[3][6];
    ODE3_IntgData intgData;
  } ModelData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
    uint32_T options;
    int_T numContStates;
    int_T numU;
    int_T numY;
    int_T numSampTimes;
    int_T numBlocks;
    int_T numBlockIO;
    int_T numBlockPrms;
    int_T numDwork;
    int_T numSFcnPrms;
    int_T numSFcns;
    int_T numIports;
    int_T numOports;
    int_T numNonSampZCs;
    int_T sysDirFeedThru;
    int_T rtwGenSfcn;
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
    void *xpcData;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T stepSize1;
    time_T tStart;
    time_T tFinal;
    time_T timeOfLastOutput;
    void *timingData;
    real_T *varNextHitTimesList;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *sampleTimes;
    time_T *offsetTimes;
    int_T *sampleTimeTaskIDPtr;
    int_T *sampleHits;
    int_T *perTaskSampleHits;
    time_T *t;
    time_T sampleTimesArray[2];
    time_T offsetTimesArray[2];
    int_T sampleTimeTaskIDArray[2];
    int_T sampleHitArray[2];
    int_T perTaskSampleHitsArray[4];
    time_T tArray[2];
  } Timing;

  /*
   * Work:
   * The following substructure contains information regarding
   * the work vectors in the model.
   */
  struct {
    void *dwork;
  } Work;
};

/* Block parameters (auto storage) */
extern Parameters_FingerEAERCtrl FingerEAERCtrl_P;

/* Block signals (auto storage) */
extern BlockIO_FingerEAERCtrl FingerEAERCtrl_B;

/* Continuous states (auto storage) */
extern ContinuousStates_FingerEAERCtrl FingerEAERCtrl_X;

/* Block states (auto storage) */
extern D_Work_FingerEAERCtrl FingerEAERCtrl_DWork;

/* External data declarations for dependent source files */

/* Zero-crossing (trigger) state */
extern PrevZCSigStates_FingerEAERCtrl FingerEAERCtrl_PrevZCSigState;

/* Model entry point functions */
extern void FingerEAERCtrl_initialize(void);
extern void FingerEAERCtrl_output(void);
extern void FingerEAERCtrl_update(void);
extern void FingerEAERCtrl_terminate(void);

/* Real-time Model object */
extern rtModel_FingerEAERCtrl *const FingerEAERCtrl_rtM;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'FingerEAERCtrl'
 * '<S1>'   : 'FingerEAERCtrl/Kalman Filter'
 * '<S2>'   : 'FingerEAERCtrl/Robot'
 * '<S3>'   : 'FingerEAERCtrl/controller'
 * '<S4>'   : 'FingerEAERCtrl/parameters'
 * '<S5>'   : 'FingerEAERCtrl/signals'
 * '<S6>'   : 'FingerEAERCtrl/trajectory calculator'
 * '<S7>'   : 'FingerEAERCtrl/trajectory params'
 * '<S8>'   : 'FingerEAERCtrl/Kalman Filter/kalman1'
 * '<S9>'   : 'FingerEAERCtrl/Kalman Filter/kalman2'
 * '<S10>'  : 'FingerEAERCtrl/Kalman Filter/kalman1/Discrete Derivative'
 * '<S11>'  : 'FingerEAERCtrl/Kalman Filter/kalman2/Discrete Derivative'
 * '<S12>'  : 'FingerEAERCtrl/Robot/account for handedness'
 * '<S13>'  : 'FingerEAERCtrl/Robot/account for handedness force'
 * '<S14>'  : 'FingerEAERCtrl/Robot/account for handedness1'
 * '<S15>'  : 'FingerEAERCtrl/Robot/account for handedness2'
 * '<S16>'  : 'FingerEAERCtrl/Robot/filtered force output'
 * '<S17>'  : 'FingerEAERCtrl/Robot/get offsets'
 * '<S18>'  : 'FingerEAERCtrl/Robot/gravDir'
 * '<S19>'  : 'FingerEAERCtrl/Robot/account for handedness/MATLAB Function'
 * '<S20>'  : 'FingerEAERCtrl/Robot/account for handedness force/MATLAB Function'
 * '<S21>'  : 'FingerEAERCtrl/Robot/account for handedness1/MATLAB Function'
 * '<S22>'  : 'FingerEAERCtrl/Robot/account for handedness2/MATLAB Function'
 * '<S23>'  : 'FingerEAERCtrl/Robot/get offsets/MATLAB Function'
 * '<S24>'  : 'FingerEAERCtrl/Robot/gravDir/Scope (xPC) 1'
 * '<S25>'  : 'FingerEAERCtrl/controller/controller'
 * '<S26>'  : 'FingerEAERCtrl/controller/gain transition'
 * '<S27>'  : 'FingerEAERCtrl/controller/initial ramp'
 * '<S28>'  : 'FingerEAERCtrl/controller/make chirp'
 * '<S29>'  : 'FingerEAERCtrl/controller/viccosityAdder'
 * '<S30>'  : 'FingerEAERCtrl/controller/gain transition/gainramp'
 * '<S31>'  : 'FingerEAERCtrl/controller/initial ramp/MATLAB Function'
 * '<S32>'  : 'FingerEAERCtrl/controller/initial ramp/ramp'
 * '<S33>'  : 'FingerEAERCtrl/controller/make chirp/MATLAB Function'
 * '<S34>'  : 'FingerEAERCtrl/controller/make chirp/MATLAB Function1'
 * '<S35>'  : 'FingerEAERCtrl/parameters/gain transition'
 * '<S36>'  : 'FingerEAERCtrl/parameters/gain transition1'
 * '<S37>'  : 'FingerEAERCtrl/parameters/gain transition2'
 * '<S38>'  : 'FingerEAERCtrl/parameters/gain transition3'
 * '<S39>'  : 'FingerEAERCtrl/parameters/gain transition4'
 * '<S40>'  : 'FingerEAERCtrl/parameters/gain transition5'
 * '<S41>'  : 'FingerEAERCtrl/parameters/gain transition/gainramp'
 * '<S42>'  : 'FingerEAERCtrl/parameters/gain transition1/gainramp'
 * '<S43>'  : 'FingerEAERCtrl/parameters/gain transition2/gainramp'
 * '<S44>'  : 'FingerEAERCtrl/parameters/gain transition3/gainramp'
 * '<S45>'  : 'FingerEAERCtrl/parameters/gain transition4/gainramp'
 * '<S46>'  : 'FingerEAERCtrl/parameters/gain transition5/gainramp'
 * '<S47>'  : 'FingerEAERCtrl/signals/Scope (xPC) '
 * '<S48>'  : 'FingerEAERCtrl/signals/Scope (xPC) 1'
 * '<S49>'  : 'FingerEAERCtrl/signals/Scope (xPC) 2'
 * '<S50>'  : 'FingerEAERCtrl/trajectory calculator/mode 1: sub-init'
 * '<S51>'  : 'FingerEAERCtrl/trajectory calculator/mode 2: auto initiated'
 * '<S52>'  : 'FingerEAERCtrl/trajectory calculator/mode 3: auto init no return'
 * '<S53>'  : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return'
 * '<S54>'  : 'FingerEAERCtrl/trajectory calculator/mode 1: sub-init/get human force'
 * '<S55>'  : 'FingerEAERCtrl/trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc'
 * '<S56>'  : 'FingerEAERCtrl/trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1'
 * '<S57>'  : 'FingerEAERCtrl/trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/MATLAB Function'
 * '<S58>'  : 'FingerEAERCtrl/trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/detect force onset'
 * '<S59>'  : 'FingerEAERCtrl/trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/detect movement onset'
 * '<S60>'  : 'FingerEAERCtrl/trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/params buffer'
 * '<S61>'  : 'FingerEAERCtrl/trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/params buffer/buffer the trajectory params'
 * '<S62>'  : 'FingerEAERCtrl/trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1/MATLAB Function'
 * '<S63>'  : 'FingerEAERCtrl/trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1/detect force onset'
 * '<S64>'  : 'FingerEAERCtrl/trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1/detect movement onset'
 * '<S65>'  : 'FingerEAERCtrl/trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1/params buffer'
 * '<S66>'  : 'FingerEAERCtrl/trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc1/params buffer/buffer the trajectory params'
 * '<S67>'  : 'FingerEAERCtrl/trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory'
 * '<S68>'  : 'FingerEAERCtrl/trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory1'
 * '<S69>'  : 'FingerEAERCtrl/trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/MATLAB Function'
 * '<S70>'  : 'FingerEAERCtrl/trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/detect change'
 * '<S71>'  : 'FingerEAERCtrl/trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/params buffer'
 * '<S72>'  : 'FingerEAERCtrl/trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/detect change/MATLAB Function1'
 * '<S73>'  : 'FingerEAERCtrl/trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/params buffer/buffer the trajectory params'
 * '<S74>'  : 'FingerEAERCtrl/trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory1/MATLAB Function'
 * '<S75>'  : 'FingerEAERCtrl/trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory1/detect change'
 * '<S76>'  : 'FingerEAERCtrl/trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory1/params buffer'
 * '<S77>'  : 'FingerEAERCtrl/trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory1/detect change/MATLAB Function1'
 * '<S78>'  : 'FingerEAERCtrl/trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory1/params buffer/buffer the trajectory params'
 * '<S79>'  : 'FingerEAERCtrl/trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory'
 * '<S80>'  : 'FingerEAERCtrl/trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1'
 * '<S81>'  : 'FingerEAERCtrl/trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/MATLAB Function'
 * '<S82>'  : 'FingerEAERCtrl/trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/detect change'
 * '<S83>'  : 'FingerEAERCtrl/trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/params buffer'
 * '<S84>'  : 'FingerEAERCtrl/trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/detect change/MATLAB Function1'
 * '<S85>'  : 'FingerEAERCtrl/trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/params buffer/buffer the trajectory params'
 * '<S86>'  : 'FingerEAERCtrl/trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/MATLAB Function'
 * '<S87>'  : 'FingerEAERCtrl/trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/detect change'
 * '<S88>'  : 'FingerEAERCtrl/trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/params buffer'
 * '<S89>'  : 'FingerEAERCtrl/trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/detect change/MATLAB Function1'
 * '<S90>'  : 'FingerEAERCtrl/trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory1/params buffer/buffer the trajectory params'
 * '<S91>'  : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/get human force'
 * '<S92>'  : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1'
 * '<S93>'  : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2'
 * '<S94>'  : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/detect force onset1'
 * '<S95>'  : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/detect new trajectory'
 * '<S96>'  : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/force buffer'
 * '<S97>'  : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/params buffer1'
 * '<S98>'  : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/saveTrialStartTime'
 * '<S99>'  : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/timeToTrigger'
 * '<S100>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/traj calc'
 * '<S101>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/trigger check'
 * '<S102>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/detect new trajectory/MATLAB Function1'
 * '<S103>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/force buffer/buffer the initial force value'
 * '<S104>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/params buffer1/buffer the trajectory params'
 * '<S105>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/saveTrialStartTime/save the trial start time'
 * '<S106>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/timeToTrigger/save the trigger time'
 * '<S107>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/detect force onset1'
 * '<S108>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/detect new trajectory'
 * '<S109>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/force buffer'
 * '<S110>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/params buffer1'
 * '<S111>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/saveTrialStartTime'
 * '<S112>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/timeToTrigger'
 * '<S113>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/traj calc'
 * '<S114>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/trigger check'
 * '<S115>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/detect new trajectory/MATLAB Function1'
 * '<S116>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/force buffer/buffer the initial force value'
 * '<S117>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/params buffer1/buffer the trajectory params'
 * '<S118>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/saveTrialStartTime/save the trial start time'
 * '<S119>' : 'FingerEAERCtrl/trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory2/timeToTrigger/save the trigger time'
 */
#endif                                 /* RTW_HEADER_FingerEAERCtrl_h_ */
