/*
 * FingerEAERCtrl_capi.h
 *
 * Code generation for model "FingerEAERCtrl".
 *
 * Model version              : 1.750
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Thu Apr 28 15:02:04 2016
 *
 * Target selection: xpctarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef _RTW_HEADER_FingerEAERCtrl_capi_h_
#define _RTW_HEADER_FingerEAERCtrl_capi_h_
#include "FingerEAERCtrl.h"

extern void FingerEAERCtrl_InitializeDataMapInfo(rtModel_FingerEAERCtrl
  *FingerEAERCtrl_rtM
  );

#endif                                 /* _RTW_HEADER_FingerEAERCtrl_capi_h_ */

/* EOF: FingerEAERCtrl_capi.h */
