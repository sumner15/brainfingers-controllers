/*
 * FingerEAERCtrl.c
 *
 * Code generation for model "FingerEAERCtrl".
 *
 * Model version              : 1.750
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Thu Apr 28 15:02:04 2016
 *
 * Target selection: xpctarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "rt_logging_mmi.h"
#include "FingerEAERCtrl_capi.h"
#include "FingerEAERCtrl.h"
#include "FingerEAERCtrl_private.h"
#include "FingerEAERCtrl_dt.h"

/* Named constants for MATLAB Function: '<S12>/MATLAB Function' */
#define FingerEAERCtrl_CALL_EVENT      (-1)

/* Named constants for MATLAB Function: '<S26>/gainramp' */
#define FingerEAERCtrl_CALL_EVENT_c    (-1)

/* Named constants for MATLAB Function: '<S55>/MATLAB Function' */
#define FingerEAERCtrl_CALL_EVENT_d    (-1)

/* Named constants for MATLAB Function: '<S55>/detect force onset' */
#define FingerEAERCtrl_CALL_EVENT_b    (-1)

/* Named constants for MATLAB Function: '<S55>/detect movement onset' */
#define FingerEAERCtrl_CALL_EVENT_k    (-1)

/* Named constants for MATLAB Function: '<S60>/buffer the trajectory params' */
#define FingerEAERCtrl_CALL_EVENT_p    (-1)

/* Named constants for MATLAB Function: '<S67>/MATLAB Function' */
#define FingerEAERCtrl_CALL_EVENT_n    (-1)

/* Named constants for MATLAB Function: '<S70>/MATLAB Function1' */
#define FingerEAERCtrl_CALL_EVENT_km   (-1)

/* Named constants for MATLAB Function: '<S71>/buffer the trajectory params' */
#define FingerEAERCtrl_CALL_EVENT_ke   (-1)

/* Named constants for MATLAB Function: '<S79>/MATLAB Function' */
#define FingerEAERCtrl_CALL_EVENT_pr   (-1)

/* Named constants for MATLAB Function: '<S83>/buffer the trajectory params' */
#define FingerEAERCtrl_CALL_EVENT_h    (-1)

/* Named constants for MATLAB Function: '<S92>/detect force onset1' */
#define FingerEAERCtrl_CALL_EVENT_l    (-1)

/* Named constants for MATLAB Function: '<S95>/MATLAB Function1' */
#define FingerEAERCtrl_CALL_EVENT_m    (-1)

/* Named constants for MATLAB Function: '<S96>/buffer the initial force value' */
#define FingerEAERCtrl_CALL_EVENT_lh   (-1)

/* Named constants for MATLAB Function: '<S97>/buffer the trajectory params' */
#define FingerEAERCtrl_CALL_EVENT_f    (-1)

/* Named constants for MATLAB Function: '<S98>/save the trial start time' */
#define FingerEAERCtrl_CALL_EVENT_lo   (-1)

/* Named constants for MATLAB Function: '<S99>/save the trigger time' */
#define FingerEAERCtrl_CALL_EVENT_ly   (-1)

/* Named constants for MATLAB Function: '<S92>/traj calc' */
#define FingerEAERCtrl_CALL_EVENT_fy   (-1)

/* Named constants for MATLAB Function: '<S92>/trigger check' */
#define FingerEAERCtrl_CALL_EVENT_po   (-1)

/* Named constants for MATLAB Function: '<S13>/MATLAB Function' */
#define FingerEAERCtrl_CALL_EVENT_m5   (-1)

/* Block signals (auto storage) */
BlockIO_FingerEAERCtrl FingerEAERCtrl_B;

/* Continuous states */
ContinuousStates_FingerEAERCtrl FingerEAERCtrl_X;

/* Block states (auto storage) */
D_Work_FingerEAERCtrl FingerEAERCtrl_DWork;

/* Previous zero-crossings (trigger) states */
PrevZCSigStates_FingerEAERCtrl FingerEAERCtrl_PrevZCSigState;

/* Real-time model */
rtModel_FingerEAERCtrl FingerEAERCtrl_rtM_;
rtModel_FingerEAERCtrl *const FingerEAERCtrl_rtM = &FingerEAERCtrl_rtM_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 6;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  FingerEAERCtrl_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  FingerEAERCtrl_output();
  FingerEAERCtrl_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  FingerEAERCtrl_output();
  FingerEAERCtrl_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/*
 * Initial conditions for atomic system:
 *    '<S12>/MATLAB Function'
 *    '<S14>/MATLAB Function'
 *    '<S15>/MATLAB Function'
 */
void FingerEAERC_MATLABFunction_Init(rtDW_MATLABFunction_FingerEAERC *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT;
  localDW->is_active_c11_FingerEAERCtrl = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S12>/MATLAB Function'
 *    '<S14>/MATLAB Function'
 *    '<S15>/MATLAB Function'
 */
void FingerEAERCtrl_MATLABFunction(real_T rtu_input1, real_T rtu_input2, real_T
  rtu_leftyMode, rtB_MATLABFunction_FingerEAERCt *localB,
  rtDW_MATLABFunction_FingerEAERC *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT;

  /* MATLAB Function 'Robot/account for handedness/MATLAB Function': '<S19>:1' */
  /*  encoder 1 and output 1 relate to the blue mechanism */
  /*  encoder 2, output 2 and accel 2 relate to the gold mechanism */
  /*  in right hand mode, we want the gold mechanism to control the index finger */
  /*  in left hand mode, we want the blue mechanism to control the index finger */
  /*  we wallways want the index finger to be finger 1 */
  if (rtu_leftyMode == 1.0) {
    /* '<S19>:1:10' */
    /* '<S19>:1:11' */
    localB->output1 = rtu_input1;

    /* '<S19>:1:12' */
    localB->output2 = rtu_input2;
  } else {
    /* '<S19>:1:14' */
    localB->output1 = rtu_input2;

    /* '<S19>:1:15' */
    localB->output2 = rtu_input1;
  }
}

real_T rt_powd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T tmp;
  real_T tmp_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else {
    tmp = fabs(u0);
    tmp_0 = fabs(u1);
    if (rtIsInf(u1)) {
      if (tmp == 1.0) {
        y = (rtNaN);
      } else if (tmp > 1.0) {
        if (u1 > 0.0) {
          y = (rtInf);
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = (rtInf);
      }
    } else if (tmp_0 == 0.0) {
      y = 1.0;
    } else if (tmp_0 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > floor(u1))) {
      y = (rtNaN);
    } else {
      y = pow(u0, u1);
    }
  }

  return y;
}

/*
 * Initial conditions for atomic system:
 *    '<S26>/gainramp'
 *    '<S35>/gainramp'
 *    '<S36>/gainramp'
 *    '<S37>/gainramp'
 *    '<S38>/gainramp'
 *    '<S39>/gainramp'
 *    '<S40>/gainramp'
 */
void FingerEAERCtrl_gainramp_Init(rtDW_gainramp_FingerEAERCtrl *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_c;
  localDW->is_active_c8_FingerEAERCtrl = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S26>/gainramp'
 *    '<S35>/gainramp'
 *    '<S36>/gainramp'
 *    '<S37>/gainramp'
 *    '<S38>/gainramp'
 *    '<S39>/gainramp'
 *    '<S40>/gainramp'
 */
void FingerEAERCtrl_gainramp(real_T rtu_tr, real_T rtu_valD, const real_T
  rtu_state[4], rtB_gainramp_FingerEAERCtrl *localB,
  rtDW_gainramp_FingerEAERCtrl *localDW)
{
  real_T t;
  real_T Rd;
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_c;
  localB->state1[0] = rtu_state[0];
  localB->state1[1] = rtu_state[1];
  localB->state1[2] = rtu_state[2];
  localB->state1[3] = rtu_state[3];

  /* MATLAB Function 'controller/gain transition/gainramp': '<S30>:1' */
  /*  state contains [valD_,val_,Ro_,t_] */
  /*  first we need to check if they have changed the desired Value */
  if (!(rtu_valD == rtu_state[0])) {
    /* '<S30>:1:6' */
    /* '<S30>:1:7' */
    localB->state1[0] = rtu_valD;

    /* '<S30>:1:8' */
    localB->state1[3] = 0.0;

    /* '<S30>:1:9' */
    localB->state1[2] = rtu_valD - rtu_state[1];
  }

  /* '<S30>:1:12' */
  t = localB->state1[3];

  /* '<S30>:1:13' */
  if ((localB->state1[3] <= rtu_tr) && (rtu_tr != 0.0)) {
    /* '<S30>:1:15' */
    /* '<S30>:1:16' */
    Rd = localB->state1[2] - ((10.0 * rt_powd_snf(localB->state1[3], 3.0) /
      rt_powd_snf(rtu_tr, 3.0) - 15.0 * rt_powd_snf(localB->state1[3], 4.0) /
      rt_powd_snf(rtu_tr, 4.0)) + 6.0 * rt_powd_snf(localB->state1[3], 5.0) /
      rt_powd_snf(rtu_tr, 5.0)) * localB->state1[2];
  } else {
    /* '<S30>:1:18' */
    Rd = 0.0;
  }

  /* '<S30>:1:21' */
  Rd = localB->state1[0] - Rd;

  /* '<S30>:1:22' */
  localB->state1[1] = Rd;

  /* '<S30>:1:23' */
  localB->state1[3] = t + 0.001;

  /* '<S30>:1:24' */
  localB->val = Rd;
}

/*
 * Initial conditions for atomic system:
 *    '<S55>/MATLAB Function'
 *    '<S56>/MATLAB Function'
 */
void FingerEAE_MATLABFunction_e_Init(rtDW_MATLABFunction_FingerEAE_i *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_d;
  localDW->is_active_c4_FingerEAERCtrl = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S55>/MATLAB Function'
 *    '<S56>/MATLAB Function'
 */
void FingerEAERCtrl_MATLABFunction_g(real_T rtu_Pd, real_T rtu_th, real_T
  rtu_dur, real_T rtu_t, rtB_MATLABFunction_FingerEAER_h *localB,
  rtDW_MATLABFunction_FingerEAE_i *localDW)
{
  real_T startT;
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_d;

  /* MATLAB Function 'trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/MATLAB Function': '<S57>:1' */
  /*  th is the hit time */
  /*  Pd id the final destination */
  /*  t is the current time */
  /*  dur is the duration  */
  /* '<S57>:1:7' */
  startT = rtu_th - rtu_dur;

  /*  number of miliseconds until the hit time */
  /* '<S57>:1:8' */
  /*  return time */
  if ((rtu_t > startT) && (rtu_t <= rtu_th)) {
    /* '<S57>:1:10' */
    /* '<S57>:1:11' */
    startT = rtu_t - startT;

    /* '<S57>:1:12' */
    localB->des[0] = (10.0 * rtu_Pd * rt_powd_snf(startT, 3.0) / rt_powd_snf
                      (rtu_dur, 3.0) - 15.0 * rtu_Pd * rt_powd_snf(startT, 4.0) /
                      rt_powd_snf(rtu_dur, 4.0)) + 6.0 * rtu_Pd * rt_powd_snf
      (startT, 5.0) / rt_powd_snf(rtu_dur, 5.0);
    localB->des[1] = (30.0 * rtu_Pd * rt_powd_snf(startT, 2.0) / rt_powd_snf
                      (rtu_dur, 3.0) - 60.0 * rtu_Pd * rt_powd_snf(startT, 3.0) /
                      rt_powd_snf(rtu_dur, 4.0)) + 30.0 * rtu_Pd * rt_powd_snf
      (startT, 4.0) / rt_powd_snf(rtu_dur, 5.0);
    localB->des[2] = (120.0 * rtu_Pd * rt_powd_snf(startT, 3.0) / rt_powd_snf
                      (rtu_dur, 5.0) - 180.0 * rtu_Pd * rt_powd_snf(startT, 2.0)
                      / rt_powd_snf(rtu_dur, 4.0)) + 60.0 * rtu_Pd * startT /
      rt_powd_snf(rtu_dur, 3.0);
  } else if ((rtu_th < rtu_t) && (rtu_t < rtu_th + rtu_dur)) {
    /* '<S57>:1:15' */
    /* '<S57>:1:16' */
    startT = rtu_t - rtu_th;

    /* '<S57>:1:17' */
    localB->des[0] = ((rtu_Pd - 10.0 * rtu_Pd * rt_powd_snf(startT, 3.0) /
                       rt_powd_snf(rtu_dur, 3.0)) + 15.0 * rtu_Pd * rt_powd_snf
                      (startT, 4.0) / rt_powd_snf(rtu_dur, 4.0)) - 6.0 * rtu_Pd *
      rt_powd_snf(startT, 5.0) / rt_powd_snf(rtu_dur, 5.0);
    localB->des[1] = (60.0 * rtu_Pd * rt_powd_snf(startT, 3.0) / rt_powd_snf
                      (rtu_dur, 4.0) - 30.0 * rtu_Pd * rt_powd_snf(startT, 2.0) /
                      rt_powd_snf(rtu_dur, 3.0)) - 30.0 * rtu_Pd * rt_powd_snf
      (startT, 4.0) / rt_powd_snf(rtu_dur, 5.0);
    localB->des[2] = (180.0 * rtu_Pd * rt_powd_snf(startT, 2.0) / rt_powd_snf
                      (rtu_dur, 4.0) - 120.0 * rtu_Pd * rt_powd_snf(startT, 3.0)
                      / rt_powd_snf(rtu_dur, 5.0)) - 60.0 * rtu_Pd * startT /
      rt_powd_snf(rtu_dur, 3.0);
  } else {
    /* '<S57>:1:21' */
    localB->des[0] = 0.0;
    localB->des[1] = 0.0;
    localB->des[2] = 0.0;
  }
}

/*
 * Initial conditions for atomic system:
 *    '<S55>/detect force onset'
 *    '<S56>/detect force onset'
 */
void FingerEAE_detectforceonset_Init(rtDW_detectforceonset_FingerEAE *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_b;
  localDW->is_active_c46_FingerEAERCtrl = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S55>/detect force onset'
 *    '<S56>/detect force onset'
 */
void FingerEAERCtrl_detectforceonset(real_T rtu_force, real_T rtu_F_THRESH,
  real_T rtu_tDes, real_T rtu_t, real_T rtu_pTraj, real_T rtu_maxDur,
  rtB_detectforceonset_FingerEAER *localB, rtDW_detectforceonset_FingerEAE
  *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_b;

  /* MATLAB Function 'trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/detect force onset': '<S58>:1' */
  /*  this function will detect when the subject startes to move. As soon as */
  /*  the subject's velocity reaches a certain threshold, get the distance to */
  /*  the target and the start time */
  /* '<S58>:1:6' */
  localB->update = 0.0;
  if ((rtu_force > rtu_F_THRESH) && (rtu_t < rtu_tDes) && (rtu_pTraj == 0.0) &&
      (fabs(rtu_tDes - rtu_t) > 0.15) && (fabs(rtu_tDes - rtu_t) < rtu_maxDur))
  {
    /* '<S58>:1:7' */
    /*     %% add another condition to make sure that the robot does not try to move super fast */
    /* '<S58>:1:9' */
    /* '<S58>:1:10' */
    localB->update = 1.0;
  }
}

/*
 * Initial conditions for atomic system:
 *    '<S55>/detect movement onset'
 *    '<S56>/detect movement onset'
 */
void Finger_detectmovementonset_Init(rtDW_detectmovementonset_Finger *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_k;
  localDW->is_active_c1_FingerEAERCtrl = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S55>/detect movement onset'
 *    '<S56>/detect movement onset'
 */
void FingerEAERC_detectmovementonset(real_T rtu_vel, real_T rtu_V_THRESH, real_T
  rtu_tDes, real_T rtu_t, real_T rtu_pTraj, real_T rtu_maxDur,
  rtB_detectmovementonset_FingerE *localB, rtDW_detectmovementonset_Finger
  *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_k;

  /* MATLAB Function 'trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/detect movement onset': '<S59>:1' */
  /*  this function will detect when the subject startes to move. As soon as */
  /*  the subject's velocity reaches a certain threshold, get the distance to */
  /*  the target and the start time */
  /* '<S59>:1:6' */
  localB->update = 0.0;
  if ((rtu_vel > rtu_V_THRESH) && (rtu_t < rtu_tDes) && (rtu_pTraj == 0.0) &&
      (fabs(rtu_tDes - rtu_t) > 0.15) && (fabs(rtu_tDes - rtu_t) < rtu_maxDur))
  {
    /* '<S59>:1:7' */
    /*     %% add another condition to make sure that the robot does not try to move super fast */
    /* '<S59>:1:9' */
    /* '<S59>:1:10' */
    localB->update = 1.0;
  }
}

/*
 * Initial conditions for trigger system:
 *    '<S55>/params buffer'
 *    '<S56>/params buffer'
 */
void FingerEAERCtr_paramsbuffer_Init(rtDW_paramsbuffer_FingerEAERCtr *localDW)
{
  /* InitializeConditions for MATLAB Function: '<S60>/buffer the trajectory params' */
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_p;
  localDW->is_active_c3_FingerEAERCtrl = 0U;
}

/*
 * Output and update for trigger system:
 *    '<S55>/params buffer'
 *    '<S56>/params buffer'
 */
void FingerEAERCtrl_paramsbuffer(boolean_T rtu_0, real_T rtu_pDes_, real_T
  rtu_tHit_, real_T rtu_t, rtModel_FingerEAERCtrl * const FingerEAERCtrl_rtM,
  rtB_paramsbuffer_FingerEAERCtrl *localB, rtDW_paramsbuffer_FingerEAERCtr
  *localDW, rtZCE_paramsbuffer_FingerEAERCt *localZCE)
{
  boolean_T zcEvent;

  /* Outputs for Triggered SubSystem: '<S55>/params buffer' incorporates:
   *  TriggerPort: '<S60>/Trigger'
   */
  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    zcEvent = (rtu_0 && (localZCE->paramsbuffer_Trig_ZCE_n != POS_ZCSIG));
    if (zcEvent) {
      /* MATLAB Function: '<S60>/buffer the trajectory params' */
      localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_p;

      /* MATLAB Function 'trajectory calculator/mode 1: sub-init/rt minimum jerk trajectory calc/params buffer/buffer the trajectory params': '<S61>:1' */
      /* '<S61>:1:3' */
      localB->pDes = rtu_pDes_;

      /* '<S61>:1:4' */
      localB->tHit = rtu_tHit_;

      /* '<S61>:1:5' */
      localB->dur = rtu_tHit_ - rtu_t;

      /*  Ro = abs(pDes - pos) */
      /*  to = t */
      /*  tr = tDes - to */
      localDW->paramsbuffer_SubsysRanBC = 4;
    }

    localZCE->paramsbuffer_Trig_ZCE_n = (uint8_T)(rtu_0 ? (int32_T)POS_ZCSIG :
      (int32_T)ZERO_ZCSIG);
  }

  /* End of Outputs for SubSystem: '<S55>/params buffer' */
}

/*
 * Initial conditions for atomic system:
 *    '<S67>/MATLAB Function'
 *    '<S68>/MATLAB Function'
 */
void FingerEAE_MATLABFunction_a_Init(rtDW_MATLABFunction_FingerEA_ig *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_n;
  localDW->is_active_c34_FingerEAERCtrl = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S67>/MATLAB Function'
 *    '<S68>/MATLAB Function'
 */
void FingerEAERCtrl_MATLABFunction_m(real_T rtu_Pd, real_T rtu_Pstart, real_T
  rtu_th, real_T rtu_dur, real_T rtu_t, rtB_MATLABFunction_FingerEAER_b *localB,
  rtDW_MATLABFunction_FingerEA_ig *localDW)
{
  real_T startT;
  real_T Prel;
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_n;

  /* MATLAB Function 'trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/MATLAB Function': '<S69>:1' */
  /*  th is the hit time */
  /*  Pd id the final destination */
  /*  t is the current time */
  /*  dur is the duration  */
  /* '<S69>:1:7' */
  startT = rtu_th - rtu_dur;

  /*  number of miliseconds until the hit time */
  /* '<S69>:1:8' */
  /*  return time */
  /* '<S69>:1:10' */
  Prel = rtu_Pd - rtu_Pstart;
  if ((rtu_t > startT) && (rtu_t <= rtu_th)) {
    /* '<S69>:1:12' */
    /* '<S69>:1:13' */
    startT = rtu_t - startT;

    /* '<S69>:1:14' */
    localB->des[0] = ((10.0 * Prel * rt_powd_snf(startT, 3.0) / rt_powd_snf
                       (rtu_dur, 3.0) - 15.0 * Prel * rt_powd_snf(startT, 4.0) /
                       rt_powd_snf(rtu_dur, 4.0)) + 6.0 * Prel * rt_powd_snf
                      (startT, 5.0) / rt_powd_snf(rtu_dur, 5.0)) + rtu_Pstart;
    localB->des[1] = (30.0 * Prel * rt_powd_snf(startT, 2.0) / rt_powd_snf
                      (rtu_dur, 3.0) - 60.0 * Prel * rt_powd_snf(startT, 3.0) /
                      rt_powd_snf(rtu_dur, 4.0)) + 30.0 * Prel * rt_powd_snf
      (startT, 4.0) / rt_powd_snf(rtu_dur, 5.0);
    localB->des[2] = (120.0 * Prel * rt_powd_snf(startT, 3.0) / rt_powd_snf
                      (rtu_dur, 5.0) - 180.0 * Prel * rt_powd_snf(startT, 2.0) /
                      rt_powd_snf(rtu_dur, 4.0)) + 60.0 * Prel * startT /
      rt_powd_snf(rtu_dur, 3.0);
  } else if ((rtu_th < rtu_t) && (rtu_t < rtu_th + rtu_dur)) {
    /* '<S69>:1:17' */
    /* '<S69>:1:18' */
    startT = rtu_t - rtu_th;

    /* '<S69>:1:19' */
    localB->des[0] = ((rtu_Pd - 10.0 * rtu_Pd * rt_powd_snf(startT, 3.0) /
                       rt_powd_snf(rtu_dur, 3.0)) + 15.0 * rtu_Pd * rt_powd_snf
                      (startT, 4.0) / rt_powd_snf(rtu_dur, 4.0)) - 6.0 * rtu_Pd *
      rt_powd_snf(startT, 5.0) / rt_powd_snf(rtu_dur, 5.0);
    localB->des[1] = (60.0 * rtu_Pd * rt_powd_snf(startT, 3.0) / rt_powd_snf
                      (rtu_dur, 4.0) - 30.0 * rtu_Pd * rt_powd_snf(startT, 2.0) /
                      rt_powd_snf(rtu_dur, 3.0)) - 30.0 * rtu_Pd * rt_powd_snf
      (startT, 4.0) / rt_powd_snf(rtu_dur, 5.0);
    localB->des[2] = (180.0 * rtu_Pd * rt_powd_snf(startT, 2.0) / rt_powd_snf
                      (rtu_dur, 4.0) - 120.0 * rtu_Pd * rt_powd_snf(startT, 3.0)
                      / rt_powd_snf(rtu_dur, 5.0)) - 60.0 * rtu_Pd * startT /
      rt_powd_snf(rtu_dur, 3.0);
  } else {
    /* '<S69>:1:23' */
    localB->des[0] = 0.0;
    localB->des[1] = 0.0;
    localB->des[2] = 0.0;
  }

  if (localB->des[1] < 0.0) {
    /* '<S69>:1:26' */
    /* '<S69>:1:27' */
    localB->des[1] = 0.0;
  }
}

/*
 * Initial conditions for atomic system:
 *    '<S70>/MATLAB Function1'
 *    '<S75>/MATLAB Function1'
 *    '<S82>/MATLAB Function1'
 *    '<S87>/MATLAB Function1'
 */
void FingerEAER_MATLABFunction1_Init(rtDW_MATLABFunction1_FingerEAER *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_km;
  localDW->is_active_c36_FingerEAERCtrl = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S70>/MATLAB Function1'
 *    '<S75>/MATLAB Function1'
 *    '<S82>/MATLAB Function1'
 *    '<S87>/MATLAB Function1'
 */
void FingerEAERCtrl_MATLABFunction1(real_T rtu_pDes, real_T rtu_pDes_,
  rtB_MATLABFunction1_FingerEAERC *localB, rtDW_MATLABFunction1_FingerEAER
  *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_km;

  /* MATLAB Function 'trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/detect change/MATLAB Function1': '<S72>:1' */
  /* '<S72>:1:3' */
  localB->change = 0.0;

  /* '<S72>:1:4' */
  if ((rtu_pDes - rtu_pDes_ > 0.0) && (rtu_pDes_ == 0.0)) {
    /* '<S72>:1:5' */
    /* '<S72>:1:6' */
    localB->change = 1.0;
  }
}

/*
 * Initial conditions for trigger system:
 *    '<S67>/params buffer'
 *    '<S68>/params buffer'
 */
void FingerEAERC_paramsbuffer_n_Init(rtDW_paramsbuffer_FingerEAERC_p *localDW)
{
  /* InitializeConditions for MATLAB Function: '<S71>/buffer the trajectory params' */
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_ke;
  localDW->is_active_c38_FingerEAERCtrl = 0U;
}

/*
 * Output and update for trigger system:
 *    '<S67>/params buffer'
 *    '<S68>/params buffer'
 */
void FingerEAERCtrl_paramsbuffer_k(real_T rtu_0, real_T rtu_1, real_T rtu_pDes_,
  real_T rtu_pos_, real_T rtu_tHit_, rtModel_FingerEAERCtrl * const
  FingerEAERCtrl_rtM, rtB_paramsbuffer_FingerEAERCt_c *localB,
  rtDW_paramsbuffer_FingerEAERC_p *localDW, rtZCE_paramsbuffer_FingerEAER_a
  *localZCE)
{
  ZCEventType zcEvent;

  /* Outputs for Triggered SubSystem: '<S67>/params buffer' incorporates:
   *  TriggerPort: '<S71>/Trigger'
   */
  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->paramsbuffer_Trig_ZCE_p,
                       (rtu_0));
    if (zcEvent != NO_ZCEVENT) {
      /* MATLAB Function: '<S71>/buffer the trajectory params' */
      localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_ke;

      /* MATLAB Function 'trajectory calculator/mode 2: auto initiated/rt minimum jerk trajectory/params buffer/buffer the trajectory params': '<S73>:1' */
      /* '<S73>:1:3' */
      localB->pDes = rtu_pDes_;

      /* '<S73>:1:4' */
      localB->pos = rtu_pos_;

      /* '<S73>:1:5' */
      localB->tHit = rtu_tHit_;

      /* Inport: '<S71>/fixedDur' */
      /*  Ro = abs(pDes - pos) */
      /*  to = t */
      /*  tr = tDes - to */
      localB->fixedDur = rtu_1;
      localDW->paramsbuffer_SubsysRanBC = 4;
    }
  }

  /* End of Outputs for SubSystem: '<S67>/params buffer' */
}

/*
 * Initial conditions for atomic system:
 *    '<S79>/MATLAB Function'
 *    '<S80>/MATLAB Function'
 */
void FingerEAE_MATLABFunction_n_Init(rtDW_MATLABFunction_FingerEAE_l *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_pr;
  localDW->is_active_c5_FingerEAERCtrl = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S79>/MATLAB Function'
 *    '<S80>/MATLAB Function'
 */
void FingerEAERCtrl_MATLABFunction_c(real_T rtu_Pd, real_T rtu_th, real_T
  rtu_dur, real_T rtu_t, real_T rtu_Phold_, real_T rtu_state_, real_T
  rtu_Pactual_, rtB_MATLABFunction_FingerEAER_i *localB,
  rtDW_MATLABFunction_FingerEAE_l *localDW)
{
  real_T startT;
  real_T Pr;
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_pr;

  /* MATLAB Function 'trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/MATLAB Function': '<S81>:1' */
  /*  th is the hit time */
  /*  Pd id the final destination */
  /*  t is the current time */
  /*  dur is the duration  */
  /* '<S81>:1:6' */
  startT = rtu_th - rtu_dur;

  /*  number of miliseconds until the hit time */
  /* '<S81>:1:8' */
  Pr = rtu_Pd - rtu_Phold_;

  /* '<S81>:1:9' */
  localB->Phold = rtu_Phold_;

  /* '<S81>:1:10' */
  localB->state = rtu_state_;
  switch ((int32_T)rtu_state_) {
   case 0:
    /* before movement starts */
    /* des = [Phold_; 0; 0]; */
    /* '<S81>:1:15' */
    localB->des[0] = rtu_Pactual_;
    localB->des[1] = 0.0;
    localB->des[2] = 0.0;
    if (rtu_t > startT) {
      /* '<S81>:1:16' */
      localB->state = 1.0;
    }
    break;

   case 1:
    /* movement period */
    /* '<S81>:1:19' */
    startT = rtu_t - startT;

    /* '<S81>:1:20' */
    localB->des[0] = ((10.0 * Pr * rt_powd_snf(startT, 3.0) / rt_powd_snf
                       (rtu_dur, 3.0) - 15.0 * Pr * rt_powd_snf(startT, 4.0) /
                       rt_powd_snf(rtu_dur, 4.0)) + 6.0 * Pr * rt_powd_snf
                      (startT, 5.0) / rt_powd_snf(rtu_dur, 5.0)) + rtu_Phold_;
    localB->des[1] = (30.0 * Pr * rt_powd_snf(startT, 2.0) / rt_powd_snf(rtu_dur,
      3.0) - 60.0 * Pr * rt_powd_snf(startT, 3.0) / rt_powd_snf(rtu_dur, 4.0)) +
      30.0 * Pr * rt_powd_snf(startT, 4.0) / rt_powd_snf(rtu_dur, 5.0);
    localB->des[2] = (120.0 * Pr * rt_powd_snf(startT, 3.0) / rt_powd_snf
                      (rtu_dur, 5.0) - 180.0 * Pr * rt_powd_snf(startT, 2.0) /
                      rt_powd_snf(rtu_dur, 4.0)) + 60.0 * Pr * startT /
      rt_powd_snf(rtu_dur, 3.0);
    if (rtu_t > rtu_th) {
      /* '<S81>:1:23' */
      localB->state = 2.0;
    }
    break;

   case 2:
    /* movement just finished (set hold position -> goto state 3) */
    /* Phold = Pd;         */
    /* '<S81>:1:27' */
    localB->Phold = rtu_Pactual_;

    /* des = [Pd; 0; 0]; */
    /* '<S81>:1:29' */
    localB->des[0] = rtu_Pactual_;
    localB->des[1] = 0.0;
    localB->des[2] = 0.0;

    /* '<S81>:1:30' */
    localB->state = 3.0;
    break;

   case 3:
    /* in between movements      */
    /* '<S81>:1:33' */
    localB->des[0] = rtu_Phold_;
    localB->des[1] = 0.0;
    localB->des[2] = 0.0;
    if (rtu_t < startT) {
      /* '<S81>:1:34' */
      localB->state = 0.0;
    }
    break;

   default:
    /* '<S81>:1:36' */
    localB->state = 0.0;

    /* '<S81>:1:37' */
    localB->Phold = 0.0;

    /* '<S81>:1:38' */
    localB->des[0] = rtu_Phold_;
    localB->des[1] = 0.0;
    localB->des[2] = 0.0;
    break;
  }
}

/*
 * Initial conditions for trigger system:
 *    '<S79>/params buffer'
 *    '<S80>/params buffer'
 */
void FingerEAERC_paramsbuffer_b_Init(rtDW_paramsbuffer_FingerEAERC_j *localDW)
{
  /* InitializeConditions for MATLAB Function: '<S83>/buffer the trajectory params' */
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_h;
  localDW->is_active_c7_FingerEAERCtrl = 0U;
}

/*
 * Output and update for trigger system:
 *    '<S79>/params buffer'
 *    '<S80>/params buffer'
 */
void FingerEAERCtrl_paramsbuffer_o(real_T rtu_0, real_T rtu_1, real_T rtu_pDes_,
  real_T rtu_tHit_, rtModel_FingerEAERCtrl * const FingerEAERCtrl_rtM,
  rtB_paramsbuffer_FingerEAERCt_d *localB, rtDW_paramsbuffer_FingerEAERC_j
  *localDW, rtZCE_paramsbuffer_FingerEAER_l *localZCE)
{
  ZCEventType zcEvent;

  /* Outputs for Triggered SubSystem: '<S79>/params buffer' incorporates:
   *  TriggerPort: '<S83>/Trigger'
   */
  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->paramsbuffer_Trig_ZCE,
                       (rtu_0));
    if (zcEvent != NO_ZCEVENT) {
      /* MATLAB Function: '<S83>/buffer the trajectory params' */
      localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_h;

      /* MATLAB Function 'trajectory calculator/mode 3: auto init no return/rt minimum jerk trajectory/params buffer/buffer the trajectory params': '<S85>:1' */
      /* '<S85>:1:3' */
      localB->pDes = rtu_pDes_;

      /* '<S85>:1:4' */
      localB->tHit = rtu_tHit_;

      /* Inport: '<S83>/fixedDur' */
      /*  Ro = abs(pDes - pos) */
      /*  to = t */
      /*  tr = tDes - to */
      localB->fixedDur = rtu_1;
      localDW->paramsbuffer_SubsysRanBC = 4;
    }
  }

  /* End of Outputs for SubSystem: '<S79>/params buffer' */
}

/*
 * Initial conditions for atomic system:
 *    '<S92>/detect force onset1'
 *    '<S93>/detect force onset1'
 */
void FingerEA_detectforceonset1_Init(rtDW_detectforceonset1_FingerEA *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_l;
  localDW->is_active_c32_FingerEAERCtrl = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S92>/detect force onset1'
 *    '<S93>/detect force onset1'
 */
void FingerEAERCtr_detectforceonset1(real_T rtu_Pdes, real_T rtu_force, real_T
  rtu_F_THRESH, real_T rtu_tDes_, real_T rtu_t, real_T rtu_f0_,
  rtB_detectforceonset1_FingerEAE *localB, rtDW_detectforceonset1_FingerEA
  *localDW)
{
  real_T force;
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_l;

  /* MATLAB Function 'trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/detect force onset1': '<S94>:1' */
  /*  this function will detect when the subject startes to move. As soon as */
  /*  the subject's velocity reaches a certain threshold, get the distance to */
  /*  the target and the start time */
  /* '<S94>:1:5' */
  localB->update = 0.0;

  /*  change force to a difference based on a baseline value */
  /* '<S94>:1:8' */
  force = rtu_force - rtu_f0_;

  /*  reverse force requirement if in extension */
  if (rtu_Pdes < 0.5) {
    /* '<S94>:1:11' */
    /* '<S94>:1:12' */
    force = -force;
  }

  /*  check for threshold within time window */
  if ((force > rtu_F_THRESH) && (rtu_t < rtu_tDes_)) {
    /* '<S94>:1:16' */
    /* '<S94>:1:17' */
    localB->update = 1.0;
  }

  /*  pass this value onto the buffer */
  /* '<S94>:1:21' */
  localB->tDes = rtu_tDes_;
}

/*
 * Initial conditions for atomic system:
 *    '<S95>/MATLAB Function1'
 *    '<S108>/MATLAB Function1'
 */
void FingerEA_MATLABFunction1_j_Init(rtDW_MATLABFunction1_FingerEA_m *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_m;
  localDW->is_active_c49_FingerEAERCtrl = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S95>/MATLAB Function1'
 *    '<S108>/MATLAB Function1'
 */
void FingerEAERCtr_MATLABFunction1_k(real_T rtu_tDes, real_T rtu_tDesLast,
  rtB_MATLABFunction1_FingerEAE_l *localB, rtDW_MATLABFunction1_FingerEA_m
  *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_m;

  /* MATLAB Function 'trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/detect new trajectory/MATLAB Function1': '<S102>:1' */
  if (rtu_tDes != rtu_tDesLast) {
    /* '<S102>:1:2' */
    /* '<S102>:1:3' */
    localB->change = 1.0;
  } else {
    /* '<S102>:1:5' */
    localB->change = 0.0;
  }

  /* '<S102>:1:7' */
  localB->tDesOut = rtu_tDes;
}

/*
 * Initial conditions for trigger system:
 *    '<S92>/force buffer'
 *    '<S93>/force buffer'
 */
void FingerEAERCtrl_forcebuffer_Init(rtDW_forcebuffer_FingerEAERCtrl *localDW)
{
  /* InitializeConditions for MATLAB Function: '<S96>/buffer the initial force value' */
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_lh;
  localDW->is_active_c50_FingerEAERCtrl = 0U;
}

/*
 * Output and update for trigger system:
 *    '<S92>/force buffer'
 *    '<S93>/force buffer'
 */
void FingerEAERCtrl_forcebuffer(real_T rtu_0, real_T rtu_force_,
  rtModel_FingerEAERCtrl * const FingerEAERCtrl_rtM,
  rtB_forcebuffer_FingerEAERCtrl *localB, rtDW_forcebuffer_FingerEAERCtrl
  *localDW, rtZCE_forcebuffer_FingerEAERCtr *localZCE)
{
  ZCEventType zcEvent;

  /* Outputs for Triggered SubSystem: '<S92>/force buffer' incorporates:
   *  TriggerPort: '<S96>/Trigger'
   */
  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->forcebuffer_Trig_ZCE,
                       (rtu_0));
    if (zcEvent != NO_ZCEVENT) {
      /* MATLAB Function: '<S96>/buffer the initial force value' */
      localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_lh;

      /* MATLAB Function 'trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/force buffer/buffer the initial force value': '<S103>:1' */
      /* '<S103>:1:2' */
      localB->force = rtu_force_;
      localDW->forcebuffer_SubsysRanBC = 4;
    }
  }

  /* End of Outputs for SubSystem: '<S92>/force buffer' */
}

/*
 * Initial conditions for trigger system:
 *    '<S92>/params buffer1'
 *    '<S93>/params buffer1'
 */
void FingerEAERCt_paramsbuffer1_Init(rtDW_paramsbuffer1_FingerEAERCt *localDW)
{
  /* InitializeConditions for MATLAB Function: '<S97>/buffer the trajectory params' */
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_f;
  localDW->is_active_c51_FingerEAERCtrl = 0U;
}

/*
 * Output and update for trigger system:
 *    '<S92>/params buffer1'
 *    '<S93>/params buffer1'
 */
void FingerEAERCtrl_paramsbuffer1(real_T rtu_0, real_T rtu_pDes_, real_T
  rtu_tHit_, real_T rtu_maxDur, real_T rtu_t, rtModel_FingerEAERCtrl * const
  FingerEAERCtrl_rtM, rtB_paramsbuffer1_FingerEAERCtr *localB,
  rtDW_paramsbuffer1_FingerEAERCt *localDW, rtZCE_paramsbuffer1_FingerEAERC
  *localZCE)
{
  real_T minDur;
  real_T time_left;
  ZCEventType zcEvent;

  /* Outputs for Triggered SubSystem: '<S92>/params buffer1' incorporates:
   *  TriggerPort: '<S97>/Trigger'
   */
  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->paramsbuffer1_Trig_ZCE,
                       (rtu_0));
    if (zcEvent != NO_ZCEVENT) {
      /* MATLAB Function: '<S97>/buffer the trajectory params' */
      localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_f;

      /* MATLAB Function 'trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/params buffer1/buffer the trajectory params': '<S104>:1' */
      /* % %% calculate movement duration %%%% */
      /* '<S104>:1:4' */
      minDur = rtu_maxDur / 2.0;

      /* '<S104>:1:5' */
      time_left = fabs(rtu_tHit_ - rtu_t);

      /*  this assumes that dur (which is the max dur) is greater than minDur */
      if (time_left > rtu_maxDur) {
        /* '<S104>:1:8' */
        /* '<S104>:1:9' */
        minDur = rtu_maxDur;
      } else if ((time_left < rtu_maxDur) && (time_left > minDur)) {
        /* '<S104>:1:10' */
        /* '<S104>:1:11' */
        minDur = time_left;
      } else if (!(time_left < minDur)) {
        /* '<S104>:1:15' */
        minDur = rtu_maxDur;
      } else {
        /* '<S104>:1:12' */
        /* '<S104>:1:13' */
      }

      /* % %% set new movement completion parameters %%%% */
      /* '<S104>:1:19' */
      localB->pDes = rtu_pDes_;

      /* '<S104>:1:20' */
      localB->tHit = (rtu_t + minDur) + 0.001;

      /* dur already set above */
      localB->dur = minDur;

      /* End of MATLAB Function: '<S97>/buffer the trajectory params' */
      localDW->paramsbuffer1_SubsysRanBC = 4;
    }
  }

  /* End of Outputs for SubSystem: '<S92>/params buffer1' */
}

/*
 * Initial conditions for trigger system:
 *    '<S92>/saveTrialStartTime'
 *    '<S93>/saveTrialStartTime'
 */
void FingerE_saveTrialStartTime_Init(rtDW_saveTrialStartTime_FingerE *localDW)
{
  /* InitializeConditions for MATLAB Function: '<S98>/save the trial start time' */
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_lo;
  localDW->is_active_c52_FingerEAERCtrl = 0U;
}

/*
 * Output and update for trigger system:
 *    '<S92>/saveTrialStartTime'
 *    '<S93>/saveTrialStartTime'
 */
void FingerEAERCt_saveTrialStartTime(real_T rtu_0, real_T rtu_t,
  rtModel_FingerEAERCtrl * const FingerEAERCtrl_rtM,
  rtB_saveTrialStartTime_FingerEA *localB, rtDW_saveTrialStartTime_FingerE
  *localDW, rtZCE_saveTrialStartTime_Finger *localZCE)
{
  ZCEventType zcEvent;

  /* Outputs for Triggered SubSystem: '<S92>/saveTrialStartTime' incorporates:
   *  TriggerPort: '<S98>/Trigger'
   */
  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                       &localZCE->saveTrialStartTime_Trig_ZCE,
                       (rtu_0));
    if (zcEvent != NO_ZCEVENT) {
      /* MATLAB Function: '<S98>/save the trial start time' */
      localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_lo;

      /* MATLAB Function 'trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/saveTrialStartTime/save the trial start time': '<S105>:1' */
      /* '<S105>:1:2' */
      localB->trialStartTime = rtu_t;
      localDW->saveTrialStartTime_SubsysRanBC = 4;
    }
  }

  /* End of Outputs for SubSystem: '<S92>/saveTrialStartTime' */
}

/*
 * Initial conditions for trigger system:
 *    '<S92>/timeToTrigger'
 *    '<S93>/timeToTrigger'
 */
void FingerEAERCt_timeToTrigger_Init(rtDW_timeToTrigger_FingerEAERCt *localDW,
  rtP_timeToTrigger_FingerEAERCtr *localP)
{
  /* InitializeConditions for Memory: '<S99>/Memory' */
  localDW->Memory_PreviousInput = localP->Memory_X0;

  /* InitializeConditions for Memory: '<S99>/Memory1' */
  localDW->Memory1_PreviousInput = localP->Memory1_X0;

  /* InitializeConditions for MATLAB Function: '<S99>/save the trigger time' */
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_ly;
  localDW->is_active_c53_FingerEAERCtrl = 0U;
}

/*
 * Output and update for trigger system:
 *    '<S92>/timeToTrigger'
 *    '<S93>/timeToTrigger'
 */
void FingerEAERCtrl_timeToTrigger(real_T rtu_0, real_T rtu_t, real_T
  rtu_trialStart, rtModel_FingerEAERCtrl * const FingerEAERCtrl_rtM,
  rtB_timeToTrigger_FingerEAERCtr *localB, rtDW_timeToTrigger_FingerEAERCt
  *localDW, rtZCE_timeToTrigger_FingerEAERC *localZCE)
{
  ZCEventType zcEvent;

  /* Outputs for Triggered SubSystem: '<S92>/timeToTrigger' incorporates:
   *  TriggerPort: '<S99>/Trigger'
   */
  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->timeToTrigger_Trig_ZCE,
                       (rtu_0));
    if (zcEvent != NO_ZCEVENT) {
      /* Memory: '<S99>/Memory' */
      localB->Memory = localDW->Memory_PreviousInput;

      /* Memory: '<S99>/Memory1' */
      localB->Memory1 = localDW->Memory1_PreviousInput;

      /* MATLAB Function: '<S99>/save the trigger time' */
      localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_ly;

      /* MATLAB Function 'trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/timeToTrigger/save the trigger time': '<S106>:1' */
      /*  make sure this is not a subsequent trigger (we don't want those to */
      /*  update the time to trigger time value - we only want the first one) */
      if (rtu_trialStart != localB->Memory) {
        /* '<S106>:1:4' */
        /* '<S106>:1:5' */
        localB->triggerTime = rtu_t - rtu_trialStart;
      } else {
        /* '<S106>:1:7' */
        localB->triggerTime = localB->Memory1;
      }

      /*  update the trial start time regardless */
      /* '<S106>:1:11' */
      localB->lastStartT = rtu_trialStart;

      /* End of MATLAB Function: '<S99>/save the trigger time' */

      /* Update for Memory: '<S99>/Memory' */
      localDW->Memory_PreviousInput = localB->lastStartT;

      /* Update for Memory: '<S99>/Memory1' */
      localDW->Memory1_PreviousInput = localB->triggerTime;
      localDW->timeToTrigger_SubsysRanBC = 4;
    }
  }

  /* End of Outputs for SubSystem: '<S92>/timeToTrigger' */
}

/*
 * Initial conditions for atomic system:
 *    '<S92>/traj calc'
 *    '<S93>/traj calc'
 */
void FingerEAERCtrl_trajcalc_Init(rtDW_trajcalc_FingerEAERCtrl *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_fy;
  localDW->is_active_c23_FingerEAERCtrl = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S92>/traj calc'
 *    '<S93>/traj calc'
 */
void FingerEAERCtrl_trajcalc(real_T rtu_Pd, real_T rtu_th, real_T rtu_dur,
  real_T rtu_t, real_T rtu_Phold_, real_T rtu_state_, real_T rtu_Pactual_,
  real_T rtu_trajMode, rtB_trajcalc_FingerEAERCtrl *localB,
  rtDW_trajcalc_FingerEAERCtrl *localDW)
{
  real_T startT;
  real_T Pr;
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_fy;

  /* MATLAB Function 'trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/traj calc': '<S100>:1' */
  /*  th is the hit time */
  /*  Pd id the final destination */
  /*  t is the current time */
  /*  dur is the duration  */
  /* '<S100>:1:6' */
  startT = rtu_th - rtu_dur;

  /*  number of miliseconds until the hit time */
  /* '<S100>:1:8' */
  Pr = rtu_Pd - rtu_Phold_;

  /* '<S100>:1:9' */
  localB->Phold = rtu_Phold_;

  /* '<S100>:1:10' */
  localB->state = rtu_state_;
  switch ((int32_T)rtu_state_) {
   case 0:
    /* before movement starts */
    /* des = [Phold_; 0; 0]; */
    /* '<S100>:1:15' */
    localB->des[0] = rtu_Pactual_;
    localB->des[1] = 0.0;
    localB->des[2] = 0.0;
    if (rtu_t > startT) {
      /* '<S100>:1:16' */
      localB->state = 1.0;
    }
    break;

   case 1:
    /* movement period */
    /* '<S100>:1:19' */
    startT = rtu_t - startT;

    /* '<S100>:1:20' */
    localB->des[0] = ((10.0 * Pr * rt_powd_snf(startT, 3.0) / rt_powd_snf
                       (rtu_dur, 3.0) - 15.0 * Pr * rt_powd_snf(startT, 4.0) /
                       rt_powd_snf(rtu_dur, 4.0)) + 6.0 * Pr * rt_powd_snf
                      (startT, 5.0) / rt_powd_snf(rtu_dur, 5.0)) + rtu_Phold_;
    localB->des[1] = (30.0 * Pr * rt_powd_snf(startT, 2.0) / rt_powd_snf(rtu_dur,
      3.0) - 60.0 * Pr * rt_powd_snf(startT, 3.0) / rt_powd_snf(rtu_dur, 4.0)) +
      30.0 * Pr * rt_powd_snf(startT, 4.0) / rt_powd_snf(rtu_dur, 5.0);
    localB->des[2] = (120.0 * Pr * rt_powd_snf(startT, 3.0) / rt_powd_snf
                      (rtu_dur, 5.0) - 180.0 * Pr * rt_powd_snf(startT, 2.0) /
                      rt_powd_snf(rtu_dur, 4.0)) + 60.0 * Pr * startT /
      rt_powd_snf(rtu_dur, 3.0);
    if (rtu_t > rtu_th) {
      /* '<S100>:1:23' */
      localB->state = 2.0;
    }
    break;

   case 2:
    /* movement just finished (set hold position -> goto state 3) */
    /* '<S100>:1:26' */
    localB->Phold = rtu_Pd;

    /* '<S100>:1:27' */
    localB->des[0] = rtu_Pd;
    localB->des[1] = 0.0;
    localB->des[2] = 0.0;

    /* '<S100>:1:28' */
    localB->state = 3.0;
    break;

   case 3:
    /* in between movements          */
    if (rtu_trajMode != 4.0) {
      /* '<S100>:1:31' */
      /* '<S100>:1:32' */
      localB->Phold = rtu_Pactual_;

      /* '<S100>:1:33' */
      localB->des[0] = rtu_Pactual_;
      localB->des[1] = 0.0;
      localB->des[2] = 0.0;
    } else {
      /* '<S100>:1:35' */
      localB->des[0] = rtu_Phold_;
      localB->des[1] = 0.0;
      localB->des[2] = 0.0;
    }

    if (rtu_t < startT) {
      /* '<S100>:1:37' */
      localB->state = 0.0;
    }
    break;

   default:
    /* '<S100>:1:39' */
    localB->state = 0.0;

    /* '<S100>:1:40' */
    localB->Phold = 0.0;

    /* '<S100>:1:41' */
    localB->des[0] = rtu_Phold_;
    localB->des[1] = 0.0;
    localB->des[2] = 0.0;
    break;
  }

  /*  note: des is dsired trajectory: [pDes, vDes, ~] */
}

/*
 * Initial conditions for atomic system:
 *    '<S92>/trigger check'
 *    '<S93>/trigger check'
 */
void FingerEAERCtr_triggercheck_Init(rtDW_triggercheck_FingerEAERCtr *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_po;
  localDW->is_active_c55_FingerEAERCtrl = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S92>/trigger check'
 *    '<S93>/trigger check'
 */
void FingerEAERCtrl_triggercheck(real_T rtu_update, real_T rtu_tDes_, real_T
  rtu_tDesLast_, rtB_triggercheck_FingerEAERCtrl *localB,
  rtDW_triggercheck_FingerEAERCtr *localDW)
{
  localDW->sfEvent = FingerEAERCtrl_CALL_EVENT_po;

  /* MATLAB Function 'trajectory calculator/mode 4: sub init no return/rt minimum jerk trajectory1/trigger check': '<S101>:1' */
  /* if we haven't triggered before, and the force threshold is reading high... */
  if ((rtu_tDes_ != rtu_tDesLast_) && (rtu_update == 1.0)) {
    /* '<S101>:1:4' */
    /* send the trigger and save the trial time  */
    /* '<S101>:1:6' */
    localB->update1 = 1.0;

    /* '<S101>:1:7' */
    localB->tDesLast = rtu_tDes_;
  } else {
    /* send no trigger, and do not update trial time. */
    /* '<S101>:1:10' */
    localB->update1 = 0.0;

    /* '<S101>:1:11' */
    localB->tDesLast = rtu_tDesLast_;
  }
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = -0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

/* Model output function */
void FingerEAERCtrl_output(void)
{
  real_T ctrlW;
  real_T b;
  int32_T i;
  real_T pos_idx;
  real_T pos_idx_0;
  real_T vel_idx;
  real_T vel_idx_0;
  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    /* set solver stop time */
    if (!(FingerEAERCtrl_rtM->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&FingerEAERCtrl_rtM->solverInfo,
                            ((FingerEAERCtrl_rtM->Timing.clockTickH0 + 1) *
        FingerEAERCtrl_rtM->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&FingerEAERCtrl_rtM->solverInfo,
                            ((FingerEAERCtrl_rtM->Timing.clockTick0 + 1) *
        FingerEAERCtrl_rtM->Timing.stepSize0 +
        FingerEAERCtrl_rtM->Timing.clockTickH0 *
        FingerEAERCtrl_rtM->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(FingerEAERCtrl_rtM)) {
    FingerEAERCtrl_rtM->Timing.t[0] = rtsiGetT(&FingerEAERCtrl_rtM->solverInfo);
  }

  /* RTWBLOCK_START_COMMENT */
  /* RTWBLOCK_START_COMMENT */
  /* RTWBLOCK_START_COMMENT */
  /* RTWBLOCK_START_COMMENT */
  /* RTWBLOCK_START_COMMENT */
  /* RTWBLOCK_START_COMMENT */
  /* Reset subsysRan breadcrumbs */
  srClearBC(FingerEAERCtrl_DWork.paramsbuffer.paramsbuffer_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(FingerEAERCtrl_DWork.paramsbuffer_k.paramsbuffer_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(FingerEAERCtrl_DWork.paramsbuffer_o.paramsbuffer_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(FingerEAERCtrl_DWork.forcebuffer.forcebuffer_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(FingerEAERCtrl_DWork.paramsbuffer1.paramsbuffer1_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (FingerEAERCtrl_DWork.saveTrialStartTime.saveTrialStartTime_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(FingerEAERCtrl_DWork.timeToTrigger.timeToTrigger_SubsysRanBC);

  /* Integrator: '<S8>/Integrator' */
  /* RTWBLOCK_START_COMMENT */
  FingerEAERCtrl_B.Integrator[0] = FingerEAERCtrl_X.Integrator_CSTATE[0];
  FingerEAERCtrl_B.Integrator[1] = FingerEAERCtrl_X.Integrator_CSTATE[1];
  FingerEAERCtrl_B.Integrator[2] = FingerEAERCtrl_X.Integrator_CSTATE[2];

  /* Gain: '<S8>/A' */
  for (i = 0; i < 3; i++) {
    FingerEAERCtrl_B.A[i] = 0.0;
    FingerEAERCtrl_B.A[i] += FingerEAERCtrl_P.A_Gain[i] *
      FingerEAERCtrl_B.Integrator[0];
    FingerEAERCtrl_B.A[i] += FingerEAERCtrl_P.A_Gain[i + 3] *
      FingerEAERCtrl_B.Integrator[1];
    FingerEAERCtrl_B.A[i] += FingerEAERCtrl_P.A_Gain[i + 6] *
      FingerEAERCtrl_B.Integrator[2];
  }

  /* End of Gain: '<S8>/A' */
  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    /* Level2 S-Function Block: '<S2>/PCI-6221 AD1' (adnipcim) */
    {
      SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[0];
      sfcnOutputs(rts, 1);
    }

    /* Gain: '<S4>/parLeftMode' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parLeftMode = FingerEAERCtrl_P.parLeftMode_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* Saturate: '<S4>/Saturation' */
    ctrlW = FingerEAERCtrl_B.parLeftMode;
    b = FingerEAERCtrl_P.Saturation_LowerSat;
    pos_idx = FingerEAERCtrl_P.Saturation_UpperSat;
    if (ctrlW >= pos_idx) {
      FingerEAERCtrl_B.Saturation = pos_idx;
    } else if (ctrlW <= b) {
      FingerEAERCtrl_B.Saturation = b;
    } else {
      FingerEAERCtrl_B.Saturation = ctrlW;
    }

    /* End of Saturate: '<S4>/Saturation' */

    /* MATLAB Function: '<S15>/MATLAB Function' */
    FingerEAERCtrl_MATLABFunction(FingerEAERCtrl_B.PCI6221AD1_o1,
      FingerEAERCtrl_B.PCI6221AD1_o3, FingerEAERCtrl_B.Saturation,
      &FingerEAERCtrl_B.sf_MATLABFunction,
      &FingerEAERCtrl_DWork.sf_MATLABFunction);

    /* Gain: '<S8>/B' */
    FingerEAERCtrl_B.B[0] = FingerEAERCtrl_P.B_Gain[0] *
      FingerEAERCtrl_B.sf_MATLABFunction.output1;
    FingerEAERCtrl_B.B[1] = FingerEAERCtrl_P.B_Gain[1] *
      FingerEAERCtrl_B.sf_MATLABFunction.output1;
    FingerEAERCtrl_B.B[2] = FingerEAERCtrl_P.B_Gain[2] *
      FingerEAERCtrl_B.sf_MATLABFunction.output1;

    /* Level2 S-Function Block: '<S2>/PCI 6221 ENC ' (encnipcim) */
    {
      SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[1];
      sfcnOutputs(rts, 1);
    }

    /* Level2 S-Function Block: '<S2>/PCI 6221 ENC 1' (encnipcim) */
    {
      SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[2];
      sfcnOutputs(rts, 1);
    }

    /* MATLAB Function: '<S14>/MATLAB Function' */
    FingerEAERCtrl_MATLABFunction(FingerEAERCtrl_B.PCI6221ENC,
      FingerEAERCtrl_B.PCI6221ENC1, FingerEAERCtrl_B.Saturation,
      &FingerEAERCtrl_B.sf_MATLABFunction_e,
      &FingerEAERCtrl_DWork.sf_MATLABFunction_e);

    /* DigitalClock: '<S17>/Digital Clock' */
    FingerEAERCtrl_B.DigitalClock = FingerEAERCtrl_rtM->Timing.t[1];

    /* Memory: '<S17>/Memory1' */
    FingerEAERCtrl_B.Memory1[0] = FingerEAERCtrl_DWork.Memory1_PreviousInput[0];
    FingerEAERCtrl_B.Memory1[1] = FingerEAERCtrl_DWork.Memory1_PreviousInput[1];

    /* Memory: '<S17>/Memory' */
    FingerEAERCtrl_B.Memory = FingerEAERCtrl_DWork.Memory_PreviousInput;

    /* MATLAB Function: '<S17>/MATLAB Function' */
    FingerEAERCtrl_DWork.sfEvent_p = FingerEAERCtrl_CALL_EVENT_m5;

    /* MATLAB Function 'Robot/get offsets/MATLAB Function': '<S23>:1' */
    /* % remove the position offset that comes from using the encoders for */
    /*  feedback */
    /* % */
    /* '<S23>:1:6' */
    FingerEAERCtrl_B.summedVals[0] = FingerEAERCtrl_B.Memory1[0];
    FingerEAERCtrl_B.summedVals[1] = FingerEAERCtrl_B.Memory1[1];
    if ((FingerEAERCtrl_B.DigitalClock > 2.0) && (FingerEAERCtrl_B.DigitalClock <
         3.0)) {
      /* '<S23>:1:7' */
      /* '<S23>:1:8' */
      FingerEAERCtrl_B.summedVals[0] = FingerEAERCtrl_B.Memory1[0] +
        FingerEAERCtrl_B.sf_MATLABFunction_e.output1;

      /* '<S23>:1:9' */
      FingerEAERCtrl_B.summedVals[1] = FingerEAERCtrl_B.Memory1[1] +
        FingerEAERCtrl_B.sf_MATLABFunction_e.output2;

      /* '<S23>:1:10' */
      FingerEAERCtrl_B.nSamples = FingerEAERCtrl_B.Memory + 1.0;

      /* '<S23>:1:11' */
      FingerEAERCtrl_B.encoder1 = 0.0;

      /* '<S23>:1:12' */
      FingerEAERCtrl_B.encoder2 = 0.0;
    } else if (FingerEAERCtrl_B.DigitalClock >= 3.0) {
      /* '<S23>:1:13' */
      /* '<S23>:1:14' */
      /* '<S23>:1:15' */
      FingerEAERCtrl_B.nSamples = FingerEAERCtrl_B.Memory;

      /* '<S23>:1:16' */
      FingerEAERCtrl_B.encoder1 = FingerEAERCtrl_B.sf_MATLABFunction_e.output1 -
        FingerEAERCtrl_B.Memory1[0] / FingerEAERCtrl_B.Memory;

      /* '<S23>:1:17' */
      FingerEAERCtrl_B.encoder2 = FingerEAERCtrl_B.sf_MATLABFunction_e.output2 -
        FingerEAERCtrl_B.Memory1[1] / FingerEAERCtrl_B.Memory;
    } else {
      /* '<S23>:1:19' */
      /* '<S23>:1:20' */
      FingerEAERCtrl_B.nSamples = FingerEAERCtrl_B.Memory;

      /* '<S23>:1:21' */
      FingerEAERCtrl_B.encoder1 = 0.0;

      /* '<S23>:1:22' */
      FingerEAERCtrl_B.encoder2 = 0.0;
    }

    /* End of MATLAB Function: '<S17>/MATLAB Function' */

    /* Gain: '<S2>/Gain' */
    FingerEAERCtrl_B.Gain = FingerEAERCtrl_P.Gain_Gain *
      FingerEAERCtrl_B.encoder1;

    /* Gain: '<S8>/B1' */
    FingerEAERCtrl_B.B1 = FingerEAERCtrl_P.B1_Gain * FingerEAERCtrl_B.Gain;
  }

  /* Gain: '<S8>/B2' */
  FingerEAERCtrl_B.B2 = FingerEAERCtrl_P.B2_Gain * FingerEAERCtrl_B.Integrator[1];

  /* Gain: '<S8>/B3' */
  FingerEAERCtrl_B.B3 = FingerEAERCtrl_P.B3_Gain * FingerEAERCtrl_B.Integrator[2];

  /* Gain: '<S8>/C' */
  ctrlW = FingerEAERCtrl_P.C_Gain[0] * FingerEAERCtrl_B.Integrator[0];
  ctrlW += FingerEAERCtrl_P.C_Gain[1] * FingerEAERCtrl_B.Integrator[1];
  ctrlW += FingerEAERCtrl_P.C_Gain[2] * FingerEAERCtrl_B.Integrator[2];
  FingerEAERCtrl_B.C = ctrlW;
  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    /* SampleTimeMath: '<S10>/TSamp'
     *
     * About '<S10>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    FingerEAERCtrl_B.TSamp = FingerEAERCtrl_B.Gain * FingerEAERCtrl_P.TSamp_WtEt;

    /* UnitDelay: '<S10>/UD' */
    FingerEAERCtrl_B.Uk1 = FingerEAERCtrl_DWork.UD_DSTATE;

    /* Sum: '<S10>/Diff' */
    FingerEAERCtrl_B.Diff = FingerEAERCtrl_B.TSamp - FingerEAERCtrl_B.Uk1;
  }

  /* Sum: '<S8>/Sum2' */
  FingerEAERCtrl_B.Sum2 = FingerEAERCtrl_B.B1 - FingerEAERCtrl_B.C;

  /* Gain: '<S8>/K' */
  FingerEAERCtrl_B.K[0] = FingerEAERCtrl_P.K_Gain[0] * FingerEAERCtrl_B.Sum2;
  FingerEAERCtrl_B.K[1] = FingerEAERCtrl_P.K_Gain[1] * FingerEAERCtrl_B.Sum2;
  FingerEAERCtrl_B.K[2] = FingerEAERCtrl_P.K_Gain[2] * FingerEAERCtrl_B.Sum2;

  /* Sum: '<S8>/Sum3' */
  FingerEAERCtrl_B.Sum3[0] = FingerEAERCtrl_B.B[0] + FingerEAERCtrl_B.K[0];
  FingerEAERCtrl_B.Sum3[1] = FingerEAERCtrl_B.B[1] + FingerEAERCtrl_B.K[1];
  FingerEAERCtrl_B.Sum3[2] = FingerEAERCtrl_B.B[2] + FingerEAERCtrl_B.K[2];

  /* Sum: '<S8>/Sum4' */
  FingerEAERCtrl_B.Sum4[0] = FingerEAERCtrl_B.Sum3[0] + FingerEAERCtrl_B.A[0];
  FingerEAERCtrl_B.Sum4[1] = FingerEAERCtrl_B.Sum3[1] + FingerEAERCtrl_B.A[1];
  FingerEAERCtrl_B.Sum4[2] = FingerEAERCtrl_B.Sum3[2] + FingerEAERCtrl_B.A[2];

  /* Integrator: '<S9>/Integrator' */
  FingerEAERCtrl_B.Integrator_a[0] = FingerEAERCtrl_X.Integrator_CSTATE_h[0];
  FingerEAERCtrl_B.Integrator_a[1] = FingerEAERCtrl_X.Integrator_CSTATE_h[1];
  FingerEAERCtrl_B.Integrator_a[2] = FingerEAERCtrl_X.Integrator_CSTATE_h[2];

  /* Gain: '<S9>/A' */
  for (i = 0; i < 3; i++) {
    FingerEAERCtrl_B.A_o[i] = 0.0;
    FingerEAERCtrl_B.A_o[i] += FingerEAERCtrl_P.A_Gain_l[i] *
      FingerEAERCtrl_B.Integrator_a[0];
    FingerEAERCtrl_B.A_o[i] += FingerEAERCtrl_P.A_Gain_l[i + 3] *
      FingerEAERCtrl_B.Integrator_a[1];
    FingerEAERCtrl_B.A_o[i] += FingerEAERCtrl_P.A_Gain_l[i + 6] *
      FingerEAERCtrl_B.Integrator_a[2];
  }

  /* End of Gain: '<S9>/A' */
  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    /* Gain: '<S9>/B' */
    FingerEAERCtrl_B.B_d[0] = FingerEAERCtrl_P.B_Gain_f[0] *
      FingerEAERCtrl_B.sf_MATLABFunction.output2;
    FingerEAERCtrl_B.B_d[1] = FingerEAERCtrl_P.B_Gain_f[1] *
      FingerEAERCtrl_B.sf_MATLABFunction.output2;
    FingerEAERCtrl_B.B_d[2] = FingerEAERCtrl_P.B_Gain_f[2] *
      FingerEAERCtrl_B.sf_MATLABFunction.output2;

    /* Gain: '<S2>/Gain1' */
    FingerEAERCtrl_B.Gain1 = FingerEAERCtrl_P.Gain1_Gain *
      FingerEAERCtrl_B.encoder2;

    /* Gain: '<S9>/B1' */
    FingerEAERCtrl_B.B1_o = FingerEAERCtrl_P.B1_Gain_n * FingerEAERCtrl_B.Gain1;
  }

  /* Gain: '<S9>/B2' */
  FingerEAERCtrl_B.B2_o = FingerEAERCtrl_P.B2_Gain_e *
    FingerEAERCtrl_B.Integrator_a[1];

  /* Gain: '<S9>/B3' */
  FingerEAERCtrl_B.B3_l = FingerEAERCtrl_P.B3_Gain_g *
    FingerEAERCtrl_B.Integrator_a[2];

  /* Gain: '<S9>/C' */
  ctrlW = FingerEAERCtrl_P.C_Gain_h[0] * FingerEAERCtrl_B.Integrator_a[0];
  ctrlW += FingerEAERCtrl_P.C_Gain_h[1] * FingerEAERCtrl_B.Integrator_a[1];
  ctrlW += FingerEAERCtrl_P.C_Gain_h[2] * FingerEAERCtrl_B.Integrator_a[2];
  FingerEAERCtrl_B.C_m = ctrlW;
  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    /* SampleTimeMath: '<S11>/TSamp'
     *
     * About '<S11>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    FingerEAERCtrl_B.TSamp_l = FingerEAERCtrl_B.Gain1 *
      FingerEAERCtrl_P.TSamp_WtEt_p;

    /* UnitDelay: '<S11>/UD' */
    FingerEAERCtrl_B.Uk1_c = FingerEAERCtrl_DWork.UD_DSTATE_h;

    /* Sum: '<S11>/Diff' */
    FingerEAERCtrl_B.Diff_a = FingerEAERCtrl_B.TSamp_l - FingerEAERCtrl_B.Uk1_c;
  }

  /* Sum: '<S9>/Sum2' */
  FingerEAERCtrl_B.Sum2_j = FingerEAERCtrl_B.B1_o - FingerEAERCtrl_B.C_m;

  /* Gain: '<S9>/K' */
  FingerEAERCtrl_B.K_d[0] = FingerEAERCtrl_P.K_Gain_n[0] *
    FingerEAERCtrl_B.Sum2_j;
  FingerEAERCtrl_B.K_d[1] = FingerEAERCtrl_P.K_Gain_n[1] *
    FingerEAERCtrl_B.Sum2_j;
  FingerEAERCtrl_B.K_d[2] = FingerEAERCtrl_P.K_Gain_n[2] *
    FingerEAERCtrl_B.Sum2_j;

  /* Sum: '<S9>/Sum3' */
  FingerEAERCtrl_B.Sum3_j[0] = FingerEAERCtrl_B.B_d[0] + FingerEAERCtrl_B.K_d[0];
  FingerEAERCtrl_B.Sum3_j[1] = FingerEAERCtrl_B.B_d[1] + FingerEAERCtrl_B.K_d[1];
  FingerEAERCtrl_B.Sum3_j[2] = FingerEAERCtrl_B.B_d[2] + FingerEAERCtrl_B.K_d[2];

  /* Sum: '<S9>/Sum4' */
  FingerEAERCtrl_B.Sum4_l[0] = FingerEAERCtrl_B.Sum3_j[0] +
    FingerEAERCtrl_B.A_o[0];
  FingerEAERCtrl_B.Sum4_l[1] = FingerEAERCtrl_B.Sum3_j[1] +
    FingerEAERCtrl_B.A_o[1];
  FingerEAERCtrl_B.Sum4_l[2] = FingerEAERCtrl_B.Sum3_j[2] +
    FingerEAERCtrl_B.A_o[2];
  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    /* ok to acquire for <S24>/S-Function */
    FingerEAERCtrl_DWork.SFunction_IWORK.AcquireOK = 1;

    /* Sum: '<S18>/Sum' incorporates:
     *  Constant: '<S18>/Constant'
     */
    FingerEAERCtrl_B.Sum = FingerEAERCtrl_B.PCI6221AD1_o2 -
      FingerEAERCtrl_P.Constant_Value;

    /* Gain: '<S18>/gain' */
    FingerEAERCtrl_B.gain = FingerEAERCtrl_P.gain_Gain * FingerEAERCtrl_B.Sum;

    /* SignalConversion: '<S20>/TmpSignal ConversionAt SFunction Inport1' incorporates:
     *  MATLAB Function: '<S13>/MATLAB Function'
     */
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[0] =
      FingerEAERCtrl_B.PCI6221AD1_o4;
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[1] =
      FingerEAERCtrl_B.PCI6221AD1_o5;
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[2] =
      FingerEAERCtrl_B.PCI6221AD1_o6;
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[3] =
      FingerEAERCtrl_B.PCI6221AD1_o7;
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[4] =
      FingerEAERCtrl_B.PCI6221AD1_o8;

    /* MATLAB Function: '<S13>/MATLAB Function' */
    FingerEAERCtrl_DWork.sfEvent_a = FingerEAERCtrl_CALL_EVENT_m5;

    /* MATLAB Function 'Robot/account for handedness force/MATLAB Function': '<S20>:1' */
    /*  channel1 - gold tip */
    /*  channel2 - blue tip */
    /*  channel3 - gold base */
    /*  channel4 - blue base */
    /*  we wallways want the index finger to be finger 1 */
    if (FingerEAERCtrl_B.Saturation == 1.0) {
      /* '<S20>:1:10' */
      /* '<S20>:1:11' */
      FingerEAERCtrl_B.output[0] =
        FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[3];
      FingerEAERCtrl_B.output[1] =
        FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[1];
      FingerEAERCtrl_B.output[2] =
        FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[2];
      FingerEAERCtrl_B.output[3] =
        FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[0];
      FingerEAERCtrl_B.output[4] =
        FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[4];
    } else {
      /* '<S20>:1:13' */
      FingerEAERCtrl_B.output[0] =
        FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[2];
      FingerEAERCtrl_B.output[1] =
        FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[0];
      FingerEAERCtrl_B.output[2] =
        FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[3];
      FingerEAERCtrl_B.output[3] =
        FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[1];
      FingerEAERCtrl_B.output[4] =
        FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_g[4];

      /* output = [inp1(3,1); inp1(4,2); inp1(5)]; */
    }

    /* Gain: '<S4>/parChangeRate' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parChangeRate = FingerEAERCtrl_P.parChangeRate_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* Saturate: '<S3>/Saturation' incorporates:
     *  Constant: '<Root>/Force On'
     */
    ctrlW = FingerEAERCtrl_P.ForceOn_Value;
    b = FingerEAERCtrl_P.Saturation_LowerSat_o;
    pos_idx = FingerEAERCtrl_P.Saturation_UpperSat_f;
    if (ctrlW >= pos_idx) {
      FingerEAERCtrl_B.Saturation_m = pos_idx;
    } else if (ctrlW <= b) {
      FingerEAERCtrl_B.Saturation_m = b;
    } else {
      FingerEAERCtrl_B.Saturation_m = ctrlW;
    }

    /* End of Saturate: '<S3>/Saturation' */

    /* Memory: '<S26>/Memory' */
    FingerEAERCtrl_B.Memory_c[0] = FingerEAERCtrl_DWork.Memory_PreviousInput_i[0];
    FingerEAERCtrl_B.Memory_c[1] = FingerEAERCtrl_DWork.Memory_PreviousInput_i[1];
    FingerEAERCtrl_B.Memory_c[2] = FingerEAERCtrl_DWork.Memory_PreviousInput_i[2];
    FingerEAERCtrl_B.Memory_c[3] = FingerEAERCtrl_DWork.Memory_PreviousInput_i[3];

    /* MATLAB Function: '<S26>/gainramp' */
    FingerEAERCtrl_gainramp(FingerEAERCtrl_B.parChangeRate,
      FingerEAERCtrl_B.Saturation_m, FingerEAERCtrl_B.Memory_c,
      &FingerEAERCtrl_B.sf_gainramp, &FingerEAERCtrl_DWork.sf_gainramp);

    /* Gain: '<S4>/parTrajMode' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parTrajMode = FingerEAERCtrl_P.parTrajMode_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* Rounding: '<S4>/Rounding Function' */
    FingerEAERCtrl_B.RoundingFunction = rt_roundd_snf
      (FingerEAERCtrl_B.parTrajMode);

    /* Saturate: '<S4>/Saturation1' */
    ctrlW = FingerEAERCtrl_B.RoundingFunction;
    b = FingerEAERCtrl_P.Saturation1_LowerSat;
    pos_idx = FingerEAERCtrl_P.Saturation1_UpperSat;
    if (ctrlW >= pos_idx) {
      FingerEAERCtrl_B.Saturation1 = pos_idx;
    } else if (ctrlW <= b) {
      FingerEAERCtrl_B.Saturation1 = b;
    } else {
      FingerEAERCtrl_B.Saturation1 = ctrlW;
    }

    /* End of Saturate: '<S4>/Saturation1' */

    /* Gain: '<S7>/parP1Des' incorporates:
     *  Constant: '<S7>/unity_traj'
     */
    FingerEAERCtrl_B.parP1Des = FingerEAERCtrl_P.parP1Des_Gain *
      FingerEAERCtrl_P.unity_traj_Value;

    /* Gain: '<S7>/parTHit1' incorporates:
     *  Constant: '<S7>/unity_traj'
     */
    FingerEAERCtrl_B.parTHit1 = FingerEAERCtrl_P.parTHit1_Gain *
      FingerEAERCtrl_P.unity_traj_Value;

    /* DigitalClock: '<S5>/Digital Clock' */
    FingerEAERCtrl_B.DigitalClock_f = FingerEAERCtrl_rtM->Timing.t[1];

    /* Gain: '<S5>/sigTargetTime' */
    FingerEAERCtrl_B.sigTargetTime = FingerEAERCtrl_P.sigTargetTime_Gain *
      FingerEAERCtrl_B.DigitalClock_f;

    /* Gain: '<S4>/parVThresh' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parVThresh = FingerEAERCtrl_P.parVThresh_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* Memory: '<S55>/Memory' */
    FingerEAERCtrl_B.Memory_e = FingerEAERCtrl_DWork.Memory_PreviousInput_k;

    /* Gain: '<S4>/parMaxTrajDur' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parMaxTrajDur = FingerEAERCtrl_P.parMaxTrajDur_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* MATLAB Function: '<S55>/detect movement onset' */
    FingerEAERC_detectmovementonset(FingerEAERCtrl_B.Diff,
      FingerEAERCtrl_B.parVThresh, FingerEAERCtrl_B.parTHit1,
      FingerEAERCtrl_B.sigTargetTime, FingerEAERCtrl_B.Memory_e,
      FingerEAERCtrl_B.parMaxTrajDur, &FingerEAERCtrl_B.sf_detectmovementonset,
      &FingerEAERCtrl_DWork.sf_detectmovementonset);

    /* Memory: '<S16>/Memory' */
    FingerEAERCtrl_B.Memory_n = FingerEAERCtrl_DWork.Memory_PreviousInput_l;

    /* Product: '<S54>/Product' incorporates:
     *  Constant: '<S54>/Constant'
     */
    FingerEAERCtrl_B.Product = FingerEAERCtrl_B.Memory_n *
      FingerEAERCtrl_P.Constant_Value_c;

    /* Gain: '<S4>/parFThresh' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parFThresh = FingerEAERCtrl_P.parFThresh_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* MATLAB Function: '<S55>/detect force onset' */
    FingerEAERCtrl_detectforceonset(FingerEAERCtrl_B.Product,
      FingerEAERCtrl_B.parFThresh, FingerEAERCtrl_B.parTHit1,
      FingerEAERCtrl_B.sigTargetTime, FingerEAERCtrl_B.Memory_e,
      FingerEAERCtrl_B.parMaxTrajDur, &FingerEAERCtrl_B.sf_detectforceonset,
      &FingerEAERCtrl_DWork.sf_detectforceonset);

    /* Logic: '<S55>/Logical Operator' */
    FingerEAERCtrl_B.LogicalOperator =
      ((FingerEAERCtrl_B.sf_detectmovementonset.update != 0.0) ||
       (FingerEAERCtrl_B.sf_detectforceonset.update != 0.0));

    /* Outputs for Triggered SubSystem: '<S55>/params buffer' */
    FingerEAERCtrl_paramsbuffer(FingerEAERCtrl_B.LogicalOperator,
      FingerEAERCtrl_B.parP1Des, FingerEAERCtrl_B.parTHit1,
      FingerEAERCtrl_B.sigTargetTime, FingerEAERCtrl_rtM,
      &FingerEAERCtrl_B.paramsbuffer, &FingerEAERCtrl_DWork.paramsbuffer,
      &FingerEAERCtrl_PrevZCSigState.paramsbuffer);

    /* End of Outputs for SubSystem: '<S55>/params buffer' */

    /* MATLAB Function: '<S55>/MATLAB Function' */
    FingerEAERCtrl_MATLABFunction_g(FingerEAERCtrl_B.paramsbuffer.pDes,
      FingerEAERCtrl_B.paramsbuffer.tHit, FingerEAERCtrl_B.paramsbuffer.dur,
      FingerEAERCtrl_B.sigTargetTime, &FingerEAERCtrl_B.sf_MATLABFunction_g,
      &FingerEAERCtrl_DWork.sf_MATLABFunction_g);

    /* Gain: '<S7>/parP2Des' incorporates:
     *  Constant: '<S7>/unity_traj'
     */
    FingerEAERCtrl_B.parP2Des = FingerEAERCtrl_P.parP2Des_Gain *
      FingerEAERCtrl_P.unity_traj_Value;

    /* Gain: '<S7>/parTHit2' incorporates:
     *  Constant: '<S7>/unity_traj'
     */
    FingerEAERCtrl_B.parTHit2 = FingerEAERCtrl_P.parTHit2_Gain *
      FingerEAERCtrl_P.unity_traj_Value;

    /* Memory: '<S56>/Memory' */
    FingerEAERCtrl_B.Memory_c1 = FingerEAERCtrl_DWork.Memory_PreviousInput_k0;

    /* MATLAB Function: '<S56>/detect movement onset' */
    FingerEAERC_detectmovementonset(FingerEAERCtrl_B.Diff_a,
      FingerEAERCtrl_B.parVThresh, FingerEAERCtrl_B.parTHit2,
      FingerEAERCtrl_B.sigTargetTime, FingerEAERCtrl_B.Memory_c1,
      FingerEAERCtrl_B.parMaxTrajDur, &FingerEAERCtrl_B.sf_detectmovementonset_m,
      &FingerEAERCtrl_DWork.sf_detectmovementonset_m);

    /* Memory: '<S16>/Memory1' */
    FingerEAERCtrl_B.Memory1_j = FingerEAERCtrl_DWork.Memory1_PreviousInput_d;

    /* Product: '<S54>/Product1' incorporates:
     *  Constant: '<S54>/Constant'
     */
    FingerEAERCtrl_B.Product1 = FingerEAERCtrl_B.Memory1_j *
      FingerEAERCtrl_P.Constant_Value_c;

    /* MATLAB Function: '<S56>/detect force onset' */
    FingerEAERCtrl_detectforceonset(FingerEAERCtrl_B.Product1,
      FingerEAERCtrl_B.parFThresh, FingerEAERCtrl_B.parTHit2,
      FingerEAERCtrl_B.sigTargetTime, FingerEAERCtrl_B.Memory_c1,
      FingerEAERCtrl_B.parMaxTrajDur, &FingerEAERCtrl_B.sf_detectforceonset_m,
      &FingerEAERCtrl_DWork.sf_detectforceonset_m);

    /* Logic: '<S56>/Logical Operator' */
    FingerEAERCtrl_B.LogicalOperator_a =
      ((FingerEAERCtrl_B.sf_detectmovementonset_m.update != 0.0) ||
       (FingerEAERCtrl_B.sf_detectforceonset_m.update != 0.0));

    /* Outputs for Triggered SubSystem: '<S56>/params buffer' */
    FingerEAERCtrl_paramsbuffer(FingerEAERCtrl_B.LogicalOperator_a,
      FingerEAERCtrl_B.parP2Des, FingerEAERCtrl_B.parTHit2,
      FingerEAERCtrl_B.sigTargetTime, FingerEAERCtrl_rtM,
      &FingerEAERCtrl_B.paramsbuffer_b, &FingerEAERCtrl_DWork.paramsbuffer_b,
      &FingerEAERCtrl_PrevZCSigState.paramsbuffer_b);

    /* End of Outputs for SubSystem: '<S56>/params buffer' */

    /* MATLAB Function: '<S56>/MATLAB Function' */
    FingerEAERCtrl_MATLABFunction_g(FingerEAERCtrl_B.paramsbuffer_b.pDes,
      FingerEAERCtrl_B.paramsbuffer_b.tHit, FingerEAERCtrl_B.paramsbuffer_b.dur,
      FingerEAERCtrl_B.sigTargetTime, &FingerEAERCtrl_B.sf_MATLABFunction_p,
      &FingerEAERCtrl_DWork.sf_MATLABFunction_p);

    /* Gain: '<S4>/parFixedDur' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parFixedDur = FingerEAERCtrl_P.parFixedDur_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* Saturate: '<S4>/Saturation2' */
    ctrlW = FingerEAERCtrl_B.parFixedDur;
    b = FingerEAERCtrl_P.Saturation2_LowerSat;
    pos_idx = FingerEAERCtrl_P.Saturation2_UpperSat;
    if (ctrlW >= pos_idx) {
      FingerEAERCtrl_B.Saturation2 = pos_idx;
    } else if (ctrlW <= b) {
      FingerEAERCtrl_B.Saturation2 = b;
    } else {
      FingerEAERCtrl_B.Saturation2 = ctrlW;
    }

    /* End of Saturate: '<S4>/Saturation2' */

    /* Memory: '<S70>/Memory1' */
    FingerEAERCtrl_B.Memory1_i = FingerEAERCtrl_DWork.Memory1_PreviousInput_h;

    /* MATLAB Function: '<S70>/MATLAB Function1' */
    FingerEAERCtrl_MATLABFunction1(FingerEAERCtrl_B.parTHit1,
      FingerEAERCtrl_B.Memory1_i, &FingerEAERCtrl_B.sf_MATLABFunction1,
      &FingerEAERCtrl_DWork.sf_MATLABFunction1);

    /* Outputs for Triggered SubSystem: '<S67>/params buffer' */
    FingerEAERCtrl_paramsbuffer_k(FingerEAERCtrl_B.sf_MATLABFunction1.change,
      FingerEAERCtrl_B.Saturation2, FingerEAERCtrl_B.parP1Des,
      FingerEAERCtrl_B.Gain, FingerEAERCtrl_B.parTHit1, FingerEAERCtrl_rtM,
      &FingerEAERCtrl_B.paramsbuffer_k, &FingerEAERCtrl_DWork.paramsbuffer_k,
      &FingerEAERCtrl_PrevZCSigState.paramsbuffer_k);

    /* End of Outputs for SubSystem: '<S67>/params buffer' */

    /* MATLAB Function: '<S67>/MATLAB Function' */
    FingerEAERCtrl_MATLABFunction_m(FingerEAERCtrl_B.paramsbuffer_k.pDes,
      FingerEAERCtrl_B.paramsbuffer_k.pos, FingerEAERCtrl_B.paramsbuffer_k.tHit,
      FingerEAERCtrl_B.paramsbuffer_k.fixedDur, FingerEAERCtrl_B.sigTargetTime,
      &FingerEAERCtrl_B.sf_MATLABFunction_mh,
      &FingerEAERCtrl_DWork.sf_MATLABFunction_mh);

    /* Memory: '<S75>/Memory1' */
    FingerEAERCtrl_B.Memory1_o = FingerEAERCtrl_DWork.Memory1_PreviousInput_e;

    /* MATLAB Function: '<S75>/MATLAB Function1' */
    FingerEAERCtrl_MATLABFunction1(FingerEAERCtrl_B.parTHit2,
      FingerEAERCtrl_B.Memory1_o, &FingerEAERCtrl_B.sf_MATLABFunction1_m,
      &FingerEAERCtrl_DWork.sf_MATLABFunction1_m);

    /* Outputs for Triggered SubSystem: '<S68>/params buffer' */
    FingerEAERCtrl_paramsbuffer_k(FingerEAERCtrl_B.sf_MATLABFunction1_m.change,
      FingerEAERCtrl_B.Saturation2, FingerEAERCtrl_B.parP2Des,
      FingerEAERCtrl_B.Gain1, FingerEAERCtrl_B.parTHit2, FingerEAERCtrl_rtM,
      &FingerEAERCtrl_B.paramsbuffer_i, &FingerEAERCtrl_DWork.paramsbuffer_i,
      &FingerEAERCtrl_PrevZCSigState.paramsbuffer_i);

    /* End of Outputs for SubSystem: '<S68>/params buffer' */

    /* MATLAB Function: '<S68>/MATLAB Function' */
    FingerEAERCtrl_MATLABFunction_m(FingerEAERCtrl_B.paramsbuffer_i.pDes,
      FingerEAERCtrl_B.paramsbuffer_i.pos, FingerEAERCtrl_B.paramsbuffer_i.tHit,
      FingerEAERCtrl_B.paramsbuffer_i.fixedDur, FingerEAERCtrl_B.sigTargetTime,
      &FingerEAERCtrl_B.sf_MATLABFunction_i,
      &FingerEAERCtrl_DWork.sf_MATLABFunction_i);

    /* Memory: '<S82>/Memory1' */
    FingerEAERCtrl_B.Memory1_e = FingerEAERCtrl_DWork.Memory1_PreviousInput_l;

    /* MATLAB Function: '<S82>/MATLAB Function1' */
    FingerEAERCtrl_MATLABFunction1(FingerEAERCtrl_B.sigTargetTime,
      FingerEAERCtrl_B.Memory1_e, &FingerEAERCtrl_B.sf_MATLABFunction1_g,
      &FingerEAERCtrl_DWork.sf_MATLABFunction1_g);

    /* Outputs for Triggered SubSystem: '<S79>/params buffer' */
    FingerEAERCtrl_paramsbuffer_o(FingerEAERCtrl_B.sf_MATLABFunction1_g.change,
      FingerEAERCtrl_B.Saturation2, FingerEAERCtrl_B.parP1Des,
      FingerEAERCtrl_B.parTHit1, FingerEAERCtrl_rtM,
      &FingerEAERCtrl_B.paramsbuffer_o, &FingerEAERCtrl_DWork.paramsbuffer_o,
      &FingerEAERCtrl_PrevZCSigState.paramsbuffer_o);

    /* End of Outputs for SubSystem: '<S79>/params buffer' */

    /* Memory: '<S79>/Memory' */
    FingerEAERCtrl_B.Memory_ch = FingerEAERCtrl_DWork.Memory_PreviousInput_h;

    /* Memory: '<S79>/Memory1' */
    FingerEAERCtrl_B.Memory1_c = FingerEAERCtrl_DWork.Memory1_PreviousInput_ld;

    /* MATLAB Function: '<S79>/MATLAB Function' */
    FingerEAERCtrl_MATLABFunction_c(FingerEAERCtrl_B.paramsbuffer_o.pDes,
      FingerEAERCtrl_B.paramsbuffer_o.tHit,
      FingerEAERCtrl_B.paramsbuffer_o.fixedDur, FingerEAERCtrl_B.sigTargetTime,
      FingerEAERCtrl_B.Memory_ch, FingerEAERCtrl_B.Memory1_c,
      FingerEAERCtrl_B.Gain, &FingerEAERCtrl_B.sf_MATLABFunction_c,
      &FingerEAERCtrl_DWork.sf_MATLABFunction_c);

    /* Memory: '<S87>/Memory1' */
    FingerEAERCtrl_B.Memory1_n = FingerEAERCtrl_DWork.Memory1_PreviousInput_f;

    /* MATLAB Function: '<S87>/MATLAB Function1' */
    FingerEAERCtrl_MATLABFunction1(FingerEAERCtrl_B.sigTargetTime,
      FingerEAERCtrl_B.Memory1_n, &FingerEAERCtrl_B.sf_MATLABFunction1_h,
      &FingerEAERCtrl_DWork.sf_MATLABFunction1_h);

    /* Outputs for Triggered SubSystem: '<S80>/params buffer' */
    FingerEAERCtrl_paramsbuffer_o(FingerEAERCtrl_B.sf_MATLABFunction1_h.change,
      FingerEAERCtrl_B.Saturation2, FingerEAERCtrl_B.parP2Des,
      FingerEAERCtrl_B.parTHit2, FingerEAERCtrl_rtM,
      &FingerEAERCtrl_B.paramsbuffer_a, &FingerEAERCtrl_DWork.paramsbuffer_a,
      &FingerEAERCtrl_PrevZCSigState.paramsbuffer_a);

    /* End of Outputs for SubSystem: '<S80>/params buffer' */

    /* Memory: '<S80>/Memory' */
    FingerEAERCtrl_B.Memory_p = FingerEAERCtrl_DWork.Memory_PreviousInput_la;

    /* Memory: '<S80>/Memory1' */
    FingerEAERCtrl_B.Memory1_m = FingerEAERCtrl_DWork.Memory1_PreviousInput_hw;

    /* MATLAB Function: '<S80>/MATLAB Function' */
    FingerEAERCtrl_MATLABFunction_c(FingerEAERCtrl_B.paramsbuffer_a.pDes,
      FingerEAERCtrl_B.paramsbuffer_a.tHit,
      FingerEAERCtrl_B.paramsbuffer_a.fixedDur, FingerEAERCtrl_B.sigTargetTime,
      FingerEAERCtrl_B.Memory_p, FingerEAERCtrl_B.Memory1_m,
      FingerEAERCtrl_B.Gain1, &FingerEAERCtrl_B.sf_MATLABFunction_j,
      &FingerEAERCtrl_DWork.sf_MATLABFunction_j);

    /* Product: '<S91>/Product' incorporates:
     *  Constant: '<S91>/Constant'
     */
    FingerEAERCtrl_B.Product_b = FingerEAERCtrl_B.Memory_n *
      FingerEAERCtrl_P.Constant_Value_j;

    /* Gain: '<S92>/Gain' */
    FingerEAERCtrl_B.Gain_g = FingerEAERCtrl_P.Gain_Gain_b *
      FingerEAERCtrl_B.Product_b;

    /* Memory: '<S95>/Memory2' */
    FingerEAERCtrl_B.Memory2 = FingerEAERCtrl_DWork.Memory2_PreviousInput;

    /* MATLAB Function: '<S95>/MATLAB Function1' */
    FingerEAERCtr_MATLABFunction1_k(FingerEAERCtrl_B.parTHit1,
      FingerEAERCtrl_B.Memory2, &FingerEAERCtrl_B.sf_MATLABFunction1_k,
      &FingerEAERCtrl_DWork.sf_MATLABFunction1_k);

    /* Outputs for Triggered SubSystem: '<S92>/force buffer' */
    FingerEAERCtrl_forcebuffer(FingerEAERCtrl_B.sf_MATLABFunction1_k.change,
      FingerEAERCtrl_B.Gain_g, FingerEAERCtrl_rtM, &FingerEAERCtrl_B.forcebuffer,
      &FingerEAERCtrl_DWork.forcebuffer,
      &FingerEAERCtrl_PrevZCSigState.forcebuffer);

    /* End of Outputs for SubSystem: '<S92>/force buffer' */

    /* MATLAB Function: '<S92>/detect force onset1' */
    FingerEAERCtr_detectforceonset1(FingerEAERCtrl_B.parP1Des,
      FingerEAERCtrl_B.Gain_g, FingerEAERCtrl_B.parFThresh,
      FingerEAERCtrl_B.parTHit1, FingerEAERCtrl_B.sigTargetTime,
      FingerEAERCtrl_B.forcebuffer.force, &FingerEAERCtrl_B.sf_detectforceonset1,
      &FingerEAERCtrl_DWork.sf_detectforceonset1);

    /* Memory: '<S92>/tDesMem' */
    FingerEAERCtrl_B.tDesMem = FingerEAERCtrl_DWork.tDesMem_PreviousInput;

    /* MATLAB Function: '<S92>/trigger check' */
    FingerEAERCtrl_triggercheck(FingerEAERCtrl_B.sf_detectforceonset1.update,
      FingerEAERCtrl_B.sf_detectforceonset1.tDes, FingerEAERCtrl_B.tDesMem,
      &FingerEAERCtrl_B.sf_triggercheck, &FingerEAERCtrl_DWork.sf_triggercheck);

    /* Outputs for Triggered SubSystem: '<S92>/params buffer1' */
    FingerEAERCtrl_paramsbuffer1(FingerEAERCtrl_B.sf_triggercheck.update1,
      FingerEAERCtrl_B.parP1Des, FingerEAERCtrl_B.parTHit1,
      FingerEAERCtrl_B.Saturation2, FingerEAERCtrl_B.sigTargetTime,
      FingerEAERCtrl_rtM, &FingerEAERCtrl_B.paramsbuffer1,
      &FingerEAERCtrl_DWork.paramsbuffer1,
      &FingerEAERCtrl_PrevZCSigState.paramsbuffer1);

    /* End of Outputs for SubSystem: '<S92>/params buffer1' */

    /* Memory: '<S92>/pholdMem' */
    FingerEAERCtrl_B.pholdMem = FingerEAERCtrl_DWork.pholdMem_PreviousInput;

    /* Memory: '<S92>/stateMem' */
    FingerEAERCtrl_B.stateMem = FingerEAERCtrl_DWork.stateMem_PreviousInput;

    /* MATLAB Function: '<S92>/traj calc' */
    FingerEAERCtrl_trajcalc(FingerEAERCtrl_B.paramsbuffer1.pDes,
      FingerEAERCtrl_B.paramsbuffer1.tHit, FingerEAERCtrl_B.paramsbuffer1.dur,
      FingerEAERCtrl_B.sigTargetTime, FingerEAERCtrl_B.pholdMem,
      FingerEAERCtrl_B.stateMem, FingerEAERCtrl_B.Gain,
      FingerEAERCtrl_B.Saturation1, &FingerEAERCtrl_B.sf_trajcalc,
      &FingerEAERCtrl_DWork.sf_trajcalc);

    /* Product: '<S91>/Product1' incorporates:
     *  Constant: '<S91>/Constant'
     */
    FingerEAERCtrl_B.Product1_l = FingerEAERCtrl_B.Memory1_j *
      FingerEAERCtrl_P.Constant_Value_j;

    /* Gain: '<S93>/Gain' */
    FingerEAERCtrl_B.Gain_c = FingerEAERCtrl_P.Gain_Gain_p *
      FingerEAERCtrl_B.Product1_l;

    /* Memory: '<S108>/Memory2' */
    FingerEAERCtrl_B.Memory2_d = FingerEAERCtrl_DWork.Memory2_PreviousInput_o;

    /* MATLAB Function: '<S108>/MATLAB Function1' */
    FingerEAERCtr_MATLABFunction1_k(FingerEAERCtrl_B.parTHit2,
      FingerEAERCtrl_B.Memory2_d, &FingerEAERCtrl_B.sf_MATLABFunction1_l,
      &FingerEAERCtrl_DWork.sf_MATLABFunction1_l);

    /* Outputs for Triggered SubSystem: '<S93>/force buffer' */
    FingerEAERCtrl_forcebuffer(FingerEAERCtrl_B.sf_MATLABFunction1_l.change,
      FingerEAERCtrl_B.Gain_c, FingerEAERCtrl_rtM,
      &FingerEAERCtrl_B.forcebuffer_c, &FingerEAERCtrl_DWork.forcebuffer_c,
      &FingerEAERCtrl_PrevZCSigState.forcebuffer_c);

    /* End of Outputs for SubSystem: '<S93>/force buffer' */

    /* MATLAB Function: '<S93>/detect force onset1' */
    FingerEAERCtr_detectforceonset1(FingerEAERCtrl_B.parP2Des,
      FingerEAERCtrl_B.Gain_c, FingerEAERCtrl_B.parFThresh,
      FingerEAERCtrl_B.parTHit2, FingerEAERCtrl_B.sigTargetTime,
      FingerEAERCtrl_B.forcebuffer_c.force,
      &FingerEAERCtrl_B.sf_detectforceonset1_f,
      &FingerEAERCtrl_DWork.sf_detectforceonset1_f);

    /* Memory: '<S93>/tDesMem' */
    FingerEAERCtrl_B.tDesMem_l = FingerEAERCtrl_DWork.tDesMem_PreviousInput_n;

    /* MATLAB Function: '<S93>/trigger check' */
    FingerEAERCtrl_triggercheck(FingerEAERCtrl_B.sf_detectforceonset1_f.update,
      FingerEAERCtrl_B.sf_detectforceonset1_f.tDes, FingerEAERCtrl_B.tDesMem_l,
      &FingerEAERCtrl_B.sf_triggercheck_c,
      &FingerEAERCtrl_DWork.sf_triggercheck_c);

    /* Outputs for Triggered SubSystem: '<S93>/params buffer1' */
    FingerEAERCtrl_paramsbuffer1(FingerEAERCtrl_B.sf_triggercheck_c.update1,
      FingerEAERCtrl_B.parP2Des, FingerEAERCtrl_B.parTHit2,
      FingerEAERCtrl_B.Saturation2, FingerEAERCtrl_B.sigTargetTime,
      FingerEAERCtrl_rtM, &FingerEAERCtrl_B.paramsbuffer1_i,
      &FingerEAERCtrl_DWork.paramsbuffer1_i,
      &FingerEAERCtrl_PrevZCSigState.paramsbuffer1_i);

    /* End of Outputs for SubSystem: '<S93>/params buffer1' */

    /* Memory: '<S93>/pholdMem' */
    FingerEAERCtrl_B.pholdMem_c = FingerEAERCtrl_DWork.pholdMem_PreviousInput_k;

    /* Memory: '<S93>/stateMem' */
    FingerEAERCtrl_B.stateMem_h = FingerEAERCtrl_DWork.stateMem_PreviousInput_g;

    /* MATLAB Function: '<S93>/traj calc' */
    FingerEAERCtrl_trajcalc(FingerEAERCtrl_B.paramsbuffer1_i.pDes,
      FingerEAERCtrl_B.paramsbuffer1_i.tHit,
      FingerEAERCtrl_B.paramsbuffer1_i.dur, FingerEAERCtrl_B.sigTargetTime,
      FingerEAERCtrl_B.pholdMem_c, FingerEAERCtrl_B.stateMem_h,
      FingerEAERCtrl_B.Gain1, FingerEAERCtrl_B.Saturation1,
      &FingerEAERCtrl_B.sf_trajcalc_o, &FingerEAERCtrl_DWork.sf_trajcalc_o);

    /* MultiPortSwitch: '<S6>/Multiport Switch' */
    switch ((int32_T)FingerEAERCtrl_B.Saturation1) {
     case 1:
      FingerEAERCtrl_B.MultiportSwitch[0] =
        FingerEAERCtrl_B.sf_MATLABFunction_g.des[0];
      FingerEAERCtrl_B.MultiportSwitch[1] =
        FingerEAERCtrl_B.sf_MATLABFunction_g.des[1];
      FingerEAERCtrl_B.MultiportSwitch[2] =
        FingerEAERCtrl_B.sf_MATLABFunction_g.des[2];
      FingerEAERCtrl_B.MultiportSwitch[3] =
        FingerEAERCtrl_B.sf_MATLABFunction_p.des[0];
      FingerEAERCtrl_B.MultiportSwitch[4] =
        FingerEAERCtrl_B.sf_MATLABFunction_p.des[1];
      FingerEAERCtrl_B.MultiportSwitch[5] =
        FingerEAERCtrl_B.sf_MATLABFunction_p.des[2];
      break;

     case 2:
      FingerEAERCtrl_B.MultiportSwitch[0] =
        FingerEAERCtrl_B.sf_MATLABFunction_mh.des[0];
      FingerEAERCtrl_B.MultiportSwitch[1] =
        FingerEAERCtrl_B.sf_MATLABFunction_mh.des[1];
      FingerEAERCtrl_B.MultiportSwitch[2] =
        FingerEAERCtrl_B.sf_MATLABFunction_mh.des[2];
      FingerEAERCtrl_B.MultiportSwitch[3] =
        FingerEAERCtrl_B.sf_MATLABFunction_i.des[0];
      FingerEAERCtrl_B.MultiportSwitch[4] =
        FingerEAERCtrl_B.sf_MATLABFunction_i.des[1];
      FingerEAERCtrl_B.MultiportSwitch[5] =
        FingerEAERCtrl_B.sf_MATLABFunction_i.des[2];
      break;

     case 3:
      FingerEAERCtrl_B.MultiportSwitch[0] =
        FingerEAERCtrl_B.sf_MATLABFunction_c.des[0];
      FingerEAERCtrl_B.MultiportSwitch[1] =
        FingerEAERCtrl_B.sf_MATLABFunction_c.des[1];
      FingerEAERCtrl_B.MultiportSwitch[2] =
        FingerEAERCtrl_B.sf_MATLABFunction_c.des[2];
      FingerEAERCtrl_B.MultiportSwitch[3] =
        FingerEAERCtrl_B.sf_MATLABFunction_j.des[0];
      FingerEAERCtrl_B.MultiportSwitch[4] =
        FingerEAERCtrl_B.sf_MATLABFunction_j.des[1];
      FingerEAERCtrl_B.MultiportSwitch[5] =
        FingerEAERCtrl_B.sf_MATLABFunction_j.des[2];
      break;

     default:
      FingerEAERCtrl_B.MultiportSwitch[0] = FingerEAERCtrl_B.sf_trajcalc.des[0];
      FingerEAERCtrl_B.MultiportSwitch[1] = FingerEAERCtrl_B.sf_trajcalc.des[1];
      FingerEAERCtrl_B.MultiportSwitch[2] = FingerEAERCtrl_B.sf_trajcalc.des[2];
      FingerEAERCtrl_B.MultiportSwitch[3] = FingerEAERCtrl_B.sf_trajcalc_o.des[0];
      FingerEAERCtrl_B.MultiportSwitch[4] = FingerEAERCtrl_B.sf_trajcalc_o.des[1];
      FingerEAERCtrl_B.MultiportSwitch[5] = FingerEAERCtrl_B.sf_trajcalc_o.des[2];
      break;
    }

    /* End of MultiPortSwitch: '<S6>/Multiport Switch' */

    /* Gain: '<S4>/parKp1' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parKp1 = FingerEAERCtrl_P.parKp1_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* Memory: '<S35>/Memory' */
    FingerEAERCtrl_B.Memory_g[0] = FingerEAERCtrl_DWork.Memory_PreviousInput_k1
      [0];
    FingerEAERCtrl_B.Memory_g[1] = FingerEAERCtrl_DWork.Memory_PreviousInput_k1
      [1];
    FingerEAERCtrl_B.Memory_g[2] = FingerEAERCtrl_DWork.Memory_PreviousInput_k1
      [2];
    FingerEAERCtrl_B.Memory_g[3] = FingerEAERCtrl_DWork.Memory_PreviousInput_k1
      [3];

    /* MATLAB Function: '<S35>/gainramp' */
    FingerEAERCtrl_gainramp(FingerEAERCtrl_B.parChangeRate,
      FingerEAERCtrl_B.parKp1, FingerEAERCtrl_B.Memory_g,
      &FingerEAERCtrl_B.sf_gainramp_o, &FingerEAERCtrl_DWork.sf_gainramp_o);

    /* Gain: '<S4>/parKp2' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parKp2 = FingerEAERCtrl_P.parKp2_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* Memory: '<S36>/Memory' */
    FingerEAERCtrl_B.Memory_i[0] = FingerEAERCtrl_DWork.Memory_PreviousInput_n[0];
    FingerEAERCtrl_B.Memory_i[1] = FingerEAERCtrl_DWork.Memory_PreviousInput_n[1];
    FingerEAERCtrl_B.Memory_i[2] = FingerEAERCtrl_DWork.Memory_PreviousInput_n[2];
    FingerEAERCtrl_B.Memory_i[3] = FingerEAERCtrl_DWork.Memory_PreviousInput_n[3];

    /* MATLAB Function: '<S36>/gainramp' */
    FingerEAERCtrl_gainramp(FingerEAERCtrl_B.parChangeRate,
      FingerEAERCtrl_B.parKp2, FingerEAERCtrl_B.Memory_i,
      &FingerEAERCtrl_B.sf_gainramp_i, &FingerEAERCtrl_DWork.sf_gainramp_i);

    /* Gain: '<S4>/parKd1' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parKd1 = FingerEAERCtrl_P.parKd1_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* Memory: '<S37>/Memory' */
    FingerEAERCtrl_B.Memory_e3[0] = FingerEAERCtrl_DWork.Memory_PreviousInput_b
      [0];
    FingerEAERCtrl_B.Memory_e3[1] = FingerEAERCtrl_DWork.Memory_PreviousInput_b
      [1];
    FingerEAERCtrl_B.Memory_e3[2] = FingerEAERCtrl_DWork.Memory_PreviousInput_b
      [2];
    FingerEAERCtrl_B.Memory_e3[3] = FingerEAERCtrl_DWork.Memory_PreviousInput_b
      [3];

    /* MATLAB Function: '<S37>/gainramp' */
    FingerEAERCtrl_gainramp(FingerEAERCtrl_B.parChangeRate,
      FingerEAERCtrl_B.parKd1, FingerEAERCtrl_B.Memory_e3,
      &FingerEAERCtrl_B.sf_gainramp_id, &FingerEAERCtrl_DWork.sf_gainramp_id);

    /* Gain: '<S4>/parKd2' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parKd2 = FingerEAERCtrl_P.parKd2_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* Memory: '<S38>/Memory' */
    FingerEAERCtrl_B.Memory_o[0] = FingerEAERCtrl_DWork.Memory_PreviousInput_j[0];
    FingerEAERCtrl_B.Memory_o[1] = FingerEAERCtrl_DWork.Memory_PreviousInput_j[1];
    FingerEAERCtrl_B.Memory_o[2] = FingerEAERCtrl_DWork.Memory_PreviousInput_j[2];
    FingerEAERCtrl_B.Memory_o[3] = FingerEAERCtrl_DWork.Memory_PreviousInput_j[3];

    /* MATLAB Function: '<S38>/gainramp' */
    FingerEAERCtrl_gainramp(FingerEAERCtrl_B.parChangeRate,
      FingerEAERCtrl_B.parKd2, FingerEAERCtrl_B.Memory_o,
      &FingerEAERCtrl_B.sf_gainramp_b, &FingerEAERCtrl_DWork.sf_gainramp_b);

    /* SignalConversion: '<S25>/TmpSignal ConversionAt SFunction Inport2' incorporates:
     *  MATLAB Function: '<S3>/controller'
     */
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_h[0] = FingerEAERCtrl_B.Gain;
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_h[1] = FingerEAERCtrl_B.Diff;
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_h[2] = FingerEAERCtrl_B.Gain1;
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_h[3] =
      FingerEAERCtrl_B.Diff_a;

    /* SignalConversion: '<S25>/TmpSignal ConversionAt SFunction Inport3' incorporates:
     *  MATLAB Function: '<S3>/controller'
     */
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_b[0] =
      FingerEAERCtrl_B.sf_gainramp_o.val;
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_b[1] =
      FingerEAERCtrl_B.sf_gainramp_i.val;

    /* SignalConversion: '<S25>/TmpSignal ConversionAt SFunction Inport4' incorporates:
     *  MATLAB Function: '<S3>/controller'
     */
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_m[0] =
      FingerEAERCtrl_B.sf_gainramp_id.val;
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_m[1] =
      FingerEAERCtrl_B.sf_gainramp_b.val;

    /* MATLAB Function: '<S3>/controller' */
    FingerEAERCtrl_DWork.sfEvent_g = FingerEAERCtrl_CALL_EVENT_m5;

    /* MATLAB Function 'controller/controller': '<S25>:1' */
    /* '<S25>:1:3' */
    /* '<S25>:1:4' */
    /* '<S25>:1:6' */
    /* '<S25>:1:7' */
    /* '<S25>:1:9' */
    /* '<S25>:1:10' */
    /* '<S25>:1:12' */
    FingerEAERCtrl_B.Forces_a[0] = (FingerEAERCtrl_B.MultiportSwitch[0] -
      FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_h[0]) *
      FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_b[0] +
      (FingerEAERCtrl_B.MultiportSwitch[1] -
       FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_h[1]) *
      FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_m[0];
    FingerEAERCtrl_B.Forces_a[1] = (FingerEAERCtrl_B.MultiportSwitch[3] -
      FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_h[2]) *
      FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_b[1] +
      (FingerEAERCtrl_B.MultiportSwitch[4] -
       FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_h[3]) *
      FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_m[1];

    /* Product: '<S3>/Product' */
    FingerEAERCtrl_B.Product_m[0] = FingerEAERCtrl_B.sf_gainramp.val *
      FingerEAERCtrl_B.Forces_a[0];
    FingerEAERCtrl_B.Product_m[1] = FingerEAERCtrl_B.sf_gainramp.val *
      FingerEAERCtrl_B.Forces_a[1];

    /* MATLAB Function: '<S27>/ramp' */
    FingerEAERCtrl_DWork.sfEvent_d = FingerEAERCtrl_CALL_EVENT_m5;

    /* MATLAB Function 'controller/initial ramp/ramp': '<S32>:1' */
    /* '<S32>:1:4' */
    FingerEAERCtrl_B.y = FingerEAERCtrl_B.sigTargetTime * -0.8;

    /* Saturate: '<S27>/Saturation1' */
    ctrlW = FingerEAERCtrl_B.y;
    b = FingerEAERCtrl_P.Saturation1_LowerSat_k;
    pos_idx = FingerEAERCtrl_P.Saturation1_UpperSat_i;
    if (ctrlW >= pos_idx) {
      FingerEAERCtrl_B.Saturation1_i = pos_idx;
    } else if (ctrlW <= b) {
      FingerEAERCtrl_B.Saturation1_i = b;
    } else {
      FingerEAERCtrl_B.Saturation1_i = ctrlW;
    }

    /* End of Saturate: '<S27>/Saturation1' */

    /* MATLAB Function: '<S27>/MATLAB Function' */
    FingerEAERCtrl_DWork.sfEvent_cn = FingerEAERCtrl_CALL_EVENT_m5;

    /* MATLAB Function 'controller/initial ramp/MATLAB Function': '<S31>:1' */
    /* '<S31>:1:3' */
    /* '<S31>:1:4' */
    ctrlW = 1.0 / (exp((FingerEAERCtrl_B.sigTargetTime - 5.0) * -8.0) + 1.0);

    /* '<S31>:1:5' */
    b = (1.0 - ctrlW) * FingerEAERCtrl_B.Saturation1_i;
    FingerEAERCtrl_B.Force[0] = ctrlW * FingerEAERCtrl_B.Product_m[0] + b;
    FingerEAERCtrl_B.Force[1] = ctrlW * FingerEAERCtrl_B.Product_m[1] + b;

    /* Gain: '<S4>/parPStop' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parPStop = FingerEAERCtrl_P.parPStop_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* Gain: '<S4>/parKdV1' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parKdV1 = FingerEAERCtrl_P.parKdV1_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* Memory: '<S39>/Memory' */
    FingerEAERCtrl_B.Memory_nk[0] =
      FingerEAERCtrl_DWork.Memory_PreviousInput_ix[0];
    FingerEAERCtrl_B.Memory_nk[1] =
      FingerEAERCtrl_DWork.Memory_PreviousInput_ix[1];
    FingerEAERCtrl_B.Memory_nk[2] =
      FingerEAERCtrl_DWork.Memory_PreviousInput_ix[2];
    FingerEAERCtrl_B.Memory_nk[3] =
      FingerEAERCtrl_DWork.Memory_PreviousInput_ix[3];

    /* MATLAB Function: '<S39>/gainramp' */
    FingerEAERCtrl_gainramp(FingerEAERCtrl_B.parChangeRate,
      FingerEAERCtrl_B.parKdV1, FingerEAERCtrl_B.Memory_nk,
      &FingerEAERCtrl_B.sf_gainramp_f, &FingerEAERCtrl_DWork.sf_gainramp_f);

    /* Gain: '<S4>/parKdV2' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parKdV2 = FingerEAERCtrl_P.parKdV2_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* Memory: '<S40>/Memory' */
    FingerEAERCtrl_B.Memory_os[0] = FingerEAERCtrl_DWork.Memory_PreviousInput_c
      [0];
    FingerEAERCtrl_B.Memory_os[1] = FingerEAERCtrl_DWork.Memory_PreviousInput_c
      [1];
    FingerEAERCtrl_B.Memory_os[2] = FingerEAERCtrl_DWork.Memory_PreviousInput_c
      [2];
    FingerEAERCtrl_B.Memory_os[3] = FingerEAERCtrl_DWork.Memory_PreviousInput_c
      [3];

    /* MATLAB Function: '<S40>/gainramp' */
    FingerEAERCtrl_gainramp(FingerEAERCtrl_B.parChangeRate,
      FingerEAERCtrl_B.parKdV2, FingerEAERCtrl_B.Memory_os,
      &FingerEAERCtrl_B.sf_gainramp_a, &FingerEAERCtrl_DWork.sf_gainramp_a);

    /* SignalConversion: '<S29>/TmpSignal ConversionAt SFunction Inport1' incorporates:
     *  MATLAB Function: '<S3>/viccosityAdder'
     */
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctionI[0] = FingerEAERCtrl_B.Gain;
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctionI[1] = FingerEAERCtrl_B.Diff;
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctionI[2] = FingerEAERCtrl_B.Gain1;
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctionI[3] =
      FingerEAERCtrl_B.Diff_a;

    /* SignalConversion: '<S29>/TmpSignal ConversionAt SFunction Inport3' incorporates:
     *  MATLAB Function: '<S3>/viccosityAdder'
     */
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_j[0] =
      FingerEAERCtrl_B.sf_gainramp_f.val;
    FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_j[1] =
      FingerEAERCtrl_B.sf_gainramp_a.val;

    /* MATLAB Function: '<S3>/viccosityAdder' */
    FingerEAERCtrl_DWork.sfEvent = FingerEAERCtrl_CALL_EVENT_m5;

    /* MATLAB Function 'controller/viccosityAdder': '<S29>:1' */
    /* '<S29>:1:4' */
    pos_idx = FingerEAERCtrl_B.TmpSignalConversionAtSFunctionI[0];
    pos_idx_0 = FingerEAERCtrl_B.TmpSignalConversionAtSFunctionI[2];

    /* '<S29>:1:5' */
    vel_idx = FingerEAERCtrl_B.TmpSignalConversionAtSFunctionI[1];
    vel_idx_0 = FingerEAERCtrl_B.TmpSignalConversionAtSFunctionI[3];

    /* '<S29>:1:6' */
    FingerEAERCtrl_B.Forces[0] = 0.0;
    FingerEAERCtrl_B.Forces[1] = 0.0;

    /* '<S29>:1:7' */
    FingerEAERCtrl_B.Forces[0] = -vel_idx *
      FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_j[0];

    /* '<S29>:1:8' */
    FingerEAERCtrl_B.Forces[1] = -vel_idx_0 *
      FingerEAERCtrl_B.TmpSignalConversionAtSFunctio_j[1];

    /* % add in a software soft stop */
    /*  if the robot is close to the extreemes of it's range of motion, apply a */
    /*  viscous field to slow the robot down so that the user will not slam the */
    /*  mechanisms into the hard stops. */
    /*  softStopGain = .7; */
    /* '<S29>:1:17' */
    ctrlW = 2.0 / (1.0 - FingerEAERCtrl_B.parPStop);

    /* '<S29>:1:18' */
    b = -ctrlW * FingerEAERCtrl_B.parPStop;

    /* '<S29>:1:19' */
    /* '<S29>:1:20' */
    if ((pos_idx > FingerEAERCtrl_B.parPStop) && (vel_idx > 0.0)) {
      /* '<S29>:1:23' */
      /* '<S29>:1:24' */
      FingerEAERCtrl_B.Forces[0] -= (ctrlW * pos_idx + b) * vel_idx;
    }

    if ((pos_idx_0 > FingerEAERCtrl_B.parPStop) && (vel_idx_0 > 0.0)) {
      /* '<S29>:1:27' */
      /* '<S29>:1:28' */
      FingerEAERCtrl_B.Forces[1] -= (ctrlW * pos_idx_0 + b) * vel_idx_0;
    }

    /* Gain: '<S4>/parForceTrigger' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parForceTrigger = FingerEAERCtrl_P.parForceTrigger_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* Memory: '<S28>/Memory' */
    FingerEAERCtrl_B.Memory_b = FingerEAERCtrl_DWork.Memory_PreviousInput_i3;

    /* MATLAB Function: '<S28>/MATLAB Function1' */
    FingerEAERCtrl_DWork.sfEvent_c = FingerEAERCtrl_CALL_EVENT_m5;

    /* MATLAB Function 'controller/make chirp/MATLAB Function1': '<S34>:1' */
    /* '<S34>:1:4' */
    FingerEAERCtrl_B.pulse = 0.0;

    /* '<S34>:1:5' */
    FingerEAERCtrl_B.oldTrigger_ = FingerEAERCtrl_B.Memory_b;
    if (FingerEAERCtrl_B.parForceTrigger != FingerEAERCtrl_B.Memory_b) {
      /* '<S34>:1:6' */
      /* '<S34>:1:7' */
      FingerEAERCtrl_B.pulse = FingerEAERCtrl_B.parForceTrigger;

      /* '<S34>:1:8' */
      FingerEAERCtrl_B.oldTrigger_ = FingerEAERCtrl_B.parForceTrigger;
    }

    /* End of MATLAB Function: '<S28>/MATLAB Function1' */

    /* Gain: '<S4>/parWiggleAmp' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parWiggleAmp = FingerEAERCtrl_P.parWiggleAmp_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* Memory: '<S28>/Memory2' */
    FingerEAERCtrl_B.Memory2_a = FingerEAERCtrl_DWork.Memory2_PreviousInput_f;

    /* Memory: '<S28>/Memory1' */
    FingerEAERCtrl_B.Memory1_a = FingerEAERCtrl_DWork.Memory1_PreviousInput_k;

    /* MATLAB Function: '<S28>/MATLAB Function' */
    FingerEAERCtrl_DWork.sfEvent_b = FingerEAERCtrl_CALL_EVENT_m5;

    /* MATLAB Function 'controller/make chirp/MATLAB Function': '<S33>:1' */
    /* '<S33>:1:3' */
    FingerEAERCtrl_B.tStart_ = FingerEAERCtrl_B.Memory2_a;

    /* '<S33>:1:4' */
    FingerEAERCtrl_B.fNum_ = FingerEAERCtrl_B.Memory1_a;
    if (FingerEAERCtrl_B.pulse == 1.0) {
      /* '<S33>:1:5' */
      /* '<S33>:1:6' */
      FingerEAERCtrl_B.tStart_ = FingerEAERCtrl_B.sigTargetTime;

      /* '<S33>:1:7' */
      FingerEAERCtrl_B.fNum_ = FingerEAERCtrl_B.pulse;
    } else {
      if (FingerEAERCtrl_B.pulse == 2.0) {
        /* '<S33>:1:8' */
        /* '<S33>:1:9' */
        FingerEAERCtrl_B.tStart_ = FingerEAERCtrl_B.sigTargetTime;

        /* '<S33>:1:10' */
        FingerEAERCtrl_B.fNum_ = FingerEAERCtrl_B.pulse;
      }
    }

    /* '<S33>:1:13' */
    ctrlW = FingerEAERCtrl_B.sigTargetTime - FingerEAERCtrl_B.Memory2_a;

    /* '<S33>:1:15' */
    /* '<S33>:1:19' */
    /* '<S33>:1:21' */
    b = sin(0.60000000000000009 * ctrlW * 6.2831853071795862 * ctrlW) *
      FingerEAERCtrl_B.parWiggleAmp;
    if (ctrlW > 10.0) {
      /* '<S33>:1:22' */
      /* '<S33>:1:23' */
      b = 0.0;
    }

    if (FingerEAERCtrl_B.Memory1_a == 1.0) {
      /* '<S33>:1:26' */
      /* '<S33>:1:27' */
      FingerEAERCtrl_B.f1 = b;

      /* '<S33>:1:28' */
      FingerEAERCtrl_B.f2 = 0.0;
    } else if (FingerEAERCtrl_B.Memory1_a == 2.0) {
      /* '<S33>:1:29' */
      /* '<S33>:1:30' */
      FingerEAERCtrl_B.f1 = 0.0;

      /* '<S33>:1:31' */
      FingerEAERCtrl_B.f2 = b;
    } else {
      /* '<S33>:1:33' */
      FingerEAERCtrl_B.f1 = 0.0;

      /* '<S33>:1:34' */
      FingerEAERCtrl_B.f2 = 0.0;
    }

    /* End of MATLAB Function: '<S28>/MATLAB Function' */

    /* Sum: '<S3>/Add' */
    FingerEAERCtrl_B.Add[0] = (FingerEAERCtrl_B.Force[0] +
      FingerEAERCtrl_B.Forces[0]) + FingerEAERCtrl_B.f1;
    FingerEAERCtrl_B.Add[1] = (FingerEAERCtrl_B.Force[1] +
      FingerEAERCtrl_B.Forces[1]) + FingerEAERCtrl_B.f2;

    /* MATLAB Function: '<S12>/MATLAB Function' */
    FingerEAERCtrl_MATLABFunction(FingerEAERCtrl_B.Add[0], FingerEAERCtrl_B.Add
      [1], FingerEAERCtrl_B.Saturation, &FingerEAERCtrl_B.sf_MATLABFunction_my,
      &FingerEAERCtrl_DWork.sf_MATLABFunction_my);

    /* Level2 S-Function Block: '<S2>/PCI-6221 DA' (danipcim) */
    {
      SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[3];
      sfcnOutputs(rts, 1);
    }

    /* DiscreteStateSpace: '<S16>/Low Pass 100 Hz' */
    {
      FingerEAERCtrl_B.LowPass100Hz = (FingerEAERCtrl_P.LowPass100Hz_C[0])*
        FingerEAERCtrl_DWork.LowPass100Hz_DSTATE[0]
        + (FingerEAERCtrl_P.LowPass100Hz_C[1])*
        FingerEAERCtrl_DWork.LowPass100Hz_DSTATE[1];
      FingerEAERCtrl_B.LowPass100Hz += FingerEAERCtrl_P.LowPass100Hz_D*
        FingerEAERCtrl_B.Add[0];
    }

    /* DiscreteStateSpace: '<S16>/Low Pass 100 Hz1' */
    {
      FingerEAERCtrl_B.LowPass100Hz1 = (FingerEAERCtrl_P.LowPass100Hz1_C[0])*
        FingerEAERCtrl_DWork.LowPass100Hz1_DSTATE[0]
        + (FingerEAERCtrl_P.LowPass100Hz1_C[1])*
        FingerEAERCtrl_DWork.LowPass100Hz1_DSTATE[1];
      FingerEAERCtrl_B.LowPass100Hz1 += FingerEAERCtrl_P.LowPass100Hz1_D*
        FingerEAERCtrl_B.Add[1];
    }

    /* Outputs for Triggered SubSystem: '<S92>/saveTrialStartTime' */
    FingerEAERCt_saveTrialStartTime(FingerEAERCtrl_B.sf_MATLABFunction1_k.change,
      FingerEAERCtrl_B.sigTargetTime, FingerEAERCtrl_rtM,
      &FingerEAERCtrl_B.saveTrialStartTime,
      &FingerEAERCtrl_DWork.saveTrialStartTime,
      &FingerEAERCtrl_PrevZCSigState.saveTrialStartTime);

    /* End of Outputs for SubSystem: '<S92>/saveTrialStartTime' */

    /* Outputs for Triggered SubSystem: '<S92>/timeToTrigger' */
    FingerEAERCtrl_timeToTrigger(FingerEAERCtrl_B.sf_triggercheck.update1,
      FingerEAERCtrl_B.sigTargetTime,
      FingerEAERCtrl_B.saveTrialStartTime.trialStartTime, FingerEAERCtrl_rtM,
      &FingerEAERCtrl_B.timeToTrigger, &FingerEAERCtrl_DWork.timeToTrigger,
      &FingerEAERCtrl_PrevZCSigState.timeToTrigger);

    /* End of Outputs for SubSystem: '<S92>/timeToTrigger' */

    /* Outputs for Triggered SubSystem: '<S93>/saveTrialStartTime' */
    FingerEAERCt_saveTrialStartTime(FingerEAERCtrl_B.sf_MATLABFunction1_l.change,
      FingerEAERCtrl_B.sigTargetTime, FingerEAERCtrl_rtM,
      &FingerEAERCtrl_B.saveTrialStartTime_o,
      &FingerEAERCtrl_DWork.saveTrialStartTime_o,
      &FingerEAERCtrl_PrevZCSigState.saveTrialStartTime_o);

    /* End of Outputs for SubSystem: '<S93>/saveTrialStartTime' */

    /* Outputs for Triggered SubSystem: '<S93>/timeToTrigger' */
    FingerEAERCtrl_timeToTrigger(FingerEAERCtrl_B.sf_triggercheck_c.update1,
      FingerEAERCtrl_B.sigTargetTime,
      FingerEAERCtrl_B.saveTrialStartTime_o.trialStartTime, FingerEAERCtrl_rtM,
      &FingerEAERCtrl_B.timeToTrigger_e, &FingerEAERCtrl_DWork.timeToTrigger_e,
      &FingerEAERCtrl_PrevZCSigState.timeToTrigger_e);

    /* End of Outputs for SubSystem: '<S93>/timeToTrigger' */

    /* Gain: '<S4>/parMarker' incorporates:
     *  Constant: '<S4>/paremeters_ must_be_one'
     */
    FingerEAERCtrl_B.parMarker = FingerEAERCtrl_P.parMarker_Gain *
      FingerEAERCtrl_P.paremeters_must_be_one_Value;

    /* ok to acquire for <S48>/S-Function */
    FingerEAERCtrl_DWork.SFunction_IWORK_l.AcquireOK = 1;

    /* ok to acquire for <S49>/S-Function */
    FingerEAERCtrl_DWork.SFunction_IWORK_a.AcquireOK = 1;

    /* Gain: '<S5>/sigPos1' */
    FingerEAERCtrl_B.sigPos1 = FingerEAERCtrl_P.sigPos1_Gain *
      FingerEAERCtrl_B.Gain;

    /* Gain: '<S5>/sigPos2' */
    FingerEAERCtrl_B.sigPos2 = FingerEAERCtrl_P.sigPos2_Gain *
      FingerEAERCtrl_B.Gain1;

    /* Gain: '<S5>/sigVel1' */
    FingerEAERCtrl_B.sigVel1 = FingerEAERCtrl_P.sigVel1_Gain *
      FingerEAERCtrl_B.Diff;

    /* Gain: '<S5>/sigVel2' */
    FingerEAERCtrl_B.sigVel2 = FingerEAERCtrl_P.sigVel2_Gain *
      FingerEAERCtrl_B.Diff_a;

    /* Gain: '<S5>/sigPos1Des' */
    FingerEAERCtrl_B.sigPos1Des = FingerEAERCtrl_P.sigPos1Des_Gain *
      FingerEAERCtrl_B.MultiportSwitch[0];

    /* Gain: '<S5>/sigPos2Des' */
    FingerEAERCtrl_B.sigPos2Des = FingerEAERCtrl_P.sigPos2Des_Gain *
      FingerEAERCtrl_B.MultiportSwitch[3];

    /* Gain: '<S5>/sigVel1Des' */
    FingerEAERCtrl_B.sigVel1Des = FingerEAERCtrl_P.sigVel1Des_Gain *
      FingerEAERCtrl_B.MultiportSwitch[1];

    /* Gain: '<S5>/sigVel2Des' */
    FingerEAERCtrl_B.sigVel2Des = FingerEAERCtrl_P.sigVel2Des_Gain *
      FingerEAERCtrl_B.MultiportSwitch[4];

    /* Gain: '<S5>/sigForce1' */
    FingerEAERCtrl_B.sigForce1 = FingerEAERCtrl_P.sigForce1_Gain *
      FingerEAERCtrl_B.Add[0];

    /* Gain: '<S5>/sigForce2' */
    FingerEAERCtrl_B.sigForce2 = FingerEAERCtrl_P.sigForce2_Gain *
      FingerEAERCtrl_B.Add[1];

    /* ok to acquire for <S47>/S-Function */
    FingerEAERCtrl_DWork.SFunction_IWORK_g.AcquireOK = 1;

    /* Gain: '<S5>/sigLoadC' */
    FingerEAERCtrl_B.sigLoadC = FingerEAERCtrl_P.sigLoadC_Gain *
      FingerEAERCtrl_B.output[4];

    /* Gain: '<S5>/sigLoadCF1a' */
    FingerEAERCtrl_B.sigLoadCF1a = FingerEAERCtrl_P.sigLoadCF1a_Gain *
      FingerEAERCtrl_B.output[0];

    /* Gain: '<S5>/sigLoadCF1b' */
    FingerEAERCtrl_B.sigLoadCF1b = FingerEAERCtrl_P.sigLoadCF1b_Gain *
      FingerEAERCtrl_B.output[1];

    /* Gain: '<S5>/sigLoadCF2a' */
    FingerEAERCtrl_B.sigLoadCF2a = FingerEAERCtrl_P.sigLoadCF2a_Gain *
      FingerEAERCtrl_B.output[2];

    /* Gain: '<S5>/sigLoadCF2b' */
    FingerEAERCtrl_B.sigLoadCF2b = FingerEAERCtrl_P.sigLoadCF2b_Gain *
      FingerEAERCtrl_B.output[3];

    /* Gain: '<S5>/sigForce1Clean' */
    FingerEAERCtrl_B.sigForce1Clean = FingerEAERCtrl_P.sigForce1Clean_Gain *
      FingerEAERCtrl_B.Memory_n;

    /* Gain: '<S5>/sigForce2Clean' */
    FingerEAERCtrl_B.sigForce2Clean = FingerEAERCtrl_P.sigForce2Clean_Gain *
      FingerEAERCtrl_B.Memory1_j;

    /* Gain: '<S5>/sigGravAccel' */
    FingerEAERCtrl_B.sigGravAccel = FingerEAERCtrl_P.sigGravAccel_Gain *
      FingerEAERCtrl_B.gain;

    /* Gain: '<S5>/sigTimeToThresh1' */
    FingerEAERCtrl_B.sigTimeToThresh1 = FingerEAERCtrl_P.sigTimeToThresh1_Gain *
      FingerEAERCtrl_B.timeToTrigger.triggerTime;

    /* Gain: '<S5>/sigTimeToThresh2' */
    FingerEAERCtrl_B.sigTimeToThresh2 = FingerEAERCtrl_P.sigTimeToThresh2_Gain *
      FingerEAERCtrl_B.timeToTrigger_e.triggerTime;

    /* Gain: '<S5>/sigMarker' */
    FingerEAERCtrl_B.sigMarker = FingerEAERCtrl_P.sigMarker_Gain *
      FingerEAERCtrl_B.parMarker;
  }
}

/* Model update function */
void FingerEAERCtrl_update(void)
{
  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    /* Update for Memory: '<S17>/Memory1' */
    FingerEAERCtrl_DWork.Memory1_PreviousInput[0] = FingerEAERCtrl_B.summedVals
      [0];
    FingerEAERCtrl_DWork.Memory1_PreviousInput[1] = FingerEAERCtrl_B.summedVals
      [1];

    /* Update for Memory: '<S17>/Memory' */
    FingerEAERCtrl_DWork.Memory_PreviousInput = FingerEAERCtrl_B.nSamples;

    /* Update for UnitDelay: '<S10>/UD' */
    FingerEAERCtrl_DWork.UD_DSTATE = FingerEAERCtrl_B.TSamp;

    /* Update for UnitDelay: '<S11>/UD' */
    FingerEAERCtrl_DWork.UD_DSTATE_h = FingerEAERCtrl_B.TSamp_l;

    /* Update for Memory: '<S26>/Memory' */
    FingerEAERCtrl_DWork.Memory_PreviousInput_i[0] =
      FingerEAERCtrl_B.sf_gainramp.state1[0];
    FingerEAERCtrl_DWork.Memory_PreviousInput_i[1] =
      FingerEAERCtrl_B.sf_gainramp.state1[1];
    FingerEAERCtrl_DWork.Memory_PreviousInput_i[2] =
      FingerEAERCtrl_B.sf_gainramp.state1[2];
    FingerEAERCtrl_DWork.Memory_PreviousInput_i[3] =
      FingerEAERCtrl_B.sf_gainramp.state1[3];

    /* Update for Memory: '<S55>/Memory' */
    FingerEAERCtrl_DWork.Memory_PreviousInput_k =
      FingerEAERCtrl_B.sf_MATLABFunction_g.des[0];

    /* Update for Memory: '<S16>/Memory' */
    FingerEAERCtrl_DWork.Memory_PreviousInput_l = FingerEAERCtrl_B.LowPass100Hz;

    /* Update for Memory: '<S56>/Memory' */
    FingerEAERCtrl_DWork.Memory_PreviousInput_k0 =
      FingerEAERCtrl_B.sf_MATLABFunction_p.des[0];

    /* Update for Memory: '<S16>/Memory1' */
    FingerEAERCtrl_DWork.Memory1_PreviousInput_d =
      FingerEAERCtrl_B.LowPass100Hz1;

    /* Update for Memory: '<S70>/Memory1' */
    FingerEAERCtrl_DWork.Memory1_PreviousInput_h =
      FingerEAERCtrl_B.sf_MATLABFunction1.change;

    /* Update for Memory: '<S75>/Memory1' */
    FingerEAERCtrl_DWork.Memory1_PreviousInput_e =
      FingerEAERCtrl_B.sf_MATLABFunction1_m.change;

    /* Update for Memory: '<S82>/Memory1' */
    FingerEAERCtrl_DWork.Memory1_PreviousInput_l =
      FingerEAERCtrl_B.sf_MATLABFunction1_g.change;

    /* Update for Memory: '<S79>/Memory' */
    FingerEAERCtrl_DWork.Memory_PreviousInput_h =
      FingerEAERCtrl_B.sf_MATLABFunction_c.Phold;

    /* Update for Memory: '<S79>/Memory1' */
    FingerEAERCtrl_DWork.Memory1_PreviousInput_ld =
      FingerEAERCtrl_B.sf_MATLABFunction_c.state;

    /* Update for Memory: '<S87>/Memory1' */
    FingerEAERCtrl_DWork.Memory1_PreviousInput_f =
      FingerEAERCtrl_B.sf_MATLABFunction1_h.change;

    /* Update for Memory: '<S80>/Memory' */
    FingerEAERCtrl_DWork.Memory_PreviousInput_la =
      FingerEAERCtrl_B.sf_MATLABFunction_j.Phold;

    /* Update for Memory: '<S80>/Memory1' */
    FingerEAERCtrl_DWork.Memory1_PreviousInput_hw =
      FingerEAERCtrl_B.sf_MATLABFunction_j.state;

    /* Update for Memory: '<S95>/Memory2' */
    FingerEAERCtrl_DWork.Memory2_PreviousInput =
      FingerEAERCtrl_B.sf_MATLABFunction1_k.tDesOut;

    /* Update for Memory: '<S92>/tDesMem' */
    FingerEAERCtrl_DWork.tDesMem_PreviousInput =
      FingerEAERCtrl_B.sf_triggercheck.tDesLast;

    /* Update for Memory: '<S92>/pholdMem' */
    FingerEAERCtrl_DWork.pholdMem_PreviousInput =
      FingerEAERCtrl_B.sf_trajcalc.Phold;

    /* Update for Memory: '<S92>/stateMem' */
    FingerEAERCtrl_DWork.stateMem_PreviousInput =
      FingerEAERCtrl_B.sf_trajcalc.state;

    /* Update for Memory: '<S108>/Memory2' */
    FingerEAERCtrl_DWork.Memory2_PreviousInput_o =
      FingerEAERCtrl_B.sf_MATLABFunction1_l.tDesOut;

    /* Update for Memory: '<S93>/tDesMem' */
    FingerEAERCtrl_DWork.tDesMem_PreviousInput_n =
      FingerEAERCtrl_B.sf_triggercheck_c.tDesLast;

    /* Update for Memory: '<S93>/pholdMem' */
    FingerEAERCtrl_DWork.pholdMem_PreviousInput_k =
      FingerEAERCtrl_B.sf_trajcalc_o.Phold;

    /* Update for Memory: '<S93>/stateMem' */
    FingerEAERCtrl_DWork.stateMem_PreviousInput_g =
      FingerEAERCtrl_B.sf_trajcalc_o.state;

    /* Update for Memory: '<S35>/Memory' */
    FingerEAERCtrl_DWork.Memory_PreviousInput_k1[0] =
      FingerEAERCtrl_B.sf_gainramp_o.state1[0];
    FingerEAERCtrl_DWork.Memory_PreviousInput_k1[1] =
      FingerEAERCtrl_B.sf_gainramp_o.state1[1];
    FingerEAERCtrl_DWork.Memory_PreviousInput_k1[2] =
      FingerEAERCtrl_B.sf_gainramp_o.state1[2];
    FingerEAERCtrl_DWork.Memory_PreviousInput_k1[3] =
      FingerEAERCtrl_B.sf_gainramp_o.state1[3];

    /* Update for Memory: '<S36>/Memory' */
    FingerEAERCtrl_DWork.Memory_PreviousInput_n[0] =
      FingerEAERCtrl_B.sf_gainramp_i.state1[0];
    FingerEAERCtrl_DWork.Memory_PreviousInput_n[1] =
      FingerEAERCtrl_B.sf_gainramp_i.state1[1];
    FingerEAERCtrl_DWork.Memory_PreviousInput_n[2] =
      FingerEAERCtrl_B.sf_gainramp_i.state1[2];
    FingerEAERCtrl_DWork.Memory_PreviousInput_n[3] =
      FingerEAERCtrl_B.sf_gainramp_i.state1[3];

    /* Update for Memory: '<S37>/Memory' */
    FingerEAERCtrl_DWork.Memory_PreviousInput_b[0] =
      FingerEAERCtrl_B.sf_gainramp_id.state1[0];
    FingerEAERCtrl_DWork.Memory_PreviousInput_b[1] =
      FingerEAERCtrl_B.sf_gainramp_id.state1[1];
    FingerEAERCtrl_DWork.Memory_PreviousInput_b[2] =
      FingerEAERCtrl_B.sf_gainramp_id.state1[2];
    FingerEAERCtrl_DWork.Memory_PreviousInput_b[3] =
      FingerEAERCtrl_B.sf_gainramp_id.state1[3];

    /* Update for Memory: '<S38>/Memory' */
    FingerEAERCtrl_DWork.Memory_PreviousInput_j[0] =
      FingerEAERCtrl_B.sf_gainramp_b.state1[0];
    FingerEAERCtrl_DWork.Memory_PreviousInput_j[1] =
      FingerEAERCtrl_B.sf_gainramp_b.state1[1];
    FingerEAERCtrl_DWork.Memory_PreviousInput_j[2] =
      FingerEAERCtrl_B.sf_gainramp_b.state1[2];
    FingerEAERCtrl_DWork.Memory_PreviousInput_j[3] =
      FingerEAERCtrl_B.sf_gainramp_b.state1[3];

    /* Update for Memory: '<S39>/Memory' */
    FingerEAERCtrl_DWork.Memory_PreviousInput_ix[0] =
      FingerEAERCtrl_B.sf_gainramp_f.state1[0];
    FingerEAERCtrl_DWork.Memory_PreviousInput_ix[1] =
      FingerEAERCtrl_B.sf_gainramp_f.state1[1];
    FingerEAERCtrl_DWork.Memory_PreviousInput_ix[2] =
      FingerEAERCtrl_B.sf_gainramp_f.state1[2];
    FingerEAERCtrl_DWork.Memory_PreviousInput_ix[3] =
      FingerEAERCtrl_B.sf_gainramp_f.state1[3];

    /* Update for Memory: '<S40>/Memory' */
    FingerEAERCtrl_DWork.Memory_PreviousInput_c[0] =
      FingerEAERCtrl_B.sf_gainramp_a.state1[0];
    FingerEAERCtrl_DWork.Memory_PreviousInput_c[1] =
      FingerEAERCtrl_B.sf_gainramp_a.state1[1];
    FingerEAERCtrl_DWork.Memory_PreviousInput_c[2] =
      FingerEAERCtrl_B.sf_gainramp_a.state1[2];
    FingerEAERCtrl_DWork.Memory_PreviousInput_c[3] =
      FingerEAERCtrl_B.sf_gainramp_a.state1[3];

    /* Update for Memory: '<S28>/Memory' */
    FingerEAERCtrl_DWork.Memory_PreviousInput_i3 = FingerEAERCtrl_B.oldTrigger_;

    /* Update for Memory: '<S28>/Memory2' */
    FingerEAERCtrl_DWork.Memory2_PreviousInput_f = FingerEAERCtrl_B.tStart_;

    /* Update for Memory: '<S28>/Memory1' */
    FingerEAERCtrl_DWork.Memory1_PreviousInput_k = FingerEAERCtrl_B.fNum_;

    /* Update for DiscreteStateSpace: '<S16>/Low Pass 100 Hz' */
    {
      real_T xnew[2];
      xnew[0] = (FingerEAERCtrl_P.LowPass100Hz_A[0])*
        FingerEAERCtrl_DWork.LowPass100Hz_DSTATE[0]
        + (FingerEAERCtrl_P.LowPass100Hz_A[1])*
        FingerEAERCtrl_DWork.LowPass100Hz_DSTATE[1];
      xnew[0] += (FingerEAERCtrl_P.LowPass100Hz_B[0])*FingerEAERCtrl_B.Add[0];
      xnew[1] = (FingerEAERCtrl_P.LowPass100Hz_A[2])*
        FingerEAERCtrl_DWork.LowPass100Hz_DSTATE[0]
        + (FingerEAERCtrl_P.LowPass100Hz_A[3])*
        FingerEAERCtrl_DWork.LowPass100Hz_DSTATE[1];
      xnew[1] += (FingerEAERCtrl_P.LowPass100Hz_B[1])*FingerEAERCtrl_B.Add[0];
      (void) memcpy(&FingerEAERCtrl_DWork.LowPass100Hz_DSTATE[0], xnew,
                    sizeof(real_T)*2);
    }

    /* Update for DiscreteStateSpace: '<S16>/Low Pass 100 Hz1' */
    {
      real_T xnew[2];
      xnew[0] = (FingerEAERCtrl_P.LowPass100Hz1_A[0])*
        FingerEAERCtrl_DWork.LowPass100Hz1_DSTATE[0]
        + (FingerEAERCtrl_P.LowPass100Hz1_A[1])*
        FingerEAERCtrl_DWork.LowPass100Hz1_DSTATE[1];
      xnew[0] += (FingerEAERCtrl_P.LowPass100Hz1_B[0])*FingerEAERCtrl_B.Add[1];
      xnew[1] = (FingerEAERCtrl_P.LowPass100Hz1_A[2])*
        FingerEAERCtrl_DWork.LowPass100Hz1_DSTATE[0]
        + (FingerEAERCtrl_P.LowPass100Hz1_A[3])*
        FingerEAERCtrl_DWork.LowPass100Hz1_DSTATE[1];
      xnew[1] += (FingerEAERCtrl_P.LowPass100Hz1_B[1])*FingerEAERCtrl_B.Add[1];
      (void) memcpy(&FingerEAERCtrl_DWork.LowPass100Hz1_DSTATE[0], xnew,
                    sizeof(real_T)*2);
    }
  }

  if (rtmIsMajorTimeStep(FingerEAERCtrl_rtM)) {
    rt_ertODEUpdateContinuousStates(&FingerEAERCtrl_rtM->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++FingerEAERCtrl_rtM->Timing.clockTick0)) {
    ++FingerEAERCtrl_rtM->Timing.clockTickH0;
  }

  FingerEAERCtrl_rtM->Timing.t[0] = rtsiGetSolverStopTime
    (&FingerEAERCtrl_rtM->solverInfo);

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++FingerEAERCtrl_rtM->Timing.clockTick1)) {
      ++FingerEAERCtrl_rtM->Timing.clockTickH1;
    }

    FingerEAERCtrl_rtM->Timing.t[1] = FingerEAERCtrl_rtM->Timing.clockTick1 *
      FingerEAERCtrl_rtM->Timing.stepSize1 +
      FingerEAERCtrl_rtM->Timing.clockTickH1 *
      FingerEAERCtrl_rtM->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void FingerEAERCtrl_derivatives(void)
{
  StateDerivatives_FingerEAERCtrl *_rtXdot;
  _rtXdot = ((StateDerivatives_FingerEAERCtrl *)
             FingerEAERCtrl_rtM->ModelData.derivs);

  /* Derivatives for Integrator: '<S8>/Integrator' */
  _rtXdot->Integrator_CSTATE[0] = FingerEAERCtrl_B.Sum4[0];
  _rtXdot->Integrator_CSTATE[1] = FingerEAERCtrl_B.Sum4[1];
  _rtXdot->Integrator_CSTATE[2] = FingerEAERCtrl_B.Sum4[2];

  /* Derivatives for Integrator: '<S9>/Integrator' */
  _rtXdot->Integrator_CSTATE_h[0] = FingerEAERCtrl_B.Sum4_l[0];
  _rtXdot->Integrator_CSTATE_h[1] = FingerEAERCtrl_B.Sum4_l[1];
  _rtXdot->Integrator_CSTATE_h[2] = FingerEAERCtrl_B.Sum4_l[2];
}

/* Model initialize function */
void FingerEAERCtrl_initialize(void)
{
  /* Level2 S-Function Block: '<S2>/PCI-6221 AD1' (adnipcim) */
  {
    SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[0];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Level2 S-Function Block: '<S2>/PCI 6221 ENC ' (encnipcim) */
  {
    SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[1];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Level2 S-Function Block: '<S2>/PCI 6221 ENC 1' (encnipcim) */
  {
    SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[2];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* S-Function Block: <S24>/S-Function (scblock) */
  {
    int i;
    if ((i = rl32eScopeExists(3)) == 0) {
      if ((i = rl32eDefScope(3,2)) != 0) {
        printf("Error creating scope 3\n");
      } else {
        rl32eAddSignal(3, rl32eGetSignalNo("Robot/gravDir/gain"));
        rl32eSetScope(3, 4, 500);
        rl32eSetScope(3, 40, 0);
        rl32eSetScope(3, 7, 1);
        rl32eSetScope(3, 0, 0);
        rl32eSetScope(3, 3, rl32eGetSignalNo("Robot/gravDir/gain"));
        rl32eSetScope(3, 1, 0.0);
        rl32eSetScope(3, 2, 0);
        rl32eSetScope(3, 10, 0);
        rl32eSetTargetScope(3, 11, 0.03);
        rl32eSetTargetScope(3, 10, 0.1);
        xpceScopeAcqOK(3, &FingerEAERCtrl_DWork.SFunction_IWORK.AcquireOK);
      }
    }

    if (i) {
      rl32eRestartAcquisition(3);
    }
  }

  /* Level2 S-Function Block: '<S2>/PCI-6221 DA' (danipcim) */
  {
    SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[3];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* S-Function Block: <S48>/S-Function (scblock) */
  {
    int i;
    if ((i = rl32eScopeExists(1)) == 0) {
      if ((i = rl32eDefScope(1,2)) != 0) {
        printf("Error creating scope 1\n");
      } else {
        rl32eAddSignal(1, rl32eGetSignalNo("signals/sigPos1"));
        rl32eAddSignal(1, rl32eGetSignalNo("signals/sigPos2"));
        rl32eSetScope(1, 4, 500);
        rl32eSetScope(1, 40, 0);
        rl32eSetScope(1, 7, 1);
        rl32eSetScope(1, 0, 0);
        rl32eSetScope(1, 3, rl32eGetSignalNo("signals/sigPos1"));
        rl32eSetScope(1, 1, 0.0);
        rl32eSetScope(1, 2, 0);
        rl32eSetScope(1, 10, 0);
        rl32eSetTargetScope(1, 11, 0.0);
        rl32eSetTargetScope(1, 10, 1.1);
        xpceScopeAcqOK(1, &FingerEAERCtrl_DWork.SFunction_IWORK_l.AcquireOK);
      }
    }

    if (i) {
      rl32eRestartAcquisition(1);
    }
  }

  /* S-Function Block: <S49>/S-Function (scblock) */
  {
    int i;
    if ((i = rl32eScopeExists(2)) == 0) {
      if ((i = rl32eDefScope(2,2)) != 0) {
        printf("Error creating scope 2\n");
      } else {
        rl32eAddSignal(2, rl32eGetSignalNo("signals/sigVel1"));
        rl32eAddSignal(2, rl32eGetSignalNo("signals/sigVel2"));
        rl32eSetScope(2, 4, 500);
        rl32eSetScope(2, 40, 0);
        rl32eSetScope(2, 7, 1);
        rl32eSetScope(2, 0, 0);
        rl32eSetScope(2, 3, rl32eGetSignalNo("signals/sigVel1"));
        rl32eSetScope(2, 1, 0.0);
        rl32eSetScope(2, 2, 0);
        rl32eSetScope(2, 10, 0);
        rl32eSetTargetScope(2, 11, -10.0);
        rl32eSetTargetScope(2, 10, 10.0);
        xpceScopeAcqOK(2, &FingerEAERCtrl_DWork.SFunction_IWORK_a.AcquireOK);
      }
    }

    if (i) {
      rl32eRestartAcquisition(2);
    }
  }

  /* S-Function Block: <S47>/S-Function (scblock) */
  {
    int i;
    if ((i = rl32eScopeExists(5)) == 0) {
      if ((i = rl32eDefScope(5,2)) != 0) {
        printf("Error creating scope 5\n");
      } else {
        rl32eAddSignal(5, rl32eGetSignalNo("signals/sigLoadCF1a"));
        rl32eAddSignal(5, rl32eGetSignalNo("signals/sigLoadCF1b"));
        rl32eAddSignal(5, rl32eGetSignalNo("signals/sigLoadCF2a"));
        rl32eAddSignal(5, rl32eGetSignalNo("signals/sigLoadCF2b"));
        rl32eAddSignal(5, rl32eGetSignalNo("signals/sigLoadC"));
        rl32eSetScope(5, 4, 500);
        rl32eSetScope(5, 40, 0);
        rl32eSetScope(5, 7, 1);
        rl32eSetScope(5, 0, 0);
        rl32eSetScope(5, 3, rl32eGetSignalNo("signals/sigLoadCF1a"));
        rl32eSetScope(5, 1, 0.0);
        rl32eSetScope(5, 2, 0);
        rl32eSetScope(5, 10, 0);
        rl32eSetTargetScope(5, 11, -3.0);
        rl32eSetTargetScope(5, 10, 3.0);
        xpceScopeAcqOK(5, &FingerEAERCtrl_DWork.SFunction_IWORK_g.AcquireOK);
      }
    }

    if (i) {
      rl32eRestartAcquisition(5);
    }
  }

  FingerEAERCtrl_PrevZCSigState.timeToTrigger_e.timeToTrigger_Trig_ZCE =
    UNINITIALIZED_ZCSIG;
  FingerEAERCtrl_PrevZCSigState.saveTrialStartTime_o.saveTrialStartTime_Trig_ZCE
    = UNINITIALIZED_ZCSIG;
  FingerEAERCtrl_PrevZCSigState.paramsbuffer1_i.paramsbuffer1_Trig_ZCE =
    UNINITIALIZED_ZCSIG;
  FingerEAERCtrl_PrevZCSigState.forcebuffer_c.forcebuffer_Trig_ZCE =
    UNINITIALIZED_ZCSIG;
  FingerEAERCtrl_PrevZCSigState.timeToTrigger.timeToTrigger_Trig_ZCE =
    UNINITIALIZED_ZCSIG;
  FingerEAERCtrl_PrevZCSigState.saveTrialStartTime.saveTrialStartTime_Trig_ZCE =
    UNINITIALIZED_ZCSIG;
  FingerEAERCtrl_PrevZCSigState.paramsbuffer1.paramsbuffer1_Trig_ZCE =
    UNINITIALIZED_ZCSIG;
  FingerEAERCtrl_PrevZCSigState.forcebuffer.forcebuffer_Trig_ZCE =
    UNINITIALIZED_ZCSIG;
  FingerEAERCtrl_PrevZCSigState.paramsbuffer_a.paramsbuffer_Trig_ZCE =
    UNINITIALIZED_ZCSIG;
  FingerEAERCtrl_PrevZCSigState.paramsbuffer_o.paramsbuffer_Trig_ZCE =
    UNINITIALIZED_ZCSIG;
  FingerEAERCtrl_PrevZCSigState.paramsbuffer_i.paramsbuffer_Trig_ZCE_p =
    UNINITIALIZED_ZCSIG;
  FingerEAERCtrl_PrevZCSigState.paramsbuffer_k.paramsbuffer_Trig_ZCE_p =
    UNINITIALIZED_ZCSIG;
  FingerEAERCtrl_PrevZCSigState.paramsbuffer_b.paramsbuffer_Trig_ZCE_n =
    POS_ZCSIG;
  FingerEAERCtrl_PrevZCSigState.paramsbuffer.paramsbuffer_Trig_ZCE_n = POS_ZCSIG;

  /* InitializeConditions for Integrator: '<S8>/Integrator' */
  FingerEAERCtrl_X.Integrator_CSTATE[0] = FingerEAERCtrl_P.Integrator_IC[0];
  FingerEAERCtrl_X.Integrator_CSTATE[1] = FingerEAERCtrl_P.Integrator_IC[1];
  FingerEAERCtrl_X.Integrator_CSTATE[2] = FingerEAERCtrl_P.Integrator_IC[2];

  /* InitializeConditions for MATLAB Function: '<S15>/MATLAB Function' */
  FingerEAERC_MATLABFunction_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction);

  /* InitializeConditions for MATLAB Function: '<S14>/MATLAB Function' */
  FingerEAERC_MATLABFunction_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction_e);

  /* InitializeConditions for Memory: '<S17>/Memory1' */
  FingerEAERCtrl_DWork.Memory1_PreviousInput[0] = FingerEAERCtrl_P.Memory1_X0[0];
  FingerEAERCtrl_DWork.Memory1_PreviousInput[1] = FingerEAERCtrl_P.Memory1_X0[1];

  /* InitializeConditions for Memory: '<S17>/Memory' */
  FingerEAERCtrl_DWork.Memory_PreviousInput = FingerEAERCtrl_P.Memory_X0;

  /* InitializeConditions for MATLAB Function: '<S17>/MATLAB Function' */
  FingerEAERCtrl_DWork.sfEvent_p = FingerEAERCtrl_CALL_EVENT_m5;
  FingerEAERCtrl_DWork.is_active_c9_FingerEAERCtrl = 0U;

  /* InitializeConditions for UnitDelay: '<S10>/UD' */
  FingerEAERCtrl_DWork.UD_DSTATE = FingerEAERCtrl_P.UD_InitialCondition;

  /* InitializeConditions for Integrator: '<S9>/Integrator' */
  FingerEAERCtrl_X.Integrator_CSTATE_h[0] = FingerEAERCtrl_P.Integrator_IC_f[0];
  FingerEAERCtrl_X.Integrator_CSTATE_h[1] = FingerEAERCtrl_P.Integrator_IC_f[1];
  FingerEAERCtrl_X.Integrator_CSTATE_h[2] = FingerEAERCtrl_P.Integrator_IC_f[2];

  /* InitializeConditions for UnitDelay: '<S11>/UD' */
  FingerEAERCtrl_DWork.UD_DSTATE_h = FingerEAERCtrl_P.UD_InitialCondition_p;

  /* InitializeConditions for MATLAB Function: '<S13>/MATLAB Function' */
  FingerEAERCtrl_DWork.sfEvent_a = FingerEAERCtrl_CALL_EVENT_m5;
  FingerEAERCtrl_DWork.is_active_c26_FingerEAERCtrl = 0U;

  /* InitializeConditions for Memory: '<S26>/Memory' */
  FingerEAERCtrl_DWork.Memory_PreviousInput_i[0] = FingerEAERCtrl_P.Memory_X0_e
    [0];
  FingerEAERCtrl_DWork.Memory_PreviousInput_i[1] = FingerEAERCtrl_P.Memory_X0_e
    [1];
  FingerEAERCtrl_DWork.Memory_PreviousInput_i[2] = FingerEAERCtrl_P.Memory_X0_e
    [2];
  FingerEAERCtrl_DWork.Memory_PreviousInput_i[3] = FingerEAERCtrl_P.Memory_X0_e
    [3];

  /* InitializeConditions for MATLAB Function: '<S26>/gainramp' */
  FingerEAERCtrl_gainramp_Init(&FingerEAERCtrl_DWork.sf_gainramp);

  /* InitializeConditions for Memory: '<S55>/Memory' */
  FingerEAERCtrl_DWork.Memory_PreviousInput_k = FingerEAERCtrl_P.Memory_X0_n;

  /* InitializeConditions for MATLAB Function: '<S55>/detect movement onset' */
  Finger_detectmovementonset_Init(&FingerEAERCtrl_DWork.sf_detectmovementonset);

  /* InitializeConditions for Memory: '<S16>/Memory' */
  FingerEAERCtrl_DWork.Memory_PreviousInput_l = FingerEAERCtrl_P.Memory_X0_h;

  /* InitializeConditions for MATLAB Function: '<S55>/detect force onset' */
  FingerEAE_detectforceonset_Init(&FingerEAERCtrl_DWork.sf_detectforceonset);

  /* InitializeConditions for Triggered SubSystem: '<S55>/params buffer' */
  FingerEAERCtr_paramsbuffer_Init(&FingerEAERCtrl_DWork.paramsbuffer);

  /* End of InitializeConditions for SubSystem: '<S55>/params buffer' */

  /* InitializeConditions for MATLAB Function: '<S55>/MATLAB Function' */
  FingerEAE_MATLABFunction_e_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction_g);

  /* InitializeConditions for Memory: '<S56>/Memory' */
  FingerEAERCtrl_DWork.Memory_PreviousInput_k0 = FingerEAERCtrl_P.Memory_X0_c;

  /* InitializeConditions for MATLAB Function: '<S56>/detect movement onset' */
  Finger_detectmovementonset_Init(&FingerEAERCtrl_DWork.sf_detectmovementonset_m);

  /* InitializeConditions for Memory: '<S16>/Memory1' */
  FingerEAERCtrl_DWork.Memory1_PreviousInput_d = FingerEAERCtrl_P.Memory1_X0_a;

  /* InitializeConditions for MATLAB Function: '<S56>/detect force onset' */
  FingerEAE_detectforceonset_Init(&FingerEAERCtrl_DWork.sf_detectforceonset_m);

  /* InitializeConditions for Triggered SubSystem: '<S56>/params buffer' */
  FingerEAERCtr_paramsbuffer_Init(&FingerEAERCtrl_DWork.paramsbuffer_b);

  /* End of InitializeConditions for SubSystem: '<S56>/params buffer' */

  /* InitializeConditions for MATLAB Function: '<S56>/MATLAB Function' */
  FingerEAE_MATLABFunction_e_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction_p);

  /* InitializeConditions for Memory: '<S70>/Memory1' */
  FingerEAERCtrl_DWork.Memory1_PreviousInput_h = FingerEAERCtrl_P.Memory1_X0_e;

  /* InitializeConditions for MATLAB Function: '<S70>/MATLAB Function1' */
  FingerEAER_MATLABFunction1_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction1);

  /* InitializeConditions for Triggered SubSystem: '<S67>/params buffer' */
  FingerEAERC_paramsbuffer_n_Init(&FingerEAERCtrl_DWork.paramsbuffer_k);

  /* End of InitializeConditions for SubSystem: '<S67>/params buffer' */

  /* InitializeConditions for MATLAB Function: '<S67>/MATLAB Function' */
  FingerEAE_MATLABFunction_a_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction_mh);

  /* InitializeConditions for Memory: '<S75>/Memory1' */
  FingerEAERCtrl_DWork.Memory1_PreviousInput_e = FingerEAERCtrl_P.Memory1_X0_j;

  /* InitializeConditions for MATLAB Function: '<S75>/MATLAB Function1' */
  FingerEAER_MATLABFunction1_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction1_m);

  /* InitializeConditions for Triggered SubSystem: '<S68>/params buffer' */
  FingerEAERC_paramsbuffer_n_Init(&FingerEAERCtrl_DWork.paramsbuffer_i);

  /* End of InitializeConditions for SubSystem: '<S68>/params buffer' */

  /* InitializeConditions for MATLAB Function: '<S68>/MATLAB Function' */
  FingerEAE_MATLABFunction_a_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction_i);

  /* InitializeConditions for Memory: '<S82>/Memory1' */
  FingerEAERCtrl_DWork.Memory1_PreviousInput_l = FingerEAERCtrl_P.Memory1_X0_k;

  /* InitializeConditions for MATLAB Function: '<S82>/MATLAB Function1' */
  FingerEAER_MATLABFunction1_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction1_g);

  /* InitializeConditions for Triggered SubSystem: '<S79>/params buffer' */
  FingerEAERC_paramsbuffer_b_Init(&FingerEAERCtrl_DWork.paramsbuffer_o);

  /* End of InitializeConditions for SubSystem: '<S79>/params buffer' */

  /* InitializeConditions for Memory: '<S79>/Memory' */
  FingerEAERCtrl_DWork.Memory_PreviousInput_h = FingerEAERCtrl_P.Memory_X0_d;

  /* InitializeConditions for Memory: '<S79>/Memory1' */
  FingerEAERCtrl_DWork.Memory1_PreviousInput_ld = FingerEAERCtrl_P.Memory1_X0_m;

  /* InitializeConditions for MATLAB Function: '<S79>/MATLAB Function' */
  FingerEAE_MATLABFunction_n_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction_c);

  /* InitializeConditions for Memory: '<S87>/Memory1' */
  FingerEAERCtrl_DWork.Memory1_PreviousInput_f = FingerEAERCtrl_P.Memory1_X0_ja;

  /* InitializeConditions for MATLAB Function: '<S87>/MATLAB Function1' */
  FingerEAER_MATLABFunction1_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction1_h);

  /* InitializeConditions for Triggered SubSystem: '<S80>/params buffer' */
  FingerEAERC_paramsbuffer_b_Init(&FingerEAERCtrl_DWork.paramsbuffer_a);

  /* End of InitializeConditions for SubSystem: '<S80>/params buffer' */

  /* InitializeConditions for Memory: '<S80>/Memory' */
  FingerEAERCtrl_DWork.Memory_PreviousInput_la = FingerEAERCtrl_P.Memory_X0_o;

  /* InitializeConditions for Memory: '<S80>/Memory1' */
  FingerEAERCtrl_DWork.Memory1_PreviousInput_hw = FingerEAERCtrl_P.Memory1_X0_b;

  /* InitializeConditions for MATLAB Function: '<S80>/MATLAB Function' */
  FingerEAE_MATLABFunction_n_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction_j);

  /* InitializeConditions for Memory: '<S95>/Memory2' */
  FingerEAERCtrl_DWork.Memory2_PreviousInput = FingerEAERCtrl_P.Memory2_X0;

  /* InitializeConditions for MATLAB Function: '<S95>/MATLAB Function1' */
  FingerEA_MATLABFunction1_j_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction1_k);

  /* InitializeConditions for Triggered SubSystem: '<S92>/force buffer' */
  FingerEAERCtrl_forcebuffer_Init(&FingerEAERCtrl_DWork.forcebuffer);

  /* End of InitializeConditions for SubSystem: '<S92>/force buffer' */

  /* InitializeConditions for MATLAB Function: '<S92>/detect force onset1' */
  FingerEA_detectforceonset1_Init(&FingerEAERCtrl_DWork.sf_detectforceonset1);

  /* InitializeConditions for Memory: '<S92>/tDesMem' */
  FingerEAERCtrl_DWork.tDesMem_PreviousInput = FingerEAERCtrl_P.tDesMem_X0;

  /* InitializeConditions for MATLAB Function: '<S92>/trigger check' */
  FingerEAERCtr_triggercheck_Init(&FingerEAERCtrl_DWork.sf_triggercheck);

  /* InitializeConditions for Triggered SubSystem: '<S92>/params buffer1' */
  FingerEAERCt_paramsbuffer1_Init(&FingerEAERCtrl_DWork.paramsbuffer1);

  /* End of InitializeConditions for SubSystem: '<S92>/params buffer1' */

  /* InitializeConditions for Memory: '<S92>/pholdMem' */
  FingerEAERCtrl_DWork.pholdMem_PreviousInput = FingerEAERCtrl_P.pholdMem_X0;

  /* InitializeConditions for Memory: '<S92>/stateMem' */
  FingerEAERCtrl_DWork.stateMem_PreviousInput = FingerEAERCtrl_P.stateMem_X0;

  /* InitializeConditions for MATLAB Function: '<S92>/traj calc' */
  FingerEAERCtrl_trajcalc_Init(&FingerEAERCtrl_DWork.sf_trajcalc);

  /* InitializeConditions for Memory: '<S108>/Memory2' */
  FingerEAERCtrl_DWork.Memory2_PreviousInput_o = FingerEAERCtrl_P.Memory2_X0_k;

  /* InitializeConditions for MATLAB Function: '<S108>/MATLAB Function1' */
  FingerEA_MATLABFunction1_j_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction1_l);

  /* InitializeConditions for Triggered SubSystem: '<S93>/force buffer' */
  FingerEAERCtrl_forcebuffer_Init(&FingerEAERCtrl_DWork.forcebuffer_c);

  /* End of InitializeConditions for SubSystem: '<S93>/force buffer' */

  /* InitializeConditions for MATLAB Function: '<S93>/detect force onset1' */
  FingerEA_detectforceonset1_Init(&FingerEAERCtrl_DWork.sf_detectforceonset1_f);

  /* InitializeConditions for Memory: '<S93>/tDesMem' */
  FingerEAERCtrl_DWork.tDesMem_PreviousInput_n = FingerEAERCtrl_P.tDesMem_X0_a;

  /* InitializeConditions for MATLAB Function: '<S93>/trigger check' */
  FingerEAERCtr_triggercheck_Init(&FingerEAERCtrl_DWork.sf_triggercheck_c);

  /* InitializeConditions for Triggered SubSystem: '<S93>/params buffer1' */
  FingerEAERCt_paramsbuffer1_Init(&FingerEAERCtrl_DWork.paramsbuffer1_i);

  /* End of InitializeConditions for SubSystem: '<S93>/params buffer1' */

  /* InitializeConditions for Memory: '<S93>/pholdMem' */
  FingerEAERCtrl_DWork.pholdMem_PreviousInput_k = FingerEAERCtrl_P.pholdMem_X0_p;

  /* InitializeConditions for Memory: '<S93>/stateMem' */
  FingerEAERCtrl_DWork.stateMem_PreviousInput_g = FingerEAERCtrl_P.stateMem_X0_l;

  /* InitializeConditions for MATLAB Function: '<S93>/traj calc' */
  FingerEAERCtrl_trajcalc_Init(&FingerEAERCtrl_DWork.sf_trajcalc_o);

  /* InitializeConditions for Memory: '<S35>/Memory' */
  FingerEAERCtrl_DWork.Memory_PreviousInput_k1[0] =
    FingerEAERCtrl_P.Memory_X0_g[0];
  FingerEAERCtrl_DWork.Memory_PreviousInput_k1[1] =
    FingerEAERCtrl_P.Memory_X0_g[1];
  FingerEAERCtrl_DWork.Memory_PreviousInput_k1[2] =
    FingerEAERCtrl_P.Memory_X0_g[2];
  FingerEAERCtrl_DWork.Memory_PreviousInput_k1[3] =
    FingerEAERCtrl_P.Memory_X0_g[3];

  /* InitializeConditions for MATLAB Function: '<S35>/gainramp' */
  FingerEAERCtrl_gainramp_Init(&FingerEAERCtrl_DWork.sf_gainramp_o);

  /* InitializeConditions for Memory: '<S36>/Memory' */
  FingerEAERCtrl_DWork.Memory_PreviousInput_n[0] = FingerEAERCtrl_P.Memory_X0_a
    [0];
  FingerEAERCtrl_DWork.Memory_PreviousInput_n[1] = FingerEAERCtrl_P.Memory_X0_a
    [1];
  FingerEAERCtrl_DWork.Memory_PreviousInput_n[2] = FingerEAERCtrl_P.Memory_X0_a
    [2];
  FingerEAERCtrl_DWork.Memory_PreviousInput_n[3] = FingerEAERCtrl_P.Memory_X0_a
    [3];

  /* InitializeConditions for MATLAB Function: '<S36>/gainramp' */
  FingerEAERCtrl_gainramp_Init(&FingerEAERCtrl_DWork.sf_gainramp_i);

  /* InitializeConditions for Memory: '<S37>/Memory' */
  FingerEAERCtrl_DWork.Memory_PreviousInput_b[0] = FingerEAERCtrl_P.Memory_X0_b
    [0];
  FingerEAERCtrl_DWork.Memory_PreviousInput_b[1] = FingerEAERCtrl_P.Memory_X0_b
    [1];
  FingerEAERCtrl_DWork.Memory_PreviousInput_b[2] = FingerEAERCtrl_P.Memory_X0_b
    [2];
  FingerEAERCtrl_DWork.Memory_PreviousInput_b[3] = FingerEAERCtrl_P.Memory_X0_b
    [3];

  /* InitializeConditions for MATLAB Function: '<S37>/gainramp' */
  FingerEAERCtrl_gainramp_Init(&FingerEAERCtrl_DWork.sf_gainramp_id);

  /* InitializeConditions for Memory: '<S38>/Memory' */
  FingerEAERCtrl_DWork.Memory_PreviousInput_j[0] =
    FingerEAERCtrl_P.Memory_X0_g0[0];
  FingerEAERCtrl_DWork.Memory_PreviousInput_j[1] =
    FingerEAERCtrl_P.Memory_X0_g0[1];
  FingerEAERCtrl_DWork.Memory_PreviousInput_j[2] =
    FingerEAERCtrl_P.Memory_X0_g0[2];
  FingerEAERCtrl_DWork.Memory_PreviousInput_j[3] =
    FingerEAERCtrl_P.Memory_X0_g0[3];

  /* InitializeConditions for MATLAB Function: '<S38>/gainramp' */
  FingerEAERCtrl_gainramp_Init(&FingerEAERCtrl_DWork.sf_gainramp_b);

  /* InitializeConditions for MATLAB Function: '<S3>/controller' */
  FingerEAERCtrl_DWork.sfEvent_g = FingerEAERCtrl_CALL_EVENT_m5;
  FingerEAERCtrl_DWork.is_active_c2_FingerEAERCtrl = 0U;

  /* InitializeConditions for MATLAB Function: '<S27>/ramp' */
  FingerEAERCtrl_DWork.sfEvent_d = FingerEAERCtrl_CALL_EVENT_m5;
  FingerEAERCtrl_DWork.is_active_c45_FingerEAERCtrl = 0U;

  /* InitializeConditions for MATLAB Function: '<S27>/MATLAB Function' */
  FingerEAERCtrl_DWork.sfEvent_cn = FingerEAERCtrl_CALL_EVENT_m5;
  FingerEAERCtrl_DWork.is_active_c10_FingerEAERCtrl = 0U;

  /* InitializeConditions for Memory: '<S39>/Memory' */
  FingerEAERCtrl_DWork.Memory_PreviousInput_ix[0] =
    FingerEAERCtrl_P.Memory_X0_bp[0];
  FingerEAERCtrl_DWork.Memory_PreviousInput_ix[1] =
    FingerEAERCtrl_P.Memory_X0_bp[1];
  FingerEAERCtrl_DWork.Memory_PreviousInput_ix[2] =
    FingerEAERCtrl_P.Memory_X0_bp[2];
  FingerEAERCtrl_DWork.Memory_PreviousInput_ix[3] =
    FingerEAERCtrl_P.Memory_X0_bp[3];

  /* InitializeConditions for MATLAB Function: '<S39>/gainramp' */
  FingerEAERCtrl_gainramp_Init(&FingerEAERCtrl_DWork.sf_gainramp_f);

  /* InitializeConditions for Memory: '<S40>/Memory' */
  FingerEAERCtrl_DWork.Memory_PreviousInput_c[0] =
    FingerEAERCtrl_P.Memory_X0_eq[0];
  FingerEAERCtrl_DWork.Memory_PreviousInput_c[1] =
    FingerEAERCtrl_P.Memory_X0_eq[1];
  FingerEAERCtrl_DWork.Memory_PreviousInput_c[2] =
    FingerEAERCtrl_P.Memory_X0_eq[2];
  FingerEAERCtrl_DWork.Memory_PreviousInput_c[3] =
    FingerEAERCtrl_P.Memory_X0_eq[3];

  /* InitializeConditions for MATLAB Function: '<S40>/gainramp' */
  FingerEAERCtrl_gainramp_Init(&FingerEAERCtrl_DWork.sf_gainramp_a);

  /* InitializeConditions for MATLAB Function: '<S3>/viccosityAdder' */
  FingerEAERCtrl_DWork.sfEvent = FingerEAERCtrl_CALL_EVENT_m5;
  FingerEAERCtrl_DWork.is_active_c42_FingerEAERCtrl = 0U;

  /* InitializeConditions for Memory: '<S28>/Memory' */
  FingerEAERCtrl_DWork.Memory_PreviousInput_i3 = FingerEAERCtrl_P.Memory_X0_hx;

  /* InitializeConditions for MATLAB Function: '<S28>/MATLAB Function1' */
  FingerEAERCtrl_DWork.sfEvent_c = FingerEAERCtrl_CALL_EVENT_m5;
  FingerEAERCtrl_DWork.is_active_c31_FingerEAERCtrl = 0U;

  /* InitializeConditions for Memory: '<S28>/Memory2' */
  FingerEAERCtrl_DWork.Memory2_PreviousInput_f = FingerEAERCtrl_P.Memory2_X0_l;

  /* InitializeConditions for Memory: '<S28>/Memory1' */
  FingerEAERCtrl_DWork.Memory1_PreviousInput_k = FingerEAERCtrl_P.Memory1_X0_c;

  /* InitializeConditions for MATLAB Function: '<S28>/MATLAB Function' */
  FingerEAERCtrl_DWork.sfEvent_b = FingerEAERCtrl_CALL_EVENT_m5;
  FingerEAERCtrl_DWork.is_active_c30_FingerEAERCtrl = 0U;

  /* InitializeConditions for MATLAB Function: '<S12>/MATLAB Function' */
  FingerEAERC_MATLABFunction_Init(&FingerEAERCtrl_DWork.sf_MATLABFunction_my);

  /* InitializeConditions for DiscreteStateSpace: '<S16>/Low Pass 100 Hz' */
  FingerEAERCtrl_DWork.LowPass100Hz_DSTATE[0] =
    FingerEAERCtrl_P.LowPass100Hz_X0[0];
  FingerEAERCtrl_DWork.LowPass100Hz_DSTATE[1] =
    FingerEAERCtrl_P.LowPass100Hz_X0[1];

  /* InitializeConditions for DiscreteStateSpace: '<S16>/Low Pass 100 Hz1' */
  FingerEAERCtrl_DWork.LowPass100Hz1_DSTATE[0] =
    FingerEAERCtrl_P.LowPass100Hz1_X0[0];
  FingerEAERCtrl_DWork.LowPass100Hz1_DSTATE[1] =
    FingerEAERCtrl_P.LowPass100Hz1_X0[1];

  /* InitializeConditions for Triggered SubSystem: '<S92>/saveTrialStartTime' */
  FingerE_saveTrialStartTime_Init(&FingerEAERCtrl_DWork.saveTrialStartTime);

  /* End of InitializeConditions for SubSystem: '<S92>/saveTrialStartTime' */

  /* InitializeConditions for Triggered SubSystem: '<S92>/timeToTrigger' */
  FingerEAERCt_timeToTrigger_Init(&FingerEAERCtrl_DWork.timeToTrigger,
    (rtP_timeToTrigger_FingerEAERCtr *)&FingerEAERCtrl_P.timeToTrigger);

  /* End of InitializeConditions for SubSystem: '<S92>/timeToTrigger' */

  /* InitializeConditions for Triggered SubSystem: '<S93>/saveTrialStartTime' */
  FingerE_saveTrialStartTime_Init(&FingerEAERCtrl_DWork.saveTrialStartTime_o);

  /* End of InitializeConditions for SubSystem: '<S93>/saveTrialStartTime' */

  /* InitializeConditions for Triggered SubSystem: '<S93>/timeToTrigger' */
  FingerEAERCt_timeToTrigger_Init(&FingerEAERCtrl_DWork.timeToTrigger_e,
    (rtP_timeToTrigger_FingerEAERCtr *)&FingerEAERCtrl_P.timeToTrigger_e);

  /* End of InitializeConditions for SubSystem: '<S93>/timeToTrigger' */
}

/* Model terminate function */
void FingerEAERCtrl_terminate(void)
{
  /* Level2 S-Function Block: '<S2>/PCI-6221 AD1' (adnipcim) */
  {
    SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/PCI 6221 ENC ' (encnipcim) */
  {
    SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/PCI 6221 ENC 1' (encnipcim) */
  {
    SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/PCI-6221 DA' (danipcim) */
  {
    SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[3];
    sfcnTerminate(rts);
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  FingerEAERCtrl_output();

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  FingerEAERCtrl_update();

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  FingerEAERCtrl_initialize();
}

void MdlTerminate(void)
{
  FingerEAERCtrl_terminate();
}

rtModel_FingerEAERCtrl *FingerEAERCtrl(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)FingerEAERCtrl_rtM, 0,
                sizeof(rtModel_FingerEAERCtrl));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&FingerEAERCtrl_rtM->solverInfo,
                          &FingerEAERCtrl_rtM->Timing.simTimeStep);
    rtsiSetTPtr(&FingerEAERCtrl_rtM->solverInfo, &rtmGetTPtr(FingerEAERCtrl_rtM));
    rtsiSetStepSizePtr(&FingerEAERCtrl_rtM->solverInfo,
                       &FingerEAERCtrl_rtM->Timing.stepSize0);
    rtsiSetdXPtr(&FingerEAERCtrl_rtM->solverInfo,
                 &FingerEAERCtrl_rtM->ModelData.derivs);
    rtsiSetContStatesPtr(&FingerEAERCtrl_rtM->solverInfo,
                         &FingerEAERCtrl_rtM->ModelData.contStates);
    rtsiSetNumContStatesPtr(&FingerEAERCtrl_rtM->solverInfo,
      &FingerEAERCtrl_rtM->Sizes.numContStates);
    rtsiSetErrorStatusPtr(&FingerEAERCtrl_rtM->solverInfo, (&rtmGetErrorStatus
      (FingerEAERCtrl_rtM)));
    rtsiSetRTModelPtr(&FingerEAERCtrl_rtM->solverInfo, FingerEAERCtrl_rtM);
  }

  rtsiSetSimTimeStep(&FingerEAERCtrl_rtM->solverInfo, MAJOR_TIME_STEP);
  FingerEAERCtrl_rtM->ModelData.intgData.y = FingerEAERCtrl_rtM->ModelData.odeY;
  FingerEAERCtrl_rtM->ModelData.intgData.f[0] =
    FingerEAERCtrl_rtM->ModelData.odeF[0];
  FingerEAERCtrl_rtM->ModelData.intgData.f[1] =
    FingerEAERCtrl_rtM->ModelData.odeF[1];
  FingerEAERCtrl_rtM->ModelData.intgData.f[2] =
    FingerEAERCtrl_rtM->ModelData.odeF[2];
  FingerEAERCtrl_rtM->ModelData.contStates = ((real_T *) &FingerEAERCtrl_X);
  rtsiSetSolverData(&FingerEAERCtrl_rtM->solverInfo, (void *)
                    &FingerEAERCtrl_rtM->ModelData.intgData);
  rtsiSetSolverName(&FingerEAERCtrl_rtM->solverInfo,"ode3");
  FingerEAERCtrl_rtM->solverInfoPtr = (&FingerEAERCtrl_rtM->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = FingerEAERCtrl_rtM->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    FingerEAERCtrl_rtM->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    FingerEAERCtrl_rtM->Timing.sampleTimes =
      (&FingerEAERCtrl_rtM->Timing.sampleTimesArray[0]);
    FingerEAERCtrl_rtM->Timing.offsetTimes =
      (&FingerEAERCtrl_rtM->Timing.offsetTimesArray[0]);

    /* task periods */
    FingerEAERCtrl_rtM->Timing.sampleTimes[0] = (0.0);
    FingerEAERCtrl_rtM->Timing.sampleTimes[1] = (0.001);

    /* task offsets */
    FingerEAERCtrl_rtM->Timing.offsetTimes[0] = (0.0);
    FingerEAERCtrl_rtM->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(FingerEAERCtrl_rtM, &FingerEAERCtrl_rtM->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = FingerEAERCtrl_rtM->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    FingerEAERCtrl_rtM->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(FingerEAERCtrl_rtM, -1);
  FingerEAERCtrl_rtM->Timing.stepSize0 = 0.001;
  FingerEAERCtrl_rtM->Timing.stepSize1 = 0.001;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    FingerEAERCtrl_rtM->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(FingerEAERCtrl_rtM->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(FingerEAERCtrl_rtM->rtwLogInfo, (NULL));
    rtliSetLogT(FingerEAERCtrl_rtM->rtwLogInfo, "tout");
    rtliSetLogX(FingerEAERCtrl_rtM->rtwLogInfo, "");
    rtliSetLogXFinal(FingerEAERCtrl_rtM->rtwLogInfo, "");
    rtliSetSigLog(FingerEAERCtrl_rtM->rtwLogInfo, "");
    rtliSetLogVarNameModifier(FingerEAERCtrl_rtM->rtwLogInfo, "rt_");
    rtliSetLogFormat(FingerEAERCtrl_rtM->rtwLogInfo, 0);
    rtliSetLogMaxRows(FingerEAERCtrl_rtM->rtwLogInfo, 1000);
    rtliSetLogDecimation(FingerEAERCtrl_rtM->rtwLogInfo, 1);
    rtliSetLogY(FingerEAERCtrl_rtM->rtwLogInfo, "");
    rtliSetLogYSignalInfo(FingerEAERCtrl_rtM->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(FingerEAERCtrl_rtM->rtwLogInfo, (NULL));
  }

  /* External mode info */
  FingerEAERCtrl_rtM->Sizes.checksums[0] = (506262087U);
  FingerEAERCtrl_rtM->Sizes.checksums[1] = (142155991U);
  FingerEAERCtrl_rtM->Sizes.checksums[2] = (1069231661U);
  FingerEAERCtrl_rtM->Sizes.checksums[3] = (2603057408U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[69];
    FingerEAERCtrl_rtM->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = &rtAlwaysEnabled;
    systemRan[9] = &rtAlwaysEnabled;
    systemRan[10] = &rtAlwaysEnabled;
    systemRan[11] = &rtAlwaysEnabled;
    systemRan[12] = &rtAlwaysEnabled;
    systemRan[13] = &rtAlwaysEnabled;
    systemRan[14] = &rtAlwaysEnabled;
    systemRan[15] = &rtAlwaysEnabled;
    systemRan[16] = &rtAlwaysEnabled;
    systemRan[17] = &rtAlwaysEnabled;
    systemRan[18] = &rtAlwaysEnabled;
    systemRan[19] = &rtAlwaysEnabled;
    systemRan[20] = &rtAlwaysEnabled;
    systemRan[21] = &rtAlwaysEnabled;
    systemRan[22] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer.paramsbuffer_SubsysRanBC;
    systemRan[23] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer.paramsbuffer_SubsysRanBC;
    systemRan[24] = &rtAlwaysEnabled;
    systemRan[25] = &rtAlwaysEnabled;
    systemRan[26] = &rtAlwaysEnabled;
    systemRan[27] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer_b.paramsbuffer_SubsysRanBC;
    systemRan[28] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer_b.paramsbuffer_SubsysRanBC;
    systemRan[29] = &rtAlwaysEnabled;
    systemRan[30] = &rtAlwaysEnabled;
    systemRan[31] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer_k.paramsbuffer_SubsysRanBC;
    systemRan[32] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer_k.paramsbuffer_SubsysRanBC;
    systemRan[33] = &rtAlwaysEnabled;
    systemRan[34] = &rtAlwaysEnabled;
    systemRan[35] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer_i.paramsbuffer_SubsysRanBC;
    systemRan[36] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer_i.paramsbuffer_SubsysRanBC;
    systemRan[37] = &rtAlwaysEnabled;
    systemRan[38] = &rtAlwaysEnabled;
    systemRan[39] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer_o.paramsbuffer_SubsysRanBC;
    systemRan[40] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer_o.paramsbuffer_SubsysRanBC;
    systemRan[41] = &rtAlwaysEnabled;
    systemRan[42] = &rtAlwaysEnabled;
    systemRan[43] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer_a.paramsbuffer_SubsysRanBC;
    systemRan[44] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer_a.paramsbuffer_SubsysRanBC;
    systemRan[45] = &rtAlwaysEnabled;
    systemRan[46] = &rtAlwaysEnabled;
    systemRan[47] = (sysRanDType *)
      &FingerEAERCtrl_DWork.forcebuffer.forcebuffer_SubsysRanBC;
    systemRan[48] = (sysRanDType *)
      &FingerEAERCtrl_DWork.forcebuffer.forcebuffer_SubsysRanBC;
    systemRan[49] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer1.paramsbuffer1_SubsysRanBC;
    systemRan[50] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer1.paramsbuffer1_SubsysRanBC;
    systemRan[51] = (sysRanDType *)
      &FingerEAERCtrl_DWork.saveTrialStartTime.saveTrialStartTime_SubsysRanBC;
    systemRan[52] = (sysRanDType *)
      &FingerEAERCtrl_DWork.saveTrialStartTime.saveTrialStartTime_SubsysRanBC;
    systemRan[53] = (sysRanDType *)
      &FingerEAERCtrl_DWork.timeToTrigger.timeToTrigger_SubsysRanBC;
    systemRan[54] = (sysRanDType *)
      &FingerEAERCtrl_DWork.timeToTrigger.timeToTrigger_SubsysRanBC;
    systemRan[55] = &rtAlwaysEnabled;
    systemRan[56] = &rtAlwaysEnabled;
    systemRan[57] = &rtAlwaysEnabled;
    systemRan[58] = &rtAlwaysEnabled;
    systemRan[59] = (sysRanDType *)
      &FingerEAERCtrl_DWork.forcebuffer_c.forcebuffer_SubsysRanBC;
    systemRan[60] = (sysRanDType *)
      &FingerEAERCtrl_DWork.forcebuffer_c.forcebuffer_SubsysRanBC;
    systemRan[61] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer1_i.paramsbuffer1_SubsysRanBC;
    systemRan[62] = (sysRanDType *)
      &FingerEAERCtrl_DWork.paramsbuffer1_i.paramsbuffer1_SubsysRanBC;
    systemRan[63] = (sysRanDType *)
      &FingerEAERCtrl_DWork.saveTrialStartTime_o.saveTrialStartTime_SubsysRanBC;
    systemRan[64] = (sysRanDType *)
      &FingerEAERCtrl_DWork.saveTrialStartTime_o.saveTrialStartTime_SubsysRanBC;
    systemRan[65] = (sysRanDType *)
      &FingerEAERCtrl_DWork.timeToTrigger_e.timeToTrigger_SubsysRanBC;
    systemRan[66] = (sysRanDType *)
      &FingerEAERCtrl_DWork.timeToTrigger_e.timeToTrigger_SubsysRanBC;
    systemRan[67] = &rtAlwaysEnabled;
    systemRan[68] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(FingerEAERCtrl_rtM->extModeInfo,
      &FingerEAERCtrl_rtM->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(FingerEAERCtrl_rtM->extModeInfo,
                        FingerEAERCtrl_rtM->Sizes.checksums);
    rteiSetTPtr(FingerEAERCtrl_rtM->extModeInfo, rtmGetTPtr(FingerEAERCtrl_rtM));
  }

  FingerEAERCtrl_rtM->solverInfoPtr = (&FingerEAERCtrl_rtM->solverInfo);
  FingerEAERCtrl_rtM->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&FingerEAERCtrl_rtM->solverInfo, 0.001);
  rtsiSetSolverMode(&FingerEAERCtrl_rtM->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  FingerEAERCtrl_rtM->ModelData.blockIO = ((void *) &FingerEAERCtrl_B);
  (void) memset(((void *) &FingerEAERCtrl_B), 0,
                sizeof(BlockIO_FingerEAERCtrl));

  /* parameters */
  FingerEAERCtrl_rtM->ModelData.defaultParam = ((real_T *)&FingerEAERCtrl_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &FingerEAERCtrl_X;
    FingerEAERCtrl_rtM->ModelData.contStates = (x);
    (void) memset((void *)&FingerEAERCtrl_X, 0,
                  sizeof(ContinuousStates_FingerEAERCtrl));
  }

  /* states (dwork) */
  FingerEAERCtrl_rtM->Work.dwork = ((void *) &FingerEAERCtrl_DWork);
  (void) memset((void *)&FingerEAERCtrl_DWork, 0,
                sizeof(D_Work_FingerEAERCtrl));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    FingerEAERCtrl_rtM->SpecialInfo.mappingInfo = (&dtInfo);
    FingerEAERCtrl_rtM->SpecialInfo.xpcData = ((void*) &dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.B = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.P = &rtPTransTable;
  }

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  FingerEAERCtrl_InitializeDataMapInfo(FingerEAERCtrl_rtM);

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &FingerEAERCtrl_rtM->NonInlinedSFcns.sfcnInfo;
    FingerEAERCtrl_rtM->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(FingerEAERCtrl_rtM)));
    rtssSetNumRootSampTimesPtr(sfcnInfo, &FingerEAERCtrl_rtM->Sizes.numSampTimes);
    FingerEAERCtrl_rtM->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr
      (FingerEAERCtrl_rtM)[0]);
    FingerEAERCtrl_rtM->NonInlinedSFcns.taskTimePtrs[1] = &(rtmGetTPtr
      (FingerEAERCtrl_rtM)[1]);
    rtssSetTPtrPtr(sfcnInfo,FingerEAERCtrl_rtM->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(FingerEAERCtrl_rtM));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(FingerEAERCtrl_rtM));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (FingerEAERCtrl_rtM));
    rtssSetStepSizePtr(sfcnInfo, &FingerEAERCtrl_rtM->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(FingerEAERCtrl_rtM));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &FingerEAERCtrl_rtM->ModelData.derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
      &FingerEAERCtrl_rtM->ModelData.zCCacheNeedsReset);
    rtssSetBlkStateChangePtr(sfcnInfo,
      &FingerEAERCtrl_rtM->ModelData.blkStateChange);
    rtssSetSampleHitsPtr(sfcnInfo, &FingerEAERCtrl_rtM->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &FingerEAERCtrl_rtM->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &FingerEAERCtrl_rtM->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &FingerEAERCtrl_rtM->solverInfoPtr);
  }

  FingerEAERCtrl_rtM->Sizes.numSFcns = (4);

  /* register each child */
  {
    (void) memset((void *)&FingerEAERCtrl_rtM->NonInlinedSFcns.childSFunctions[0],
                  0,
                  4*sizeof(SimStruct));
    FingerEAERCtrl_rtM->childSfunctions =
      (&FingerEAERCtrl_rtM->NonInlinedSFcns.childSFunctionPtrs[0]);
    FingerEAERCtrl_rtM->childSfunctions[0] =
      (&FingerEAERCtrl_rtM->NonInlinedSFcns.childSFunctions[0]);
    FingerEAERCtrl_rtM->childSfunctions[1] =
      (&FingerEAERCtrl_rtM->NonInlinedSFcns.childSFunctions[1]);
    FingerEAERCtrl_rtM->childSfunctions[2] =
      (&FingerEAERCtrl_rtM->NonInlinedSFcns.childSFunctions[2]);
    FingerEAERCtrl_rtM->childSfunctions[3] =
      (&FingerEAERCtrl_rtM->NonInlinedSFcns.childSFunctions[3]);

    /* Level2 S-Function Block: FingerEAERCtrl/<S2>/PCI-6221 AD1 (adnipcim) */
    {
      SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod = FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset = FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.blkInfo2[0]);
      }

      ssSetRTWSfcnInfo(rts, FingerEAERCtrl_rtM->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.statesInfo2[0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 8);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &FingerEAERCtrl_B.PCI6221AD1_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &FingerEAERCtrl_B.PCI6221AD1_o2));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidth(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((real_T *)
            &FingerEAERCtrl_B.PCI6221AD1_o3));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidth(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((real_T *)
            &FingerEAERCtrl_B.PCI6221AD1_o4));
        }

        /* port 4 */
        {
          _ssSetOutputPortNumDimensions(rts, 4, 1);
          ssSetOutputPortWidth(rts, 4, 1);
          ssSetOutputPortSignal(rts, 4, ((real_T *)
            &FingerEAERCtrl_B.PCI6221AD1_o5));
        }

        /* port 5 */
        {
          _ssSetOutputPortNumDimensions(rts, 5, 1);
          ssSetOutputPortWidth(rts, 5, 1);
          ssSetOutputPortSignal(rts, 5, ((real_T *)
            &FingerEAERCtrl_B.PCI6221AD1_o6));
        }

        /* port 6 */
        {
          _ssSetOutputPortNumDimensions(rts, 6, 1);
          ssSetOutputPortWidth(rts, 6, 1);
          ssSetOutputPortSignal(rts, 6, ((real_T *)
            &FingerEAERCtrl_B.PCI6221AD1_o7));
        }

        /* port 7 */
        {
          _ssSetOutputPortNumDimensions(rts, 7, 1);
          ssSetOutputPortWidth(rts, 7, 1);
          ssSetOutputPortSignal(rts, 7, ((real_T *)
            &FingerEAERCtrl_B.PCI6221AD1_o8));
        }
      }

      /* path info */
      ssSetModelName(rts, "PCI-6221 AD1");
      ssSetPath(rts, "FingerEAERCtrl/Robot/PCI-6221 AD1");
      ssSetRTModel(rts,FingerEAERCtrl_rtM);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)FingerEAERCtrl_P.PCI6221AD1_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)FingerEAERCtrl_P.PCI6221AD1_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)FingerEAERCtrl_P.PCI6221AD1_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)FingerEAERCtrl_P.PCI6221AD1_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)FingerEAERCtrl_P.PCI6221AD1_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)FingerEAERCtrl_P.PCI6221AD1_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)FingerEAERCtrl_P.PCI6221AD1_P7_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &FingerEAERCtrl_DWork.PCI6221AD1_IWORK[0]);
      ssSetPWork(rts, (void **) &FingerEAERCtrl_DWork.PCI6221AD1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 41);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &FingerEAERCtrl_DWork.PCI6221AD1_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &FingerEAERCtrl_DWork.PCI6221AD1_PWORK);
      }

      /* registration */
      adnipcim(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 3, 1);
      _ssSetOutputPortConnected(rts, 4, 1);
      _ssSetOutputPortConnected(rts, 5, 1);
      _ssSetOutputPortConnected(rts, 6, 1);
      _ssSetOutputPortConnected(rts, 7, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 4, 0);
      _ssSetOutputPortBeingMerged(rts, 5, 0);
      _ssSetOutputPortBeingMerged(rts, 6, 0);
      _ssSetOutputPortBeingMerged(rts, 7, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: FingerEAERCtrl/<S2>/PCI 6221 ENC  (encnipcim) */
    {
      SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod = FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset = FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.blkInfo2[1]);
      }

      ssSetRTWSfcnInfo(rts, FingerEAERCtrl_rtM->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.statesInfo2[1]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn1.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &FingerEAERCtrl_B.PCI6221ENC));
        }
      }

      /* path info */
      ssSetModelName(rts, "PCI 6221 ENC ");
      ssSetPath(rts, "FingerEAERCtrl/Robot/PCI 6221 ENC ");
      ssSetRTModel(rts,FingerEAERCtrl_rtM);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 10);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)FingerEAERCtrl_P.PCI6221ENC_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)FingerEAERCtrl_P.PCI6221ENC_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)FingerEAERCtrl_P.PCI6221ENC_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)FingerEAERCtrl_P.PCI6221ENC_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)FingerEAERCtrl_P.PCI6221ENC_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)FingerEAERCtrl_P.PCI6221ENC_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)FingerEAERCtrl_P.PCI6221ENC_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)FingerEAERCtrl_P.PCI6221ENC_P8_Size);
        ssSetSFcnParam(rts, 8, (mxArray*)FingerEAERCtrl_P.PCI6221ENC_P9_Size);
        ssSetSFcnParam(rts, 9, (mxArray*)FingerEAERCtrl_P.PCI6221ENC_P10_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &FingerEAERCtrl_DWork.PCI6221ENC_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn1.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn1.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &FingerEAERCtrl_DWork.PCI6221ENC_PWORK);
      }

      /* registration */
      encnipcim(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: FingerEAERCtrl/<S2>/PCI 6221 ENC 1 (encnipcim) */
    {
      SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod = FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset = FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap = FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.blkInfo2[2]);
      }

      ssSetRTWSfcnInfo(rts, FingerEAERCtrl_rtM->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.statesInfo2[2]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn2.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &FingerEAERCtrl_B.PCI6221ENC1));
        }
      }

      /* path info */
      ssSetModelName(rts, "PCI 6221 ENC 1");
      ssSetPath(rts, "FingerEAERCtrl/Robot/PCI 6221 ENC 1");
      ssSetRTModel(rts,FingerEAERCtrl_rtM);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 10);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)FingerEAERCtrl_P.PCI6221ENC1_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)FingerEAERCtrl_P.PCI6221ENC1_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)FingerEAERCtrl_P.PCI6221ENC1_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)FingerEAERCtrl_P.PCI6221ENC1_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)FingerEAERCtrl_P.PCI6221ENC1_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)FingerEAERCtrl_P.PCI6221ENC1_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)FingerEAERCtrl_P.PCI6221ENC1_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)FingerEAERCtrl_P.PCI6221ENC1_P8_Size);
        ssSetSFcnParam(rts, 8, (mxArray*)FingerEAERCtrl_P.PCI6221ENC1_P9_Size);
        ssSetSFcnParam(rts, 9, (mxArray*)FingerEAERCtrl_P.PCI6221ENC1_P10_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &FingerEAERCtrl_DWork.PCI6221ENC1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn2.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn2.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &FingerEAERCtrl_DWork.PCI6221ENC1_PWORK);
      }

      /* registration */
      encnipcim(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: FingerEAERCtrl/<S2>/PCI-6221 DA (danipcim) */
    {
      SimStruct *rts = FingerEAERCtrl_rtM->childSfunctions[3];

      /* timing info */
      time_T *sfcnPeriod = FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn3.sfcnPeriod;
      time_T *sfcnOffset = FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn3.sfcnOffset;
      int_T *sfcnTsMap = FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn3.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.blkInfo2[3]);
      }

      ssSetRTWSfcnInfo(rts, FingerEAERCtrl_rtM->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.methods2[3]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.methods3[3]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &FingerEAERCtrl_rtM->NonInlinedSFcns.statesInfo2[3]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 2);
        ssSetPortInfoForInputs(rts,
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn3.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn3.UPtrs0;
          sfcnUPtrs[0] = &FingerEAERCtrl_B.sf_MATLABFunction_my.output1;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }

        /* port 1 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn3.UPtrs1;
          sfcnUPtrs[0] = &FingerEAERCtrl_B.sf_MATLABFunction_my.output2;
          ssSetInputPortSignalPtrs(rts, 1, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "PCI-6221 DA");
      ssSetPath(rts, "FingerEAERCtrl/Robot/PCI-6221 DA");
      ssSetRTModel(rts,FingerEAERCtrl_rtM);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn3.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)FingerEAERCtrl_P.PCI6221DA_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)FingerEAERCtrl_P.PCI6221DA_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)FingerEAERCtrl_P.PCI6221DA_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)FingerEAERCtrl_P.PCI6221DA_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)FingerEAERCtrl_P.PCI6221DA_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)FingerEAERCtrl_P.PCI6221DA_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)FingerEAERCtrl_P.PCI6221DA_P7_Size);
      }

      /* work vectors */
      ssSetRWork(rts, (real_T *) &FingerEAERCtrl_DWork.PCI6221DA_RWORK[0]);
      ssSetIWork(rts, (int_T *) &FingerEAERCtrl_DWork.PCI6221DA_IWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn3.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &FingerEAERCtrl_rtM->NonInlinedSFcns.Sfcn3.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* RWORK */
        ssSetDWorkWidth(rts, 0, 6);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &FingerEAERCtrl_DWork.PCI6221DA_RWORK[0]);

        /* IWORK */
        ssSetDWorkWidth(rts, 1, 41);
        ssSetDWorkDataType(rts, 1,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &FingerEAERCtrl_DWork.PCI6221DA_IWORK[0]);
      }

      /* registration */
      danipcim(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
    }
  }

  /* Initialize Sizes */
  FingerEAERCtrl_rtM->Sizes.numContStates = (6);/* Number of continuous states */
  FingerEAERCtrl_rtM->Sizes.numY = (0);/* Number of model outputs */
  FingerEAERCtrl_rtM->Sizes.numU = (0);/* Number of model inputs */
  FingerEAERCtrl_rtM->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  FingerEAERCtrl_rtM->Sizes.numSampTimes = (2);/* Number of sample times */
  FingerEAERCtrl_rtM->Sizes.numBlocks = (242);/* Number of blocks */
  FingerEAERCtrl_rtM->Sizes.numBlockIO = (253);/* Number of block outputs */
  FingerEAERCtrl_rtM->Sizes.numBlockPrms = (323);/* Sum of parameter "widths" */
  return FingerEAERCtrl_rtM;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
