function child=FingerEAERCtrlref
child = [];
